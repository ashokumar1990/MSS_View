<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CashierModel extends CI_Model {

    public function ModelHelper($success,$error,$error_msg = '',$data_arr = array()){
        if($success == true && $error == false){
            $data = array(
                'success' => 'true',
                'error'   => 'false',
                'message' => $error_msg,
                'res_arr' => $data_arr 
            ) ;
            
            return $data;
        }
        elseif ($success == false && $error == true) {
            $data = array(
                'success' => 'false',
                'error'   => 'true',
                'message' => $error_msg
            );
            return $data;
        }
    }

    //public function for logging in the Cashier to dashboard    
    public function CashierLogin($data) {
        $this->db->select('*');
        $this->db->from('mss_employees');
        $this->db->where('employee_email',$data['employee_email']);
        $this->db->limit(1);
        
        $query = $this->db->get();

        if ($query->num_rows() == 1){
            return $this->ModelHelper(true,false);
        }
        else{
            return $this->ModelHelper(false,true,'No such employee exists!');
        }
    }
    

    public function CashierByEmail($email) {

        $sql = "SELECT * FROM mss_employees AS A,mss_business_admin AS B WHERE A.employee_email = ".$this->db->escape($email)." AND A.employee_business_admin = B.business_admin_id";

        $query = $this->db->query($sql);
        
        if($query && $query->num_rows() == 1){
            return $this->ModelHelper(true,false,'',$query->row_array());
        }
        else{
            return $this->ModelHelper(false,true,"Duplicate emails are there!");   
        }
    }


	 //Generic function which will give all details by primary key of table
    public function DetailsById($id,$table_name,$where)
    {
        $this->db->select('*');
        $this->db->from($table_name);
        $this->db->where($where,$id);
        $this->db->limit(1);
        
        //execute the query
        $query = $this->db->get();
        
        if ($query->num_rows() == 1){
           return $this->ModelHelper(true,false,'',$query->row_array());
        } 
        else{
           return $this->ModelHelper(false,true,"Duplicate rows found!");
        }
    }

    //Generic function
    public function MultiWhereSelect($table_name,$where_array){
        $this->db->select('*');
        $this->db->from($table_name);
        $this->db->where($where_array);
        
        //execute the query
        $query = $this->db->get();

        if($query){
            return $this->ModelHelper(true,false,'',$query->result_array());
        }
        else{
            return $this->ModelHelper(false,true,"DB error!");   
        }
    }

    //Generic function
    public function FullTable($table_name){
        $query = $this->db->get($table_name);
        
        if($query){
            return $this->ModelHelper(true,false,'',$query->result_array());
        }
        else{
            return $this->ModelHelper(false,true,"DB error!");   
        }
    }

    //Generic function
    public function Update($data,$table_name,$where){
        $this->db->where($where, $data[$where]);
        $this->db->update($table_name, $data);
        if($this->db->affected_rows() > 0){
            return $this->ModelHelper(true,false);    
        }
        elseif($this->db->affected_rows() == 0){
            return $this->ModelHelper(true,false,"No row updated!");   
        }
        else{
            return $this->ModelHelper(false,true,"Some DB Error!");
        }    
        
    }

    //Generic function
    public function Insert($data,$table_name){
        if($this->db->insert($table_name,$data)){
            $data = array('insert_id' => $this->db->insert_id());
            return $this->ModelHelper(true,false,'',$data);
        }
        else{
            return $this->ModelHelper(false,true,"Check your inserted query!");
        }
    }

    public function GetCashierPersonal($employee_id){
        $sql = "SELECT * FROM mss_employees,mss_business_outlets WHERE mss_employees.employee_business_outlet = mss_business_outlets.business_outlet_id AND mss_employees.employee_id = ".$this->db->escape($employee_id)."";

        $query = $this->db->query($sql);
        
        if($query){
            return $this->ModelHelper(true,false,'',$query->row_array());
        }
        else{
            return $this->ModelHelper(false,true,"DB error!");   
        }
    }

    public function SearchCustomers($search_term,$business_admin_id,$business_outlet_id){

        $sql = "SELECT customer_id,customer_name,customer_mobile FROM `mss_customers` WHERE customer_business_admin_id = ".$this->db->escape($business_admin_id)." AND customer_business_outlet_id = ".$this->db->escape($business_outlet_id)." AND (customer_name LIKE '%$search_term%' OR customer_mobile  LIKE '%$search_term%') ORDER BY customer_name LIMIT 15";
        
        $query = $this->db->query($sql);
        
        if($query){
            return $this->ModelHelper(true,false,'',$query->result_array());
        }
        else{
            return $this->ModelHelper(false,true,"DB error!");   
        }
    }

    public function CheckCustomerExists($where){
        $this->db->select('*');
        $this->db->from('mss_customers');
        $this->db->where('customer_mobile',$where['customer_mobile']);
        $this->db->where('customer_business_admin_id',$where['customer_business_admin_id']);
        $this->db->where('customer_business_outlet_id',$where['customer_business_outlet_id']);
        
        $query = $this->db->get();

        if ($query->num_rows() == 0){
            return $this->ModelHelper(true,false);
        }
        else{
            return $this->ModelHelper(false,true,'Customer already exists!');
        }
    }

    public function VerifyCustomer($where){
        $this->db->select('*');
        $this->db->from('mss_customers');
        $this->db->where('customer_id',$where['customer_id']);
        $this->db->where('customer_business_outlet_id',$where['business_outlet_id']);
        $this->db->where('customer_business_admin_id',$where['business_admin_id']);
        $query = $this->db->get();

        if ($query->num_rows() == 1){
            return $this->ModelHelper(true,false);
        }
        else{
            return $this->ModelHelper(false,true,'You are not allowed to bill the another customer which is not under you. Please do not change url!');
        }
    }
    
    /* SAMPLE-DATA coming from the POST Request
    Array
    (
        [txn_data] => Array
            (
                [txn_customer_id] => 11
                [txn_discount] => 95
                [txn_value] => 481
            )

        [txn_settlement] => Array
            (
                [txn_settlement_way] => Split Payment
                [txn_settlement_payment_mode] => Split
                [txn_settlement_amount_received] => 400
                [txn_settlement_balance_paid] => 0
            )

        [customer_pending_data] => Array
            (
                [customer_id] => 11
                [pending_amount] => 81
            )

        [cart_data] => Array
            (
                [0] => Array
                    (
                        [service_id] => 1
                        [service_total_value] => 220
                        [service_quantity] => 2
                        [service_expert_id] => 4
                        [service_discount_percentage] => 0
                        [service_discount_absolute] => 10
                    )

                [1] => Array
                    (
                        [service_id] => 1
                        [service_total_value] => 220
                        [service_quantity] => 2
                        [service_expert_id] => 4
                        [service_discount_percentage] => 0
                        [service_discount_absolute] => 10
                    )

            )

    )
    */
    public function BillingTransaction($data){

        /*
            1. Insert data in mss_transactions
            2. Insert data in mss_transaction_services
            3. Insert data in mss_transaction_settlements
            4. Update the pending amounts for the customers if any
            
            
            //Not Implemented
            5. Last but not least if composition is available then update the stock for the services taken.
        */
        $this->db->trans_start();
        
        //1.
        $result_1 = $this->Insert($data['txn_data'],'mss_transactions');

        //2.
        for($i=0;$i<count($data['cart_data']);$i++){
            $services_data = array(
                 'txn_service_service_id' => $data['cart_data'][$i]['service_id'],
                 'txn_service_expert_id'  => $data['cart_data'][$i]['service_expert_id'],
                 'txn_service_txn_id'     => $result_1['res_arr']['insert_id'],
                 'txn_service_quantity'   => $data['cart_data'][$i]['service_quantity'],
                 'txn_service_discount_percentage' => $data['cart_data'][$i]['service_discount_percentage'],
                 'txn_service_discount_absolute'   => $data['cart_data'][$i]['service_discount_absolute'],
                 'txn_service_discounted_price' => $data['cart_data'][$i]['service_total_value']
            );
        
            $result_2 = $this->Insert($services_data,'mss_transaction_services');
        }


        //3.
        $settlement_data = array(
            'txn_settlement_txn_id' => $result_1['res_arr']['insert_id'],
            'txn_settlement_way' => $data['txn_settlement']['txn_settlement_way'],
            'txn_settlement_payment_mode' =>$data['txn_settlement']['txn_settlement_payment_mode'],
            'txn_settlement_amount_received' =>$data['txn_settlement']['txn_settlement_amount_received'],
            'txn_settlement_balance_paid' =>$data['txn_settlement']['txn_settlement_balance_paid']
        );

        $result_3 = $this->Insert($settlement_data,'mss_transaction_settlements');

       
       //4.
        $query = "UPDATE mss_customers SET customer_pending_amount = customer_pending_amount + ".(int)$data['customer_pending_data']['pending_amount']." WHERE customer_id = ".$data['customer_pending_data']['customer_id']."";
        $this->db->query($query); 
        
        $this->db->trans_complete();

        if ($this->db->trans_status() === FALSE)
        {
            return $this->ModelHelper(false,true,'Transaction cannot be processed!');
        }

        return $this->ModelHelper(true,false);
    }
}