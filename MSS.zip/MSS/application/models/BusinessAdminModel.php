<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class BusinessAdminModel extends CI_Model {
	

	public function ModelHelper($success,$error,$error_msg = '',$data_arr = array()){
        if($success == true && $error == false){
            $data = array(
                            'success' => 'true',
                            'error'   => 'false',
                            'message' => $error_msg,
                            'res_arr' => $data_arr 
                        ) ;
            
            return $data;
        }
        elseif ($success == false && $error == true) {
            $data = array(
                            'success' => 'false',
                            'error'   => 'true',
                            'message' => $error_msg
                        );
            
            return $data;
        }
    }

    //public function for logging in the business-admin to dashboard    
    public function BusinessAdminLogin($data) {
        $this->db->select('*');
        $this->db->from('mss_business_admin');
        $this->db->where('business_admin_email',$data['business_admin_email']);
        $this->db->limit(1);
        
        $query = $this->db->get();

        if ($query->num_rows() == 1){
            return $this->ModelHelper(true,false);
        }
        else{
            return $this->ModelHelper(false,true,'No such business admin exists!');
        }
    }
    

    public function BusinessAdminByEmail($email) {

        $this->db->select('*');
        $this->db->from('mss_business_admin');
        $this->db->where('business_admin_email',$email);
        $this->db->limit(1);
        
        //execute the query
        $query = $this->db->get();

        if ($query->num_rows() == 1){
            return $this->ModelHelper(true,false,'',$query->row_array());
        } 
        else{
            return $this->ModelHelper(false,true,"Duplicate emails are there!");
        }
    }


    //Generic function which will give all details by primary key of table
    public function DetailsById($id,$table_name,$where)
    {
        $this->db->select('*');
        $this->db->from($table_name);
        $this->db->where($where,$id);
        $this->db->limit(1);
        
        //execute the query
        $query = $this->db->get();
        
        if ($query->num_rows() == 1){
           return $this->ModelHelper(true,false,'',$query->row_array());
        } 
        else{
           return $this->ModelHelper(false,true,"Duplicate rows found!");
        }
    }

    //Generic function
    public function MultiWhereSelect($table_name,$where_array){
        $this->db->select('*');
        $this->db->from($table_name);
        $this->db->where($where_array);
        
        //execute the query
        $query = $this->db->get();

        if($query){
            return $this->ModelHelper(true,false,'',$query->result_array());
        }
        else{
            return $this->ModelHelper(false,true,"DB error!");   
        }
    }

    //Generic function
    public function FullTable($table_name){
        $query = $this->db->get($table_name);
        
        if($query){
            return $this->ModelHelper(true,false,'',$query->result_array());
        }
        else{
            return $this->ModelHelper(false,true,"DB error!");   
        }
    }

    //Generic function
    public function Update($data,$table_name,$where){
        $this->db->where($where, $data[$where]);
        $this->db->update($table_name, $data);
        if($this->db->affected_rows() > 0){
            return $this->ModelHelper(true,false);    
        }
        else{
            return $this->ModelHelper(false,true,"No row updated!");
        }    
        
    }

    //Generic function
    public function Insert($data,$table_name){
        if($this->db->insert($table_name,$data)){
            return $this->ModelHelper(true,false);
        }
        else{
            return $this->ModelHelper(false,true,"Check your inserted query!");
        }
    }

    public function BusinessAdminPackages($business_admin_id){

        $sql = "SELECT A.business_admin_package_id,A.business_admin_id,B.package_id,B.package_name,A.package_expiry_date FROM mss_business_admin_packages AS A,mss_packages AS B WHERE A.business_admin_id = ".$this->db->escape($business_admin_id)." AND A.package_id = B.package_id";

        $query = $this->db->query($sql);
        
        if($query){
            return $this->ModelHelper(true,false,'',$query->result_array());
        }
        else{
            return $this->ModelHelper(false,true,"DB error!");   
        }
    }

    public function SubCategories($where){
       $sql = "SELECT sub_category_id,sub_category_category_id,sub_category_name,sub_category_is_active,sub_category_description,category_name FROM mss_sub_categories AS A,mss_categories AS B WHERE A.sub_category_category_id = B.category_id AND B.category_business_admin_id = ".$this->db->escape($where['category_business_admin_id'])." AND sub_category_is_active = ".$this->db->escape($where['sub_category_is_active'])." AND B.category_business_outlet_id=".$this->db->escape($where['category_business_outlet_id'])."";
        
        $query = $this->db->query($sql);
        
        if($query){
            return $this->ModelHelper(true,false,'',$query->result_array());
        }
        else{
            return $this->ModelHelper(false,true,"DB error!");   
        }
    }

    public function Services($where){
       $sql = "SELECT * FROM mss_categories AS A,mss_sub_categories AS B,mss_services AS C WHERE A.category_id = B.sub_category_category_id AND B.sub_category_id = C.service_sub_category_id AND A.category_business_admin_id = ".$this->db->escape($where['category_business_admin_id'])." AND C.service_is_active = ".$this->db->escape($where['service_is_active'])." AND A.category_business_outlet_id=".$this->db->escape($where['category_business_outlet_id'])."";
        
        $query = $this->db->query($sql);
        
        if($query){
            return $this->ModelHelper(true,false,'',$query->result_array());
        }
        else{
            return $this->ModelHelper(false,true,"DB error!");   
        }
    }

    public function OTC($where){
       $sql = "SELECT * FROM mss_categories AS A,mss_sub_categories AS B,mss_otc_categories AS C WHERE A.category_id = B.sub_category_category_id AND B.sub_category_id = C.otc_sub_category_id AND A.category_business_admin_id = ".$this->db->escape($where['category_business_admin_id'])." AND C.otc_is_active = ".$this->db->escape($where['otc_is_active'])." AND A.category_business_outlet_id=".$this->db->escape($where['category_business_outlet_id'])."";
        
        $query = $this->db->query($sql);
        
        if($query){
            return $this->ModelHelper(true,false,'',$query->result_array());
        }
        else{
            return $this->ModelHelper(false,true,"DB error!");   
        }
    }

    public function DeactiveCategory($category_id){
        $sql = "UPDATE mss_services,mss_sub_categories,mss_categories SET mss_services.service_is_active = FALSE,mss_sub_categories.sub_category_is_active = FALSE,mss_categories.category_is_active = FALSE WHERE mss_categories.category_id = mss_sub_categories.sub_category_category_id AND mss_sub_categories.sub_category_id = mss_services.service_sub_category_id AND mss_categories.category_id =".$this->db->escape($category_id)."";

        $query = $this->db->query($sql);

        if($this->db->affected_rows() > 0){
            return $this->ModelHelper(true,false);    
        }
        else{
            return $this->ModelHelper(false,true,"No row updated!");
        } 


    }

    public function DeactiveSubCategory($sub_category_id){
        $sql = "UPDATE mss_sub_categories,mss_services SET mss_sub_categories.sub_category_is_active = FALSE,mss_services.service_is_active = FALSE WHERE mss_sub_categories.sub_category_id = mss_services.service_sub_category_id AND mss_sub_categories.sub_category_id = ".$this->db->escape($sub_category_id)."";

        $query = $this->db->query($sql);

        if($this->db->affected_rows() > 0){
            return $this->ModelHelper(true,false);    
        }
        else{
            return $this->ModelHelper(false,true,"No row updated!");
        } 
    }

    public function ViewCompositionBasic($where){
        $sql = "SELECT * FROM mss_raw_composition,mss_services,mss_sub_categories,mss_categories WHERE mss_raw_composition.service_id = mss_services.service_id AND mss_services.service_sub_category_id = mss_sub_categories.sub_category_id AND mss_sub_categories.sub_category_category_id = mss_categories.category_id AND mss_categories.category_business_admin_id = ".$this->db->escape($where['business_admin_id'])." AND mss_categories.category_business_outlet_id =".$this->db->escape($where['business_outlet_id'])." GROUP BY mss_raw_composition.service_id";

        $query = $this->db->query($sql);
        
        if($query){
            return $this->ModelHelper(true,false,'',$query->result_array());
        }
        else{
            return $this->ModelHelper(false,true,"DB error!");   
        }
    }

    public function ViewComposition($where){
        $sql = "SELECT * FROM mss_raw_composition,mss_raw_material_categories,mss_services WHERE mss_raw_composition.rmc_id = mss_raw_material_categories.raw_material_category_id AND mss_raw_material_categories.raw_material_business_admin_id = ".$this->db->escape($where['business_admin_id'])." AND mss_raw_material_categories.raw_material_business_outlet_id = ".$this->db->escape($where['business_outlet_id'])." AND mss_raw_composition.service_id = ".$this->db->escape($where['service_id'])."  AND mss_raw_composition.service_id = mss_services.service_id";

        $query = $this->db->query($sql);
        
        if($query){
            return $this->ModelHelper(true,false,'',$query->result_array());
        }
        else{
            return $this->ModelHelper(false,true,"DB error!");   
        }
    }

    //For packages
    public function Packages($business_admin_id){

        $sql = "SELECT * FROM mss_packages";

        $query = $this->db->query($sql);
        
        if($query){
            return $this->ModelHelper(true,false,'',$query->result_array());
        }
        else{
            return $this->ModelHelper(false,true,"DB error!");   
        }
    }
 

}