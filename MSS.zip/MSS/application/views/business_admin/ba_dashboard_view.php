<?php
	$this->load->view('business_admin/ba_header_view');
?>
<div class="wrapper">
	<?php
		$this->load->view('business_admin/ba_nav_view');
	?>
	<div class="main">
		<?php
			$this->load->view('business_admin/ba_top_nav_view');
		?>	
		<main class="content">
			<div class="container-fluid p-0">
				<div class="row">
					<?php
					// print_r($business_outlet_details);
					// exit;
						if(empty($business_outlet_details)){
						
					?>	
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title">Add Outlets</h5>
								</div>
								<div class="card-body">
									<p>Please add outlet to proceed.</p>
								</div>
							</div>
						</div>
					<?php
						}
						
						if(!isset($selected_outlet)){
					?>
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title">Select Outlet</h5>
								</div>
								<div class="card-body">
									<p>Please select outlet to proceed.</p>
								</div>
							</div>
						</div>
					<?php
						}
						else{
					?>
					<div class="col-md-2 col-sm-6">
						<div class="card ">
							<div class="card-body py-4">
								<div class="media">
									<div class="d-inline-block mt-2 mr-3">
										<i class="fas fa-rupee-sign fa-2x text-success" data-feather=""></i>
									</div>
									<div class="media-body">
										<div class="mb-0">Sales Today</div>
										<h3 class="mb-2">2.562</h3>
										
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-2 col-sm-6">
						<div class="card ">
							<div class="card-body py-4">
								<div class="media">
									<div class="d-inline-block mt-2 mr-3">
										<i class="fa fa-users fa-2x text-warning" data-feather="activity"></i>
									</div>
									<div class="media-body">
										<div class="mb-0">MTD Total</div>
										<h3 class="mb-2">17.212</h3>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-2 col-sm-6">
						<div class="card">
							<div class="card-body py-4">
								<div class="media">
									<div class="d-inline-block mt-2 mr-3">
										<i class="fa fa-users fa-2x text-success" data-feather=""></i>
									</div>
									<div class="media-body">
										<div class="mb-0">MTD new</div>
										<h3 class="mb-2">24.300</h3>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-2 col-sm-6">
						<div class="card ">
							<div class="card-body py-4">
								<div class="media">
									<div class="d-inline-block mt-2 mr-3">
										<i class="fa fa-users fa-2x text-danger" data-feather=""></i>
									</div>
									<div class="media-body">
										<div class="mb-0">MTD Ext</div>
										<h3 class="mb-2">43</h3>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-2 col-sm-6">
						<div class="card">
							<div class="card-body py-4">
								<div class="media">
									<div class="d-inline-block mt-2 mr-3">
										<i class="fa paw fa-2x text-info" data-feather="dollar-sign"></i>
									</div>
									<div class="media-body">
										<div class="mb-0">No. Of Visits</div>
										<h3 class="mb-2">18</h3>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!--  -->
					<div class="col-md-2 col-sm-6">
						<div class="card">
							<div class="card-body py-4">
								<div class="media">
									<div class="d-inline-block mt-2 mr-3">
										<i class="fa fa-rupee-sign fa-2x text-success" data-feather="dollar-sign"></i>
									</div>
									<div class="media-body">
										<div class="mb-0">FTD Sales</div>
										<h3 class="mb-2">18.700</h3>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!--  -->
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="card flex-fill w-100">
							<div class="card-header">
								<h5 class="card-title mb-0">Select KPI</h5>
								<div class="float-left">
									<select>
										<option>Revenue</option>
										<option>Visits</option>
										<option>Service / OTC Revenue</option>
										<option>Revenue / Customer</option>
										<option>Revenue / Visits</option>
									</select>
								</div>
								<div class="float-right">
									<button class="btn btn-primary ">Daily</button>&emsp;
									<button class="btn btn-primary ">Weekly</button>&emsp;
									<button class="btn btn-primary ">Monthly</button>
								</div>
							</div>
							<div class="card-body">
								<div class="chart chart-lg">
									<canvas id="chartjs-dashboard-line"></canvas>
								</div>
							</div>
						</div>
					</div>
					<!-- <div class="col-12 col-lg-4 d-flex">
						<div class="card flex-fill w-100">
							<div class="card-header">
								<span class="badge badge-info float-right">Today</span>
								<h5 class="card-title mb-0">Daily feed</h5>
							</div>
							<div class="card-body">
								<div class="media">
									<img src="img/avatars/avatar-5.jpg" width="36" height="36" class="rounded-circle mr-2" alt="Ashley Briggs">
									<div class="media-body">
										<small class="float-right text-navy">5m ago</small>
										<strong>Ashley Briggs</strong> started following <strong>Stacie Hall</strong><br />
										<small class="text-muted">Today 7:51 pm</small><br />
									</div>
								</div>
								<hr />
								<div class="media">
									<img src="img/avatars/avatar.jpg" width="36" height="36" class="rounded-circle mr-2" alt="Chris Wood">
									<div class="media-body">
										<small class="float-right text-navy">30m ago</small>
										<strong>Chris Wood</strong> posted something on <strong>Stacie Hall</strong>'s timeline<br />
										<small class="text-muted">Today 7:21 pm</small>
										<div class="border text-sm text-muted p-2 mt-1">
											Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing...
										</div>
									</div>
								</div>

								<hr />
								<div class="media">
									<img src="img/avatars/avatar-4.jpg" width="36" height="36" class="rounded-circle mr-2" alt="Stacie Hall">
									<div class="media-body">
										<small class="float-right text-navy">1h ago</small>
										<strong>Stacie Hall</strong> posted a new blog<br />

										<small class="text-muted">Today 6:35 pm</small>
									</div>
								</div>

								<hr />
								<a href="#" class="btn btn-primary btn-block">Load more</a>
							</div>
						</div>
					</div> -->
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="card flex-fill w-100">
							<div class="card-header">
								<h5 class="card-title mb-0">Select KPI</h5>
								<div class="float-left">
									<select>
										<option>Revenue</option>
										<option>Customer</option>
										<option>Visits</option>
										
									</select>
								</div>
								<div class="float-right">
									<select>
										<option>Category</option>
										<option>Category</option>
										<option>Category</option>
										</select>
									<select>
									<option>Sub-Category</option>
										<option>Sub-Category</option>
										<option>Sub-Category</option>
									</select>
									<select>
										<option>Service</option>
										<option>Service</option>
										<option>Service</option>
									</select>
									<select>
										<option>OTC Revenue</option>
										<option>OTC Revenue</option>
										<option>OTC Revenue</option></select>
								</div>
							</div>
							<div class="card-body">
						<div class="chart chart-lg">
							<canvas id="chartjs-dashboard-bar"></canvas>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="card flex-fill w-100">
						<div class="card-header">
							<h5 class="card-title mb-0">Day-Wise</h5>								
						</div>
						<div class="card-body">
							<div class="chart chart-lg">
								<canvas id="chartjs-dashboard-bar2"></canvas>
							</div>					
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<div class="card flex-fill w-100">
							<div class="card-header">
								<h5 class="card-title mb-0">DashBoard Gender-Wise</h5>							
							</div>
							<div class="card-body">
								<div class="chart chart-lg">
									<canvas id="chartjs-dashboard-pie"></canvas>
								</div>					
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="card flex-fill w-100">
							<div class="card-header">
								<h5 class="card-title mb-0">DashBoard Age Group-Wise</h5>							
							</div>
							<div class="card-body">
								<div class="chart chart-lg">
									<canvas id="chartjs-dashboard-pie2"></canvas>								
								</div>													
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="card flex-fill w-100">
						<div class="card-header">
							<h5 class="card-title mb-0">Low Stock Items(Top 5)</h5>
							<h4 style="color:red;">Re-Ordering required</h4>								
						</div>
						<div class="card-body">
							<div class="chart chart-lg">
								<canvas id="chartjs-dashboard-bar3"></canvas>
							</div>					
						</div>
					</div>
				</div>
			</div>	
			<?php
				}
			?>
		</main>
<?php
	$this->load->view('business_admin/ba_footer_view');
?>
<script>
	$(function() {
		// Bar chart
		new Chart(document.getElementById("chartjs-dashboard-bar"), {
			type: "bar",
			data: {
				labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
				datasets: [{
					label: "Last year",
					backgroundColor: window.theme.primary,
					borderColor: window.theme.primary,
					hoverBackgroundColor: window.theme.primary,
					hoverBorderColor: window.theme.primary,
					data: [54, 67, 41, 55, 62, 45, 55, 73, 60, 76, 48, 79]
				}, {
					label: "This year",
					backgroundColor: "#bcb321",
					borderColor: "#E8EAED",
					hoverBackgroundColor: "#E8EAED",
					hoverBorderColor: "#E8EAED",
					data: [69, 66, 24, 48, 52, 51, 44, 53, 62, 79, 51, 68]
				}]
			},
			options: {
				maintainAspectRatio: false,
				legend: {
					display: true
				},
				scales: {
					yAxes: [{
						gridLines: {
							display: false
						},
						stacked: false,
						ticks: {
							stepSize: 20
						}
					}],
					xAxes: [{
						barPercentage: .75,
						categoryPercentage: .5,
						stacked: false,
						gridLines: {
							color: "transparent"
						}
					}]
				}
			}
		});
	});
</script>
<script>
	$(function() {
		// Bar chart
		new Chart(document.getElementById("chartjs-dashboard-bar2"), {
			type: "bar",
			data: {
				labels: ["Monday", "Tuesday", "Wednesday", "Thirsday", "Friday", "Saturday","Sunday"],
				datasets: [{
					label: "Revenue",
					backgroundColor: window.theme.primary,
					borderColor: window.theme.primary,
					hoverBackgroundColor: window.theme.primary,
					hoverBorderColor: window.theme.primary,
					data: [54, 67, 41, 55, 62, 45, 55]
				}, {
					label: "Customer",
					backgroundColor: "red",
					borderColor: "#E8EAED",
					hoverBackgroundColor: "#E8EAED",
					hoverBorderColor: "#E8EAED",
					data: [69, 66, 24, 48, 52, 51, 44]
				}
				, {
					label: "Visits",
					backgroundColor: "darkgray",
					borderColor: "#E8EAED",
					hoverBackgroundColor: "#E8EAED",
					hoverBorderColor: "#E8EAED",
					data: [69, 66, 24, 48, 52, 51, 44]
				}]
			},
			options: {
				maintainAspectRatio: false,
				legend: {
					display: true
				},
				scales: {
					yAxes: [{
						gridLines: {
							display: false
						},
						stacked: false,
						ticks: {
							stepSize: 20
						}
					}],
					xAxes: [{
						barPercentage: .75,
						categoryPercentage: .5,
						stacked: false,
						gridLines: {
							color: "transparent"
						}
					}]
				}
			}
		});
	});
</script>
<script>
	$(function() {
		$("#datetimepicker-dashboard").datetimepicker({
			inline: true,
			sideBySide: false,
			format: "L"
		});
	});
</script>
<script>
	$(function() {
		// Bar chart
		new Chart(document.getElementById("chartjs-dashboard-bar3"), {
			type: "bar",
			data: {
				labels: ["Facewash", "Shampoo", "Soap", "Himalaya Facewash", "Hair Color"],
				datasets: [{
					label: "Quantity (In Numbers)",
					backgroundColor: window.theme.primary,
					borderColor: window.theme.primary,
					hoverBackgroundColor: window.theme.primary,
					hoverBorderColor: window.theme.primary,
					data: [15, 17, 8, 5, 6, 5, 12]
				}]
			},
			options: {
				maintainAspectRatio: false,
				legend: {
					display: true
				},
				scales: {
					yAxes: [{
						gridLines: {
							display: false
						},
						stacked: false,
						ticks: {
							stepSize: 10
						}
					}],
					xAxes: [{
						barPercentage: .75,
						categoryPercentage: .5,
						stacked: false,
						gridLines: {
							color: "transparent"
						}
					}]
				}
			}
		});
	});
</script>
<script>
	$(function() {
		$("#datetimepicker-dashboard").datetimepicker({
			inline: true,
			sideBySide: false,
			format: "L"
		});
	});
</script>
<script>
	$(function() {
		// Line chart
		new Chart(document.getElementById("chartjs-dashboard-line"), {
			type: "line",
			data: {
				labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
				datasets: [{
					label: "Sales ($)",
					fill: true,
					backgroundColor: "transparent",
					borderColor: window.theme.primary,
					data: [2015, 1465, 1487, 1796, 1387, 2123, 2866, 2548, 3902, 4938, 3917, 4927]
				}, {
					label: "Orders",
					fill: true,
					backgroundColor: "transparent",
					borderColor: window.theme.tertiary,
					borderDash: [4, 4],
					data: [928, 734, 626, 893, 921, 1202, 1396, 1232, 1524, 2102, 1506, 1887]
				}]
			},
			options: {
				maintainAspectRatio: false,
				legend: {
					display: false
				},
				tooltips: {
					intersect: false
				},
				hover: {
					intersect: true
				},
				plugins: {
					filler: {
						propagate: false
					}
				},
				scales: {
					xAxes: [{
						reverse: true,
						gridLines: {
							color: "rgba(0,0,0,0.05)"
						}
					}],
					yAxes: [{
						ticks: {
							stepSize: 500
						},
						display: true,
						borderDash: [5, 5],
						gridLines: {
							color: "rgba(0,0,0,0)",
							fontColor: "#fff"
						}
					}]
				}
			}
		});
	});
</script>
<script>
	$(function() {
		// Pie chart
		new Chart(document.getElementById("chartjs-dashboard-pie"), {
			type: "pie",
			data: {
				labels: ["Male", "Female", "Others"],
				datasets: [{
					data: [2602, 1253, 541],
					backgroundColor: [
						window.theme.primary,
						window.theme.warning,
						window.theme.danger,
						"#E8EAED"
					],
					borderColor: "transparent"
				}]
			},
			options: {
				responsive: !window.MSInputMethodContext,
				maintainAspectRatio: false,
				legend: {
					display: false
				}
			}
		});
	});
</script>
<script>
	$(function() {
		// Pie chart
		new Chart(document.getElementById("chartjs-dashboard-pie2"), {
			type: "pie",
			data: {
				labels: ["< 18 Years", "18-25 years", "25-35 years","35-45 years","45-60 years","> 60 years"],
				datasets: [{
					data: [2602, 1253, 541,453,346,260],
					backgroundColor: [
						window.theme.primary,
						window.theme.warning,
						window.theme.danger,
						window.theme.success,
						window.theme.secondary,
						window.theme.info,
						"#E8EAED"
					],
					borderColor: "transparent"
				}]
			},
			options: {
				responsive: !window.MSInputMethodContext,
				maintainAspectRatio: false,
				legend: {
					display: false
				}
			}
		});
	});
</script>
<script>
	$(function() {
		$("#datatables-dashboard-projects").DataTable({
			pageLength: 6,
			lengthChange: false,
			bFilter: false,
			autoWidth: false
		});
	});
</script>