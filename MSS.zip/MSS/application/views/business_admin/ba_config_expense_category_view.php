<?php
	$this->load->view('business_admin/ba_header_view');
?>
<div class="wrapper">
	<?php
		$this->load->view('business_admin/ba_nav_view');
	?>
	<div class="main">
		<?php
			$this->load->view('business_admin/ba_top_nav_view');
		?>
		<main class="content">
			<div class="container-fluid p-0">
				<h1 class="h3 mb-3">Expense Management</h1>
				<div class="row">
					<?php
						if(empty($business_outlet_details)){
					?>	
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title">Add Outlets</h5>
								</div>
								<div class="card-body">
									<p>Please add outlet to proceed.</p>
								</div>
							</div>
						</div>
					<?php
						}

						if(!isset($selected_outlet)){
					?>
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title">Select Outlet</h5>
								</div>
								<div class="card-body">
									<p>Please select outlet to proceed.</p>
								</div>
							</div>
						</div>
					<?php
						}
						else{
					?>
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h5 class="card-title">Add Expense Category</h5>
							</div>
							<div class="card-body">
								<!-- Modals -->
								<div class="modal fade" id="defaultModalSuccess" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title">Success</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    			<span aria-hidden="true">&times;</span>
                 			 	</button>
											</div>
											<div class="modal-body m-3">
												<p class="mb-0" id="SuccessModalMessage"><p>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>

								<div class="modal fade" id="ModalAddExpenseCategory" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title">Add Expense Category</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		                      <span aria-hidden="true">&times;</span>
		                    </button>
											</div>
											<div class="modal-body m-3">
												<div class="row">
													<div class="col-md-12">
														<form id="AddExpenseCategory" method="POST" action="#">
															<div class="form-group">
																<label>Category Name</label>
																<input type="text" class="form-control" placeholder="Category Name" name="expense_type">
															</div>
															<div class="form-group">
																<label>Description</label>
																<textarea class="form-control" placeholder="Description" name="expense_type_description"></textarea>
															</div>
															<button type="submit" class="btn btn-primary">Submit</button>
														</form>
														<div class="alert alert-dismissible feedback mt-2" role="alert">
															<button type="button" class="close" data-dismiss="alert" aria-label="Close">
																<span aria-hidden="true">&times;</span>
									            </button>
															<div class="alert-message">
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>

								<div class="modal fade" id="ModalEditExpenseCategory" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title">Edit Expense Category</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		                      <span aria-hidden="true">&times;</span>
		                    </button>
											</div>
											<div class="modal-body m-3">
												<div class="row">
													<div class="col-md-12">
														<form id="EditExpenseCategory" method="POST" action="#">
															<div class="form-group">
																<label>Category Name</label>
																<input type="text" class="form-control" placeholder="Category Name" name="expense_type">
															</div>
															<div class="form-group">
																<label>Description</label>
																<textarea class="form-control" placeholder="Description" name="expense_type_description"></textarea>
															</div>
															<div class="form-group">
					                      <input class="form-control" type="hidden" name="expense_type_id" readonly="true">
					                    </div>
															<button type="submit" class="btn btn-primary">Submit</button>
														</form>
														<div class="alert alert-dismissible feedback mt-2" role="alert">
															<button type="button" class="close" data-dismiss="alert" aria-label="Close">
																<span aria-hidden="true">&times;</span>
									            </button>
															<div class="alert-message">
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>

								<!-----END------>
								<button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#ModalAddExpenseCategory"><i class="fas fa-fw fa-plus"></i>Add Expense Category</button>
								<table class="table table-hover table-responsive mt-3">
									<thead>
										<tr>
											<th>Category Code</th>
											<th>Name</th>
											<th>Description</th>
											<th>Actions</th>
										</tr>
									</thead>
									<tbody>
										<?php
											foreach ($expense_types as $type):
										?>
										<tr>
											<td><?=$type['expense_type_id']?></td>
											<td><?=$type['expense_type']?></td>
											<td><?=$type['expense_type_description']?></td>
											<td class="table-action">
												<button type="button" class="btn btn-primary expense-type-edit-btn" expense_type_id="<?=$type['expense_type_id']?>">
									        <i class="align-middle" data-feather="edit-2"></i>
									      </button>
											</td>
										</tr>	
										<?php		
											endforeach;
										?>
									</tbody>
								</table>
							</div>
						</div>	
					</div>
					<div class="col-md-3">
					<div class="card text-center h-100" style="border-color:green;">
						<div class="card-body d-flex flex-column">
							<div class="row">
								<div class="col-md-7 text-left">
									<h4>Virat </h4>
								</div>
								<div class="col-md-5">
									<h6 style="color:red;">package</h6>
								</div>
								
							</div>
							<div class="row">
								<div class="col-md-12 text-left">
									<ul class="list-unstyled justify">
										<li>9988776655</li>
										<li style="color:red">Due Amount : 3500</li>
										<li>Wallet Balance: Rs. 300</li>
									</ul>
							</div>
										
							</div>
							<div class="row">
							<div class="col-md-6">
							<!-- <div class="mt-auto"> -->
								<a href="#" class="btn btn-lg btn-outline-primary">Bill-it</a>
							<!-- </div> -->
							</div>
							<div class="col-md-6">
							<div class="mt-auto">
								<a href="#" class="btn btn-lg btn-outline-primary">view</a>
							</div>
							</div>		
							</div>
						</div>
					</div>
				</div>
					<?php
						}
					?>
				</div>
			</div>
		</main>
<?php
	$this->load->view('business_admin/ba_footer_view');
?>
<script type="text/javascript">
	$(document).ready(function(){
	
		$(document).ajaxStart(function() {
      $("#load_screen").show();
    });

    $(document).ajaxStop(function() {
      $("#load_screen").hide();
    });
	  	
  	$("#AddExpenseCategory").validate({
	  	errorElement: "div",
	    rules: {
	        "expense_type" : {
            required : true,
            maxlength : 100
	        }  
	    },
	    submitHandler: function(form) {
				var formData = $("#AddExpenseCategory").serialize(); 
				$.ajax({
		        url: "<?=base_url()?>index.php/BusinessAdmin/AddExpenseCategory/",
		        data: formData,
		        type: "POST",
		        crossDomain: true,
						cache: false,
		        dataType : "json",
		    		success: function(data) {
              if(data.success == 'true'){ 
              	$("#ModalAddExpenseCategory").modal('hide');
								$('#defaultModalSuccess').modal('show').on('shown.bs.modal', function (e) {
									$("#SuccessModalMessage").html("").html(data.message);
								}).on('hidden.bs.modal', function (e) {
										window.location.reload();
								});
              }
              else if (data.success == 'false'){                   
          	    if($('.feedback').hasClass('alert-success')){
                  $('.feedback').removeClass('alert-success').addClass('alert-danger');
                }
                else{
                  $('.feedback').addClass('alert-danger');
                }
                $('.alert-message').html("").html(data.message); 
              }
            },
            error: function(data){
    					$('.feedback').addClass('alert-danger');
    					$('.alert-message').html("").html(data.message); 
            }
				});
			},
		});

		$("#EditExpenseCategory").validate({
	  	errorElement: "div",
	    rules : {
      	"expense_type" : {
      	  required : true,
        	maxlength : 100
      	}
      },
	    submitHandler: function(form) {
				var formData = $("#EditExpenseCategory").serialize(); 
				$.ajax({
		        url: "<?=base_url()?>index.php/BusinessAdmin/EditExpenseCategory/",
		        data: formData,
		        type: "POST",
		        crossDomain: true,
						cache: false,
		        dataType : "json",
		    		success: function(data) {
              if(data.success == 'true'){
              	$("#ModalEditExpenseCategory").modal('hide');
								$('#defaultModalSuccess').modal('show').on('shown.bs.modal', function (e) {
									$("#SuccessModalMessage").html("").html(data.message);
								}).on('hidden.bs.modal', function (e) {
										window.location.reload();
								});
              }
              else if (data.success == 'false'){                   
          	    if($('.feedback').hasClass('alert-success')){
                  $('.feedback').removeClass('alert-success').addClass('alert-danger');
                }
                else{
                  $('.feedback').addClass('alert-danger');
                }
                $('.alert-message').html("").html(data.message); 
              }
            },
            error: function(data){
    					$('.feedback').addClass('alert-danger');
    					$('.alert-message').html("").html(data.message); 
            }
				});
			},
		});

		$('.expense-type-edit-btn').click(function(event) {
      event.preventDefault();
      this.blur(); // Manually remove focus from clicked link.
      var parameters = {
        expense_type_id : $(this).attr('expense_type_id')
      };
      $.getJSON("<?=base_url()?>index.php/BusinessAdmin/GetExpenseType/", parameters)
      .done(function(data, textStatus, jqXHR) { 
        $("#EditExpenseCategory input[name=expense_type]").attr('value',data.expense_type);
        $("#EditExpenseCategory textarea[name=expense_type_description]").val(data.expense_type_description);
        $("#EditExpenseCategory input[name=expense_type_id]").attr('value',data.expense_type_id);

        $("#ModalEditExpenseCategory").modal('show');
    	})
    	.fail(function(jqXHR, textStatus, errorThrown) {
        console.log(errorThrown.toString());
   		});
    });

  });
</script>