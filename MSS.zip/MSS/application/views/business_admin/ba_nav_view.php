<nav class="sidebar">
	<div class="sidebar-content">
		<a class="sidebar-brand" href="<?=base_url()?>index.php/BusinessAdmin/">
 		 <i class="align-middle" data-feather="box"></i>
	     <span class="align-middle">MarksSalonSolution</span>
        </a>

		<ul class="sidebar-nav">
			<li class="sidebar-header">
				Dashboard
			</li>
			<?php
				if(array_search('POS System', $business_admin_packages) !== false):
			?>
			<li class="sidebar-item">
				<a href="#dashboards" data-toggle="collapse" class="sidebar-link collapsed">
				<i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Business Panel</span>
				</a>
				<ul id="dashboards" class="sidebar-dropdown list-unstyled collapse show">
					<li class="sidebar-item"><a class="sidebar-link" href="<?=base_url()?>index.php/BusinessAdmin/Dashboard/">Dashboard</a></li>
					<li class="sidebar-item">
						<a href="#configurations" data-toggle="collapse" class="sidebar-link collapsed">
		          <span class="align-middle">Configurations</span>
		        </a>
		        <ul id="configurations" class="sidebar-dropdown list-unstyled collapse show">
		        	<li class="sidebar-item"><a class="sidebar-link" href="<?=base_url()?>index.php/BusinessAdmin/AddOutlet/">Outlets</a></li>
			    		<li class="sidebar-item"><a class="sidebar-link" href="<?=base_url()?>index.php/BusinessAdmin/Inventory/">Inventory</a></li>
			    		<li class="sidebar-item"><a class="sidebar-link" href="<?=base_url()?>index.php/BusinessAdmin/MenuManagement/">Menu Management</a></li>
			    		<li class="sidebar-item"><a class="sidebar-link" href="<?=base_url()?>index.php/BusinessAdmin/AddEmployee/">Employee</a></li>
						<li class="sidebar-item"><a class="sidebar-link" href="<?=base_url()?>index.php/BusinessAdmin/ConfigExpense/">Expense</a></li>
						<li class="sidebar-item"><a class="sidebar-link" href="<?=base_url()?>index.php/BusinessAdmin/packages/">Packages</a></li>
						<li class="sidebar-item"><a class="sidebar-link" href="<?=base_url()?>index.php/BusinessAdmin/expenses/">Expense Tracker</a></li>
			    	</ul>
					</li>
					<li class="sidebar-item"><a class="sidebar-link" href="dashboard-e-commerce.html">Reports</a></li>
				</ul>
			</li>
			<?php
				endif;

				if(array_search('Customer Analytics', $business_admin_packages) !== false):
			?>
			<li class="sidebar-item">
				<a href="#pages" data-toggle="collapse" class="sidebar-link collapsed">
		          <i class="align-middle" data-feather="layout"></i> <span class="align-middle">Engagement</span>
		        </a>
				<ul id="pages" class="sidebar-dropdown list-unstyled collapse ">
					<li class="sidebar-item"><a class="sidebar-link" href="pages-profile.html">Customer</a></li>
					<li class="sidebar-item"><a class="sidebar-link" href="pages-settings.html">Tags</a></li>
					<li class="sidebar-item"><a class="sidebar-link" href="pages-clients.html">Campaign Manager</a></li>
					<li class="sidebar-item"><a class="sidebar-link" href="pages-invoice.html">Deals & Discount</a></li>
					<li class="sidebar-item"><a class="sidebar-link" href="pages-pricing.html">Auto-Engage</a></li>
					<li class="sidebar-item"><a class="sidebar-link" href="pages-kanban.html">Packages</a></li>
					<li class="sidebar-item"><a class="sidebar-link" href="pages-blank.html">Loyalty</a></li>
				</ul>
			</li>
			<?php
				endif;
			?>
			<li class="sidebar-header">
				Other Options
			</li>
			<li class="sidebar-item">
				<a href="#ui" data-toggle="collapse" class="sidebar-link collapsed">
		          <i class="align-middle" data-feather="grid"></i> <span class="align-middle">Settings</span>
		        </a>
				<ul id="ui" class="sidebar-dropdown list-unstyled collapse ">
					<li class="sidebar-item"><a class="sidebar-link" href="<?=base_url()?>index.php/BusinessAdmin/Logout/">Logout</a></li>
					<li class="sidebar-item"><a class="sidebar-link" href="<?=base_url()?>index.php/BusinessAdmin/Profile/">Profile</a></li>
					<li class="sidebar-item"><a class="sidebar-link" href="<?=base_url()?>index.php/BusinessAdmin/ResetPassword/">Reset Password</a></li>
				</ul>
			</li>
		</ul>
		<div class="sidebar-bottom d-none d-lg-block">
			<div class="media">
				<img class="rounded-circle mr-3" src="<?=base_url()?>public/images/default.png" alt="Business Admin" width="40" height="40">
				<div class="media-body">
					<h5 class="mb-1"><?=$business_admin_details['business_admin_first_name']?></h5>
					<div>
						<i class="fas fa-circle text-success"></i> Online
					</div>
				</div>
			</div>
		</div>
	</div>
</nav>