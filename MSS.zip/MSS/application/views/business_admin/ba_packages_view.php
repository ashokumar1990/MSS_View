<?php
	$this->load->view('business_admin/ba_header_view');
?>
<div class="wrapper">
	<?php
		$this->load->view('business_admin/ba_nav_view');
	?>
	<div class="main">
		<?php
			$this->load->view('business_admin/ba_top_nav_view');
		?>
		<main class="content">
			<div class="container-fluid p-0">
				<h1 class="h3 mb-3">Package Management</h1>
				<div class="row">
					<div class="col-md-12">
						<div class="card flex-fill w-100">
							<div class="card-header">
								<h5 class="card-title mb-0">Select KPI</h5>
								
								<div class="float-left">
									<select>
										<option>Revenue</option>
										<option>Visits</option>
										<option>Service / OTC Revenue</option>
										<option>Revenue / Customer</option>
										<option>Revenue / Visits</option>
									</select>
								</div>
								
								<div class="float-right">
									<button class="btn btn-primary ">Daily</button>&emsp;
									<button class="btn btn-primary ">Weekly</button>&emsp;
									<button class="btn btn-primary ">Monthly</button>
								</div>
							</div>
							<div class="card-body">
								<div class="chart chart-lg">
									<canvas id="chartjs-dashboard-line"></canvas>
								</div>
							</div>
						</div>
					</div>					
				</div>
				<div class="row">
					<?php
						if(empty($business_outlet_details)){
					?>	
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h5 class="card-title">Add Outlets</h5>
							</div>
							<div class="card-body">
								<p>Please add outlet to proceed.</p>
							</div>
						</div>
					</div>
					<?php
						}

						if(!isset($selected_outlet)){
					?>
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h5 class="card-title">Select Outlet</h5>
							</div>
							<div class="card-body">
								<p>Please select outlet to proceed.</p>
							</div>
						</div>
					</div>
					<?php
						}
						else{
					?>
					<!--  -->
					
					<!--  -->
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h5 class="card-title">Your Packages</h5>
							</div>
							<div class="card-body">
								<div class="card">
									<div class="card-header">
										<div class="row">
											<div class="col-md-6">
												<h4>Active Packages</h4>
											</div>								
											<div class="col-md-6">
												<button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#ModalAddPackage" style="margin-left:10vw;"><i class="fas fa-fw fa-plus"></i> Create New Package</button>
											</div>
										</div>
									</div>
									<div class="card-body">
										<div class="tab-content" >
											<div class="tab-pane fade show active" id="tab-1" role="tabpanel">		
												<table class="table fixed_header">
													<thead>
														<tr class="text-primary">
															<th>Package Id</th>
															<th>Package	 Name</th>
															<th>Package Type</th>
															<th>Creation Date</th>
															<th>Current Status</th>
															<th>Upfront Amount</th>
															<th>Validity (Months)</th>
															<th>Discount %</th>
															<th>Discount Rs.</th>
															<th>Service Count</th>
															<th>V.W. Multiplier</th>
															<th>V.W. Amount</th>
														</tr>
													</thead>
													<tbody>
														<?php
															foreach ($customer_packages as $package):
														?>
														<tr>
															<td><?=$package['package_id']?></td>
															<td><?=$package['package_name']?></td>
															<td><?=$package['package_type']?></td>
															<td><?=$package['creation_date']?></td>
															<td><?=$package['status']?></td>
															<td><?=$package['upfront_amount']?></td>
															<td><?=$package['validity']?></td>
															<td><?=$package['discount_rs']?></td>
															<td><?=$package['discount_percent']?></td>
															<td><?=$package['service_count']?></td>
															<td><?=$package['wallet_multiplier']?></td>
															<td><?=$package['virtual_amount']?></td>
														</tr>	
														<?php		
															endforeach;
														?>
													</tbody>
												</table>
											</div>
											
											
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div> <!-- End row-->
				<!-- Customer List table-->
				<div class="col-12">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title">Customer List</h5>
									
								</div>
								<div class="card-body">
								<div class="row">
									<div class="col-md-6">
									<button class="btn btn-primary btn-md" onclick="exportTableToExcel('datatables-buttons')">Export</button>
								</div>
								</div>
										<table id="datatables-buttons" class="table table-striped" style="width:100%">
									
										<thead>
											<tr>
												<th>Name</th>
												<th>Contact No.</th>
												<th>Package</th>
												<th>Last Visit</th>
												<th>Next Visit</th>
												<th>Total Services</th>
												<th>Services Allowed</th>
												<th>Services Availed</th>
												<th>Balance Services</th>
												<th>Expiry Date</th>
												<th>Amount Paid</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td>Tiger Nixon</td>
												<td>System Architect</td>
												<td>Edinburgh</td>
												<td>61</td>
												<td>2011/04/25</td>
												<td>RS.320,800</td>
												<td>System Architect</td>
												<td>Edinburgh</td>
												<td>61</td>
												<td>2011/04/25</td>
												<td>RS.320,800</td>
											</tr>
											<tr>
												<td>Garrett Winters</td>
												<td>Accountant</td>
												<td>Tokyo</td>
												<td>63</td>
												<td>2011/07/25</td>
												<td>RS.170,750</td>
												<td>System Architect</td>
												<td>Edinburgh</td>
												<td>61</td>
												<td>2011/04/25</td>
												<td>RS.320,800</td>
											</tr>
											<tr>
												<td>Ashton Cox</td>
												<td>Junior Technical Author</td>
												<td>San Francisco</td>
												<td>66</td>
												<td>2009/01/12</td>
												<td>RS.86,000</td>
												<td>System Architect</td>
												<td>Edinburgh</td>
												<td>61</td>
												<td>2011/04/25</td>
												<td>RS.320,800</td>
											</tr>
											<tr>
												<td>Cedric Kelly</td>
												<td>Senior Javascript Developer</td>
												<td>Edinburgh</td>
												<td>22</td>
												<td>2012/03/29</td>
												<td>RS.433,060</td>
												<td>System Architect</td>
												<td>Edinburgh</td>
												<td>61</td>
												<td>2011/04/25</td>
												<td>RS.320,800</td>
											</tr>
											<tr>
												<td>Airi Satou</td>
												<td>Accountant</td>
												<td>Tokyo</td>
												<td>33</td>
												<td>2008/11/28</td>
												<td>RS.162,700</td>
												<td>System Architect</td>
												<td>Edinburgh</td>
												<td>61</td>
												<td>2011/04/25</td>
												<td>RS.320,800</td>
											</tr>
											<tr>
												<td>Brielle Williamson</td>
												<td>Integration Specialist</td>
												<td>New York</td>
												<td>61</td>
												<td>2012/12/02</td>
												<td>RS.372,000</td>
												<td>System Architect</td>
												<td>Edinburgh</td>
												<td>61</td>
												<td>2011/04/25</td>
												<td>RS.320,800</td>
											</tr>
											<tr>
												<td>Herrod Chandler</td>
												<td>Sales Assistant</td>
												<td>San Francisco</td>
												<td>59</td>
												<td>2012/08/06</td>
												<td>RS.137,500</td>
												<td>System Architect</td>
												<td>Edinburgh</td>
												<td>61</td>
												<td>2011/04/25</td>
												<td>RS.320,800</td>
											</tr>
											<tr>
												<td>Rhona Davidson</td>
												<td>Integration Specialist</td>
												<td>Tokyo</td>
												<td>55</td>
												<td>2010/10/14</td>
												<td>RS.327,900</td>
												<td>System Architect</td>
												<td>Edinburgh</td>
												<td>61</td>
												<td>2011/04/25</td>
												<td>RS.320,800</td>
											</tr>
											
											
										</tbody>
									</table>
								</div>
							</div>
						</div>
				<!-- end customer table -->
				<div class="row">
					<div class="col-md-12">
						<div class="card">
							<!-- <div class="card-header">
								<button class="btn btn-primary btn-lg">Customer List</button>
							</div> -->
							<!-- <div class="card-body"> -->
								<!-- Modals -->
								<div class="modal fade" id="defaultModalSuccess" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title">Success</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
											</div>
											<div class="modal-body m-3">
												<p class="mb-0" id="SuccessModalMessage"><p>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>

								<div class="modal fade" id="ModalAddPackage" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header" style="background-color:#47bac1">
												<h5 class="modal-title font-weight-bold">Add Package</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
												<span aria-hidden="true">&times;</span>
												</button>
											</div>
											<div class="modal-body m-3">
												<div class="row">
													<div class="col-md-12">
														<form id="AddPackage" method="POST" action="#">
															<div class="row">
																<div class="form-group col-md-6">
																	<label>Package Name</label>
																	<input type="text" class="form-control" placeholder="Package Name" name="package_name" autofocus>
																</div>
																<div class="form-group col-md-6">
																	<label>Upfront Amount  </label>
																	<input class="form-control" placeholder="Upfront Amount in Rs." name="upfront_amount">
																</div>
															</div>
															<div class="row">
																<div class="form-group col-md-6">
																	<label>Validity</label>
																	<input type="number" class="form-control" placeholder="Period in Months" name="validity">
																</div>
																<div class="form-group col-md-6">
																	<label>Package Type</label><br>
																	<select id="packageType" class="form-control" name="package_type" onchange="togglePackage(this.value)" required="">
																		<option selected="selected" value="none">Select Package Type</option>
																		<option  value="virtual_wallet">Virtual Wallet</option>
																		<option value="services">Services</option>
																		<option value="discount_percent">Discount </option>
																	</select>
																</div>
																<!-- <div class="form-group col-md-6">
																	<label>Services Allowed</label>
																	<input type="number" class="form-control" placeholder="Total Allowed Services" name="services_allowed">
																</div> -->
															</div>
															<div id="virtual_wallet" class="row">

																<div class="form-group col-md-6">
																	<label>Virtual Wallet Loading</label>
																	<input type="number" class="form-control" placeholder="Virtual Wallet Absolute Amount(in Rs)" name="v_ab_discount">&ensp;&ensp;&ensp;
																	<input type="number" class="form-control" placeholder="Virtual Wallet Loading in %" name="percent_discount">
																</div>
																
															</div>
														<div class="row" id="services">
															
																<div class="form-group col-md-3">
																	<label>Category</label>
																	<select class="form-control" name="service_category_id" id="Service_Category_Id">
																		<option value="" selected></option>
																		<?php
																			foreach ($categories as $category) {
																				echo "<option value=".$category['category_id'].">".$category['category_name']."</option>";
																			}
																		?>
																	</select>
																</div>
																<div class="form-group col-md-3">
																	<label>Sub-Category</label>
																	<select class="form-control" name="service_sub_category_id" id="Service_Sub_Category_Id">
																	
																	</select>
																</div>
																<div class="form-group col-md-3">
																	<label>Service</label>
																	<select class="form-control" name="service_sub_category_id" id="Service_Sub_Category_Id">
																		
																	</select>
																</div>
																<div class="form-group col-md-3" style="margin-top:30px;">
																<button class="btn btn-primary fa fa-plus btn-lg">Add</button>
																<!-- <input type="button" id="add" value="Add" onclick="Javascript:addRow()"></td> -->
																</div>
																<!-- <div id="mydata">
																	<b>Current data in the system ...</b>
																	<table id="myTableData"  border="1" cellpadding="2">
																		<tr>
																			<td>&nbsp;</td>
																			<td><b>Cotegory</b></td>
																			<td><b>Sub-Category</b></td>
																			<td><b>Service</b></td>
																		</tr>
																	</table>
																	&nbsp;
																	
																	</div> -->
														</div>
														<div id ="discount" class="row">
														<div class="form-group col-md-6">
																	<label>Discount</label>
																	<input type="number" class="form-control" placeholder="Discount in Rs." name="ab_discount">&ensp;&ensp;&ensp;
																	<input type="number" class="form-control" placeholder="Discount in %" name="percent_discount">
																</div>
														</div>
														<div class="col-md-12">
															<button type="submit" class="btn btn-primary">Submit</button>
															</div>
														</form>
														<div class="alert alert-dismissible feedback mt-2" role="alert">
															<button type="button" class="close" data-dismiss="alert" aria-label="Close">
																<span aria-hidden="true">&times;</span>
									           				</button>
															<div class="alert-message">
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>
								<div class="modal fade" id="defaultModalSuccess" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title">Success</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    			<span aria-hidden="true">&times;</span>
                 			 	</button>
											</div>
											<div class="modal-body m-3">
												<p class="mb-0" id="SuccessModalMessage"><p>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>

								<div class="modal fade" id="ModalEditService" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title">Edit Service</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
												<span aria-hidden="true">&times;</span>
												</button>
											</div>
											<div class="modal-body m-3">
												<div class="row">
													<div class="col-md-12">
														<form id="EditService" method="POST" action="#">
															<div class="form-group">
																<label>Service Name</label>
																<input type="text" class="form-control" placeholder="Service Name" name="service_name">
															</div>
															<div class="form-group">
																<label>Service Gross Price</label>
																<input class="form-control" placeholder="Service Gross Price" name="service_price_inr">
															</div>
															<div class="form-group">
																<label>Service GST Percentage</label>
																<input class="form-control" placeholder="% Value Only" name="service_gst_percentage">
															</div>
															<div class="form-group">
																<label>Service Estimate Time</label>
																<input type="text" class="form-control" placeholder="N Hours/Minutes" name="service_est_time">
															</div>
															<div class="form-group">
																<label>Service Description</label>
																<textarea class="form-control" rows="2" placeholder="Service Description" name="service_description"></textarea>
															</div>
															
															<div class="form-group">
															<input class="form-control" type="hidden" name="service_id" readonly="true">
															</div>
															<button type="submit" class="btn btn-primary">Submit</button>
														</form>
														<div class="alert alert-dismissible feedback mt-2" role="alert">
															<button type="button" class="close" data-dismiss="alert" aria-label="Close">
																<span aria-hidden="true">&times;</span>
									            </button>
															<div class="alert-message">
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								<!-- </div> -->
								<!-- Modal Area Ends -->
							</div>
						</div>
					</div>					
				</div>
							
					<?php
						}
					?>	
					
					
		</main>	
		<?php
						$this->load->view('business_admin/ba_footer_view');
					?>
	</div>
</div>
<script>
function togglePackage(){
		var selectedElement=$('#packageType option:selected').val();
		// alert(selectedElement);
		if(selectedElement=="none"){
			$("#virtual_wallet").hide();
			// $("#virtual_wallet").RemoveAttr("required");
			$("#services").hide();
			// $("#services").RemoveAttr("required");
			$("#discount").hide();
			// $("#discount").RemoveAttr("required");
			
		}
		if(selectedElement=="virtual_wallet")
		{	
			$("#services").hide();
			// $("#services").RemoveAttr("required");
			$("#discount").hide();
			// $("#discount").RemoveAttr("required");
			$("#virtual_wallet").show();
			$("#virtual_wallet").prop("required",true);
			
		}
		if(selectedElement=="services")
		{
			$("#virtual_wallet").hide();
			// $("#virtual_wallet").RemoveAttr("required");
			$("#discount").hide();
			// $("#discount").RemoveAttr("required");
			$("#services").show();
			$("#services").prop("required",true);
		}
		if(selectedElement=="discount_percent"){
			$("#virtual_wallet").hide();
			// $("#virtual_wallet").RemoveAttr("required");
			$("#services").hide();
			// $("#services").RemoveAttr("required");
			$("#discount").show();
			$("#discount").prop("required",true);
		}
		
		
	}

</script>

<script type="text/javascript">
	$(document).ready(function(){
	
		$(document).ajaxStart(function() {
      $("#load_screen").show();
    });

    $(document).ajaxStop(function() {
      $("#load_screen").hide();
    });

		$("#AddPackages").validate({
	  	errorElement: "div",
	    rules: {
	        "package_name" : {
            required : true,
            maxlength : 100
	        },
	        "package_type" :{
	        	required : true,
	        	maxlength : 50
	        },
	        "upfront_amount" : {
				maxlength : 5
	        	required : true,
	        	digits : true
	        },
	        "validity" : {
				maxlength : 5
	        	required : true,
	        	digits : true
	        }
	    },
	    submitHandler: function(form) {
				var formData = $("#AddPackage").serialize(); 
				$.ajax({
		        url: "<?=base_url()?>index.php/BusinessAdmin/packages/",
		        data: formData,
		        type: "POST",
		        crossDomain: true,
						cache: false,
		        dataType : "json",
		    		success: function(data) {
              if(data.success == 'true'){ 
              	$("#ModalAddPackage").modal('hide');
					$('#defaultModalSuccess').modal('show').on('shown.bs.modal', function (e) {
						$("#SuccessModalMessage").html("").html(data.message);
					}).on('hidden.bs.modal', function (e) {
							window.location.reload();
					});
              }
              else if (data.success == 'false'){                   
          	    if($('.feedback').hasClass('alert-success')){
                  $('.feedback').removeClass('alert-success').addClass('alert-danger');
                }
                else{
                  $('.feedback').addClass('alert-danger');
                }
                $('.alert-message').html("").html(data.message); 
              }
            },
            error: function(data){
    					$('.feedback').addClass('alert-danger');
    					$('.alert-message').html("").html(data.message); 
            }
				});
			},
		});	

   
  });
</script>
<script>
	$(function() {
		// Line chart
		new Chart(document.getElementById("chartjs-dashboard-line"), {
			type: "line",
			data: {
				labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
				datasets: [{
					label: "Sales ($)",
					fill: true,
					backgroundColor: "transparent",
					borderColor: window.theme.primary,
					data: [2015, 1465, 1487, 1796, 1387, 2123, 2866, 2548, 3902, 4938, 3917, 4927]
				}, {
					label: "Orders",
					fill: true,
					backgroundColor: "transparent",
					borderColor: window.theme.tertiary,
					borderDash: [4, 4],
					data: [928, 734, 626, 893, 921, 1202, 1396, 1232, 1524, 2102, 1506, 1887]
				}]
			},
			options: {
				maintainAspectRatio: false,
				legend: {
					display: false
				},
				tooltips: {
					intersect: false
				},
				hover: {
					intersect: true
				},
				plugins: {
					filler: {
						propagate: false
					}
				},
				scales: {
					xAxes: [{
						reverse: true,
						gridLines: {
							color: "rgba(0,0,0,0.05)"
						}
					}],
					yAxes: [{
						ticks: {
							stepSize: 500
						},
						display: true,
						borderDash: [5, 5],
						gridLines: {
							color: "rgba(0,0,0,0)",
							fontColor: "#fff"
						}
					}]
				}
			}
		});
	});
</script>
<script>
		$(function() {
			// Datatables basic
			$("#datatables-basic").DataTable({
				responsive: true
			});
			// Datatables with Buttons
			// var datatablesButtons = $("#datatables-buttons").DataTable({
			// 	responsive: true,
			// 	lengthChange: !1,
			// 	buttons: ["copy", "print"]
			// });
			// datatablesButtons.buttons().container().appendTo("#datatables-buttons_wrapper .col-md-6:eq(0)");
			// Datatables with Multiselect
			var datatablesMulti = $("#datatables-multi").DataTable({
				responsive: true,
				select: {
					style: "multi"
				}
			});
		});
	</script>
	<script>
		function exportTableToExcel(tableID, filename = 'customerlist'){
    var downloadLink;
    var dataType = 'application/vnd.ms-excel';
    var tableSelect = document.getElementById(tableID);
    var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
    
    // Specify file name
    filename = filename?filename+'.xls':'excel_data.xls';
    
    // Create download link element
    downloadLink = document.createElement("a");
    
    document.body.appendChild(downloadLink);
    
    if(navigator.msSaveOrOpenBlob){
        var blob = new Blob(['\ufeff', tableHTML], {
            type: dataType
        });
        navigator.msSaveOrOpenBlob( blob, filename);
    }else{
        // Create a link to the file
        downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
    
        // Setting the file name
        downloadLink.download = filename;
        
        //triggering the function
        downloadLink.click();
    }
}	
	</script>