<?php
	$this->load->view('business_admin/ba_header_view');
?>
<div class="wrapper">
	<?php
		$this->load->view('business_admin/ba_nav_view');
	?>
	<div class="main">
		<?php
			$this->load->view('business_admin/ba_top_nav_view');
		?>
		<main class="content">
			<div class="container-fluid p-0">
				<h1 class="h3 mb-3">Menu Management</h1>
				<div class="row">
					<?php
						if(empty($business_outlet_details)){
					?>	
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title">Add Outlets</h5>
								</div>
								<div class="card-body">
									<p>Please add outlet to proceed.</p>
								</div>
							</div>
						</div>
					<?php
						}

						if(!isset($selected_outlet)){
					?>
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title">Select Outlet</h5>
								</div>
								<div class="card-body">
									<p>Please select outlet to proceed.</p>
								</div>
							</div>
						</div>
					<?php
						}
						else{
					?>
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h5 class="card-title">Your Menu</h5>
							</div>
							<div class="card-body">
								<div class="card">
									<div class="card-header">
										<ul class="nav nav-pills card-header-pills pull-right" role="tablist">
											<li class="nav-item">
												<a class="nav-link active" data-toggle="tab" href="#tab-1">Menu - Service</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" data-toggle="tab" href="#tab-2">Menu - OTC</a>
											</li>
										</ul>
									</div>
									<div class="card-body">
										<div class="tab-content">
											<div class="tab-pane fade show active" id="tab-1" role="tabpanel">
												<button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#ModalAddService"><i class="fas fa-fw fa-plus"></i> Add Service</button>
												<table class="table table-hover table-responsive mt-3">
													<thead>
														<tr>
															<th>Service Id</th>
															<th>Service Name</th>
															<th>Category</th>
															<th>SubCategory</th>
															<th>Description</th>
															<th>Gross Price</th>
															<th>GST%</th>
															<th>GST Amount</th>
															<th>Total</th>
															<th style="width: 14%;">Actions</th>
														</tr>
													</thead>
													<tbody>
														<?php
														
															foreach ($services as $service):
														?>
														<tr>
															<td><?=$service['service_id']?></td>
															<td><?=$service['service_name']?></td>
															<td><?=$service['category_name']?></td>
															<td><?=$service['sub_category_name']?></td>
															<td><?=$service['service_description']?></td>
															<td><?=$service['service_price_inr']?></td>
															<td><?=$service['service_gst_percentage']." %"?></td>
															<td><?=(($service['service_gst_percentage']/100)*$service['service_price_inr'])?></td>
															<td><?=($service['service_price_inr'] + (($service['service_gst_percentage']/100)*$service['service_price_inr']))?></td>
															<td class="table-action">
																<button type="button" class="btn btn-primary service-edit-btn" service_id="<?=$service['service_id']?>">
													        <i class="align-middle" data-feather="edit-2"></i>
													      </button>
													      <button type="button" class="btn btn-danger service-deactivate-btn" service_id="<?=$service['service_id']?>">
													        <i class="fa fa-trash" aria-hidden="true"></i>
													      </button>
															</td>
														</tr>	
														<?php		
															endforeach;
														?>
													</tbody>
												</table>
											</div>
											<div class="tab-pane fade" id="tab-2" role="tabpanel">
												<button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#ModalAddOTC"><i class="fas fa-fw fa-plus"></i>OTC</button>
												<table class="table table-hover table-responsive mt-3">
													<thead>
														<tr>
															<th>Item Code</th>
															<th>Item Name</th>
															<th>Category</th>
															<th>Sub-Category</th>
															<th>Unit</th>
															<th>Brand</th>
															<th>Gross Price</th>
															<th>GST%</th>
															<th>GST Amount</th>
															<th>Total</th>
															<th style="width: 14%;">Actions</th>
														</tr>
													</thead>
													<tbody>
														<?php
															foreach ($all_otc as $otc):
														?>
														<tr>
															<td><?=$otc['otc_category_id']?></td>
															<td><?=$otc['otc_item_name']?></td>
															<td><?=$otc['category_name']?></td>
															<td><?=$otc['sub_category_name']?></td>
															<td><?=$otc['otc_unit']?></td>
															<td><?=$otc['otc_brand']?></td>
															<td><?=$otc['otc_price_inr']?></td>
															<td><?=$otc['otc_gst_percentage']." %"?></td>
															<td><?=(($otc['otc_gst_percentage']/100)*$otc['otc_price_inr'])?></td>
															<td><?=($otc['otc_price_inr'] + (($otc['otc_gst_percentage']/100)*$otc['otc_price_inr']))?></td>
															<td class="table-action">
																<button type="button" class="btn btn-primary otc-edit-btn" otc_category_id="<?=$otc['otc_category_id']?>">
													        <i class="align-middle" data-feather="edit-2"></i>
													      </button>
													      <button type="button" class="btn btn-danger otc-deactivate-btn" otc_category_id="<?=$otc['otc_category_id']?>">
													        <i class="fa fa-trash" aria-hidden="true"></i>
													      </button>
															</td>
														</tr>	
														<?php		
															endforeach;
														?>
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h5 class="card-title">Category & SubCategories</h5>
							</div>
							<div class="card-body">
								<!-- Modals -->
								<div class="modal fade" id="defaultModalSuccess" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title">Success</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    			<span aria-hidden="true">&times;</span>
                 			 	</button>
											</div>
											<div class="modal-body m-3">
												<p class="mb-0" id="SuccessModalMessage"><p>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>

								<div class="modal fade" id="ModalAddService" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog modal-dialog-centered modal-md" role="document">
										<div class="modal-content">
											<div class="modal-header" style="background-color:#47bac1">
												<h5 class="modal-title  text-white font-weight-bold">Add Service</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		                      <span aria-hidden="true">&times;</span>
		                    </button>
											</div>
											<div class="modal-body m-3">
												<div class="row">
													<div class="col-md-12">
														<form id="AddService" method="POST" action="#">
															<div class="row">
															<div class="form-group col-md-6">
																<label>Service Name</label>
																<input type="text" class="form-control" placeholder="Service Name" name="service_name" autofocus>
															</div>
														
															<div class="form-group col-md-6">
																<label>Service Gross Price</label>
																<input class="form-control" placeholder="Service Gross Price" name="service_price_inr">
															</div>
															</div>
															<div class="row">
															<div class="form-group col-md-6">
																<label>Service GST Percentage</label>
																<input class="form-control" placeholder="% Value Only" name="service_gst_percentage">
															</div>
															<div class="form-group col-md-6">
																<label>Service Estimate Time</label>
																<input type="text" class="form-control" placeholder="N Hours/Minutes" name="service_est_time">
															</div>
															</div>
															<div class="row">
															
															<div class="form-group col-md-6">
																<label>Category</label>
																<select class="form-control" name="service_category_id" id="Service-Category-Id">
																	<option value="" selected></option>
																	<?php
																		foreach ($categories as $category) {
																			echo "<option value=".$category['category_id'].">".$category['category_name']."</option>";
																		}
																	?>
																</select>
															</div>
															<div class="form-group col-md-6">
																<label>Sub-Category</label>
																<select class="form-control" name="service_sub_category_id" id="Service-Sub-Category-Id">
																</select>
															</div>
															</div>
															<div class="row">									
															<div class="form-group col-md-12">
																<label>Service Description</label>
																<textarea class="form-control" rows="2" placeholder="Service Description" name="service_description"></textarea>
															</div>
															</div>
															<div class="row">
																<div class="col-md-2">
															<button type="submit" class="btn btn-primary">Submit</button>
																	</div>
																	</div>
														</form>
														<div class="alert alert-dismissible feedback mt-2" role="alert">
															<button type="button" class="close" data-dismiss="alert" aria-label="Close">
																<span aria-hidden="true">&times;</span>
									            </button>
															<div class="alert-message">
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>

								<div class="modal fade" id="ModalAddCategory" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title">Add Category</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		                      <span aria-hidden="true">&times;</span>
		                    </button>
											</div>
											<div class="modal-body m-3">
												<div class="row">
													<div class="col-md-12">
														<form id="AddCategory" method="POST" action="#">
															<div class="form-group">
																<label>Category Name</label>
																<input type="text" class="form-control" placeholder="Category Name" name="category_name">
															</div>
															<div class="form-group">
																<label>Category Description</label>
																<textarea class="form-control" rows="2" placeholder="Category Description" name="category_description"></textarea>
															</div>
															<button type="submit" class="btn btn-primary">Submit</button>
														</form>
														<div class="alert alert-dismissible feedback mt-2" role="alert">
															<button type="button" class="close" data-dismiss="alert" aria-label="Close">
																<span aria-hidden="true">&times;</span>
									            </button>
															<div class="alert-message">
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>

								<div class="modal fade" id="ModalAddSubCategory" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title">Add SubCategory</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		                      <span aria-hidden="true">&times;</span>
		                    </button>
											</div>
											<div class="modal-body m-3">
												<div class="row">
													<div class="col-md-12">
														<form id="AddSubCategory" method="POST" action="#">
															<div class="form-group">
																<label>SubCategory Name</label>
																<input type="text" class="form-control" placeholder="Sub Category Name" name="sub_category_name">
															</div>
															<div class="form-group">
																<label>Category</label>
																<select name="sub_category_category_id" class="form-control">
																	<option value="" selected>Choose Category</option>
																	<?php
																		foreach ($categories as $category) {
																			echo "<option value=".$category['category_id'].">".$category['category_name']."</option>";
																		}
																	?>
																</select>																
															</div>
															<div class="form-group">
																<label>SubCategory Description</label>
																<textarea class="form-control" rows="2" placeholder="Sub Category Description" name="sub_category_description"></textarea>
															</div>
															<button type="submit" class="btn btn-primary">Submit</button>
														</form>
														<div class="alert alert-dismissible feedback mt-2" role="alert">
															<button type="button" class="close" data-dismiss="alert" aria-label="Close">
																<span aria-hidden="true">&times;</span>
									            </button>
															<div class="alert-message">
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>

								<div class="modal fade" id="ModalEditCategory" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title">Edit Category</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		                      <span aria-hidden="true">&times;</span>
		                    </button>
											</div>
											<div class="modal-body m-3">
												<div class="row">
													<div class="col-md-12">
														<form id="EditCategory" method="POST" action="#">
															<div class="form-group">
																<label>Category Name</label>
																<input type="text" class="form-control" placeholder="Category Name" name="category_name">
															</div>
															<div class="form-group">
																<label>Category Description</label>
																<textarea class="form-control" rows="2" placeholder="Category Description" name="category_description"></textarea>
															</div>
															<div class="form-group">
					                      <input class="form-control" type="hidden" name="category_id" readonly="true">
					                    </div>
															<button type="submit" class="btn btn-primary">Submit</button>
														</form>
														<div class="alert alert-dismissible feedback mt-2" role="alert">
															<button type="button" class="close" data-dismiss="alert" aria-label="Close">
																<span aria-hidden="true">&times;</span>
									            </button>
															<div class="alert-message">
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>

								<div class="modal fade" id="ModalEditSubCategory" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title">Edit SubCategory</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		                      <span aria-hidden="true">&times;</span>
		                    </button>
											</div>
											<div class="modal-body m-3">
												<div class="row">
													<div class="col-md-12">
														<form id="EditSubCategory" method="POST" action="#">
															<div class="form-group">
																<label>SubCategory Name</label>
																<input type="text" class="form-control" placeholder="Sub Category Name" name="sub_category_name">
															</div>
															<div class="form-group">
																<label>Category</label>
																<select name="sub_category_category_id" class="form-control">
																	<option value="" selected>Choose Category</option>
																	<?php
																		foreach ($categories as $category) {
																			echo "<option value=".$category['category_id'].">".$category['category_name']."</option>";
																		}
																	?>
																</select>																
															</div>
															<div class="form-group">
																<label>SubCategory Description</label>
																<textarea class="form-control" rows="2" placeholder="Sub Category Description" name="sub_category_description"></textarea>
															</div>
															<div class="form-group">
					                      <input class="form-control" type="hidden" name="sub_category_id" readonly="true">
					                    </div>
															<button type="submit" class="btn btn-primary">Submit</button>
														</form>
														<div class="alert alert-dismissible feedback mt-2" role="alert">
															<button type="button" class="close" data-dismiss="alert" aria-label="Close">
																<span aria-hidden="true">&times;</span>
									            </button>
															<div class="alert-message">
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>

								<div class="modal fade" id="ModalEditService" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title">Edit Service</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		                      <span aria-hidden="true">&times;</span>
		                    </button>
											</div>
											<div class="modal-body m-3">
												<div class="row">
													<div class="col-md-12">
														<form id="EditService" method="POST" action="#">
															<div class="form-group">
																<label>Service Name</label>
																<input type="text" class="form-control" placeholder="Service Name" name="service_name">
															</div>
															<div class="form-group">
																<label>Service Gross Price</label>
																<input class="form-control" placeholder="Service Gross Price" name="service_price_inr">
															</div>
															<div class="form-group">
																<label>Service GST Percentage</label>
																<input class="form-control" placeholder="% Value Only" name="service_gst_percentage">
															</div>
															<div class="form-group">
																<label>Service Estimate Time</label>
																<input type="text" class="form-control" placeholder="N Hours/Minutes" name="service_est_time">
															</div>
															<div class="form-group">
																<label>Service Description</label>
																<textarea class="form-control" rows="2" placeholder="Service Description" name="service_description"></textarea>
															</div>
															<!-- <div class="form-group">
																<label>Category</label>
																<select class="form-control" name="service_category_id" id="Service-Category-Edit-Id">
																	<option value="" selected></option>
																	<?php
																		//foreach ($categories as $category) {
																			//echo "<option value=".$category['category_id'].">".$category['category_name']."</option>";
																		//}
																	?>
																</select>
															</div>
															<div class="form-group">
																<label>Sub-Category</label>
																<select class="form-control" name="service_sub_category_id" id="Service-Sub-Category-Edit-Id">
																</select>
															</div> -->
															<div class="form-group">
					                      <input class="form-control" type="hidden" name="service_id" readonly="true">
					                    </div>
															<button type="submit" class="btn btn-primary">Submit</button>
														</form>
														<div class="alert alert-dismissible feedback mt-2" role="alert">
															<button type="button" class="close" data-dismiss="alert" aria-label="Close">
																<span aria-hidden="true">&times;</span>
									            </button>
															<div class="alert-message">
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>
								<!-- Modal Area Ends -->
								<button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#ModalAddCategory"><i class="fas fa-fw fa-plus"></i> Add Category</button>
								<table class="table table-hover table-responsive mt-3">
									<thead>
										<tr>
											<th>Category Id</th>
											<th>Category Name</th>
											<th>Description</th>
											<th>Actions</th>
										</tr>
									</thead>
									<tbody>
										<?php
											foreach ($categories as $category):
										?>
										<tr>
											<td><?=$category['category_id']?></td>
											<td><?=$category['category_name']?></td>
											<td><?=$category['category_description']?></td>
											<td class="table-action">
												<button type="button" class="btn btn-primary category-edit-btn" category_id="<?=$category['category_id']?>">
									        <i class="align-middle" data-feather="edit-2"></i>
									      </button>
									      <button type="button" class="btn btn-danger category-deactivate-btn" category_id="<?=$category['category_id']?>">
									        <i class="fa fa-trash" aria-hidden="true"></i>
									      </button>
											</td>
										</tr>	
										<?php		
											endforeach;
										?>
									</tbody>
								</table>

								<button class="btn btn-primary btn-lg mt-2" data-toggle="modal" data-target="#ModalAddSubCategory"><i class="fas fa-fw fa-plus"></i> Add Sub-Category</button>
								<table class="table table-hover table-responsive mt-3">
									<thead>
										<tr>
											<th>Sub-Category Id</th>
											<th>Sub-Category Name</th>
											<th>Category Name</th>
											<th>Description</th>
											<th>Actions</th>
										</tr>
									</thead>
									<tbody>
										<?php
											foreach ($sub_categories as $sub_category):
										?>
										<tr>
											<td><?=$sub_category['sub_category_id']?></td>
											<td><?=$sub_category['sub_category_name']?></td>
											<td><?=$sub_category['category_name']?></td>
											<td><?=$sub_category['sub_category_description']?></td>
											<td class="table-action">
												<button type="button" class="btn btn-primary sub-category-edit-btn" sub_category_id="<?=$sub_category['sub_category_id']?>">
									        <i class="align-middle" data-feather="edit-2"></i>
									      </button>
									      <button type="button" class="btn btn-danger sub-category-deactivate-btn" sub_category_id="<?=$sub_category['sub_category_id']?>">
									        <i class="fa fa-trash" aria-hidden="true"></i>
									      </button>
											</td>
										</tr>	
										<?php		
											endforeach;
										?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h5 class="card-title">Raw Materials</h5>
							</div>
							<div class="card-body">
								<!--Modal Area-->

								<div class="modal fade" id="ModalAddOTC" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title">Add OTC Category</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		                      <span aria-hidden="true">&times;</span>
		                    </button>
											</div>
											<div class="modal-body m-3">
												<div class="row">
													<div class="col-md-12">
														<form id="AddOTCCategory" method="POST" action="#">
															<div class="form-group">
																<label>Item Name</label>
																<input type="text" class="form-control" placeholder="Item Name" name="otc_item_name">
															</div>
															<div class="form-group">
																<label>Unit</label>
																<select class="form-control" name="otc_unit">
																	<option value="mL">mL</option>
																	<option value="gms">gms</option>
																	<option value="Kg">Kg</option>
																	<option value="Ltr">Ltr</option>
																</select>
															</div>
															<div class="form-group">
																<label>Brand</label>
																<input class="form-control" placeholder="Brand Name" name="otc_brand">
															</div>
															<div class="form-group">
																<label>Category</label>
																<select class="form-control" name="category_id" id="OTC-Category-Id">
																	<option value="" selected></option>
																	<?php
																		foreach ($categories as $category) {
																			echo "<option value=".$category['category_id'].">".$category['category_name']."</option>";
																		}
																	?>
																</select>
															</div>
															<div class="form-group">
																<label>Sub-Category</label>
																<select class="form-control" name="otc_sub_category_id" id="OTC-Sub-Category-Id">
																</select>
															</div>
															<div class="form-group">
																<label>OTC Gross Price</label>
																<input class="form-control" placeholder="OTC Gross Price" name="otc_price_inr">
															</div>
															<div class="form-group">
																<label>OTC GST Percentage</label>
																<input class="form-control" placeholder="% Value Only" name="otc_gst_percentage">
															</div>
															<button type="submit" class="btn btn-primary">Submit</button>
														</form>
														<div class="alert alert-dismissible feedback mt-2" role="alert">
															<button type="button" class="close" data-dismiss="alert" aria-label="Close">
																<span aria-hidden="true">&times;</span>
									            </button>
															<div class="alert-message">
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>

								<div class="modal fade" id="ModalEditOTC" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title">Edit OTC</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		                      <span aria-hidden="true">&times;</span>
		                    </button>
											</div>
											<div class="modal-body m-3">
												<div class="row">
													<div class="col-md-12">
														<form id="EditOTCCategory" method="POST" action="#">
															<div class="form-group">
																<label>Item Name</label>
																<input type="text" class="form-control" placeholder="Item Name" name="otc_item_name">
															</div>
															<div class="form-group">
																<label>Unit</label>
																<select class="form-control" name="otc_unit">
																	<option value="mL">mL</option>
																	<option value="gms">gms</option>
																	<option value="Kg">Kg</option>
																	<option value="Ltr">Ltr</option>
																</select>
															</div>
															<div class="form-group">
																<label>Brand</label>
																<input class="form-control" placeholder="Brand Name" name="otc_brand">
															</div>
															<div class="form-group">
																<label>OTC Gross Price</label>
																<input class="form-control" placeholder="OTC Gross Price" name="otc_price_inr">
															</div>
															<div class="form-group">
																<label>OTC GST Percentage</label>
																<input class="form-control" placeholder="% Value Only" name="otc_gst_percentage">
															</div>
															<div class="form-group">
					                      <input class="form-control" type="hidden" name="otc_category_id" readonly="true">
					                    </div>
															<button type="submit" class="btn btn-primary">Submit</button>
														</form>
														<div class="alert alert-dismissible feedback mt-2" role="alert">
															<button type="button" class="close" data-dismiss="alert" aria-label="Close">
																<span aria-hidden="true">&times;</span>
									            </button>
															<div class="alert-message">
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>

								<div class="modal fade" id="ModalAddRawMaterial" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title">Add Raw Material</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		                      <span aria-hidden="true">&times;</span>
		                    </button>
											</div>
											<div class="modal-body m-3">
												<div class="row">
													<div class="col-md-12">
														<form id="AddRawMaterial" method="POST" action="#">
															<div class="form-group">
																<label>Item Name</label>
																<input type="text" class="form-control" placeholder="Item Name" name="raw_material_name">
															</div>
															<div class="form-group">
																<label>Unit</label>
																<select class="form-control" name="raw_material_unit">
																	<option value="mL">mL</option>
																	<option value="gms">gms</option>
																	<option value="Kg">Kg</option>
																	<option value="Ltr">Ltr</option>
																</select>
															</div>
															<div class="form-group">
																<label>Brand</label>
																<input class="form-control" placeholder="Brand Name" name="raw_material_brand">
															</div>
															<button type="submit" class="btn btn-primary">Submit</button>
														</form>
														<div class="alert alert-dismissible feedback mt-2" role="alert">
															<button type="button" class="close" data-dismiss="alert" aria-label="Close">
																<span aria-hidden="true">&times;</span>
									            </button>
															<div class="alert-message">
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>

								<div class="modal fade" id="ModalEditRawMaterial" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title">Edit Raw Material</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		                      <span aria-hidden="true">&times;</span>
		                    </button>
											</div>
											<div class="modal-body m-3">
												<div class="row">
													<div class="col-md-12">
														<form id="EditRawMaterial" method="POST" action="#">
															<div class="form-group">
																<label>Item Name</label>
																<input type="text" class="form-control" placeholder="Item Name" name="raw_material_name">
															</div>
															<div class="form-group">
																<label>Unit</label>
																<select class="form-control" name="raw_material_unit">
																	<option value="mL">mL</option>
																	<option value="gms">gms</option>
																	<option value="Kg">Kg</option>
																	<option value="Ltr">Ltr</option>
																</select>
															</div>
															<div class="form-group">
																<label>Brand</label>
																<input class="form-control" placeholder="Brand Name" name="raw_material_brand">
															</div>
															<div class="form-group">
					                      <input class="form-control" type="hidden" name="raw_material_category_id" readonly="true">
					                    </div>
															<button type="submit" class="btn btn-primary">Submit</button>
														</form>
														<div class="alert alert-dismissible feedback mt-2" role="alert">
															<button type="button" class="close" data-dismiss="alert" aria-label="Close">
																<span aria-hidden="true">&times;</span>
									            </button>
															<div class="alert-message">
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>

								<!-----END------>
								<button class="btn btn-primary btn-lg mt-2" data-toggle="modal" data-target="#ModalAddRawMaterial"><i class="fas fa-fw fa-plus"></i> Add Raw Material</button>
								<table class="table table-hover table-responsive mt-3">
									<thead>
										<tr>
											<th>Item Id</th>
											<th>Item Name</th>
											<th>Brand</th>
											<th>Unit</th>
											<th>Actions</th>
										</tr>
									</thead>
									<tbody>
										<?php
											foreach ($raw_materials as $raw_material):
										?>
										<tr>
											<td><?=$raw_material['raw_material_category_id']?></td>
											<td><?=$raw_material['raw_material_name']?></td>
											<td><?=$raw_material['raw_material_brand']?></td>
											<td><?=$raw_material['raw_material_unit']?></td>
											<td class="table-action">
												<button type="button" class="btn btn-primary raw-material-edit-btn" raw_material_category_id="<?=$raw_material['raw_material_category_id']?>">
									        <i class="align-middle" data-feather="edit-2"></i>
									      </button>
									      <button type="button" class="btn btn-danger raw-material-deactivate-btn" raw_material_category_id="<?=$raw_material['raw_material_category_id']?>">
									        <i class="fa fa-trash" aria-hidden="true"></i>
									      </button>
											</td>
										</tr>	
										<?php		
											endforeach;
										?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
					<?php
						}
					?>	
				</div>
			</div>
		</main>	
<?php
	$this->load->view('business_admin/ba_footer_view');
?>
<script type="text/javascript">
	$(document).ready(function(){
	
		$(document).ajaxStart(function() {
      $("#load_screen").show();
    });

    $(document).ajaxStop(function() {
      $("#load_screen").hide();
    });
	  	
  	$("#AddCategory").validate({
	  	errorElement: "div",
	    rules: {
	        "category_name" : {
            required : true,
            maxlength : 100
	        }  
	    },
	    submitHandler: function(form) {
				var formData = $("#AddCategory").serialize(); 
				$.ajax({
		        url: "<?=base_url()?>index.php/BusinessAdmin/AddCategory/",
		        data: formData,
		        type: "POST",
		        crossDomain: true,
						cache: false,
		        dataType : "json",
		    		success: function(data) {
              if(data.success == 'true'){ 
              	$("#ModalAddCategory").modal('hide');
					$('#defaultModalSuccess').modal('show').on('shown.bs.modal', function (e) {
						$("#SuccessModalMessage").html("").html(data.message);
						
					}).on('hidden.bs.modal', function (e) {
							window.location.reload();
					});
              }
              else if (data.success == 'false'){                   
          	    if($('.feedback').hasClass('alert-success')){
                  $('.feedback').removeClass('alert-success').addClass('alert-danger');
                }
                else{
                  $('.feedback').addClass('alert-danger');
                }
                $('.alert-message').html("").html(data.message); 
              }
            },
            error: function(data){
    					$('.feedback').addClass('alert-danger');
    					$('.alert-message').html("").html(data.message); 
            }
				});
			},
		});

		$("#AddSubCategory").validate({
	  	errorElement: "div",
	    rules: {
	        "sub_category_name" : {
            required : true,
            maxlength : 100
	        },
	        "sub_category_category_id" : {
	        	required : true
	        }  
	    },
	    submitHandler: function(form) {
				var formData = $("#AddSubCategory").serialize(); 
				$.ajax({
		        url: "<?=base_url()?>index.php/BusinessAdmin/AddSubCategory/",
		        data: formData,
		        type: "POST",
		        crossDomain: true,
						cache: false,
		        dataType : "json",
		    		success: function(data) {
              if(data.success == 'true'){ 
              	$("#ModalAddSubCategory").modal('hide');
								$('#defaultModalSuccess').modal('show').on('shown.bs.modal', function (e) {
									$("#SuccessModalMessage").html("").html(data.message);
								}).on('hidden.bs.modal', function (e) {
										window.location.reload();
								});
              }
              else if (data.success == 'false'){                   
          	    if($('.feedback').hasClass('alert-success')){
                  $('.feedback').removeClass('alert-success').addClass('alert-danger');
                }
                else{
                  $('.feedback').addClass('alert-danger');
                }
                $('.alert-message').html("").html(data.message); 
              }
            },
            error: function(data){
    					$('.feedback').addClass('alert-danger');
    					$('.alert-message').html("").html(data.message); 
            }
				});
			},
		});

		$("#AddService").validate({
	  	errorElement: "div",
	    rules: {
	        "service_name" : {
            required : true,
            maxlength : 100
	        },
	        "service_est_time" :{
	        	required : true,
	        	maxlength : 50
	        },
	        "service_price_inr" : {
	        	required : true,
	        	digits : true
	        },
	        "service_gst_percentage" : {
	        	required : true,
	        	digits : true
	        },
	        "service_sub_category_id" :{
	        	required : true
	        }
	    },
	    submitHandler: function(form) {
				var formData = $("#AddService").serialize(); 
				$.ajax({
		        url: "<?=base_url()?>index.php/BusinessAdmin/AddService/",
		        data: formData,
		        type: "POST",
		        crossDomain: true,
						cache: false,
		        dataType : "json",
		    		success: function(data) {
              if(data.success == 'true'){ 
              	$("#ModalAddService").modal('hide');
								$('#defaultModalSuccess').modal('show').on('shown.bs.modal', function (e) {
									$("#SuccessModalMessage").html("").html(data.message);
								}).on('hidden.bs.modal', function (e) {
										window.location.reload();
								});
								
              }
              else if (data.success == 'false'){                   
          	    if($('.feedback').hasClass('alert-success')){
                  $('.feedback').removeClass('alert-success').addClass('alert-danger');
                }
                else{
                  $('.feedback').addClass('alert-danger');
                }
                $('.alert-message').html("").html(data.message); 
              }
            },
            error: function(data){
    					$('.feedback').addClass('alert-danger');
    					$('.alert-message').html("").html(data.message); 
            }
				});
			},
		});

		$("#AddOTCCategory").validate({
	  	errorElement: "div",
	    rules: {
	        "otc_item_name" : {
            required : true,
            maxlength : 100
	        },
	        "otc_brand" :{
	        	required : true,
	        	maxlength : 100
	        },
	        "otc_unit" : {
	        	required : true
	        },
	        "otc_sub_category_id" : {
	        	required : true
	        },
	        "otc_price_inr" : {
	        	required : true,
	        	digits : true
	        },
	        "otc_gst_percentage" : {
	        	required : true,
	        	digits : true
	        }
	    },
	    submitHandler: function(form) {
				var formData = $("#AddOTCCategory").serialize(); 
				$.ajax({
		        url: "<?=base_url()?>index.php/BusinessAdmin/AddOTCCategory/",
		        data: formData,
		        type: "POST",
		        crossDomain: true,
						cache: false,
		        dataType : "json",
		    		success: function(data) {
              if(data.success == 'true'){ 
              	$("#ModalAddOTC").modal('hide');
								$('#defaultModalSuccess').modal('show').on('shown.bs.modal', function (e) {
									$("#SuccessModalMessage").html("").html(data.message);
								}).on('hidden.bs.modal', function (e) {
										window.location.reload();
								});
              }
              else if (data.success == 'false'){                   
          	    if($('.feedback').hasClass('alert-success')){
                  $('.feedback').removeClass('alert-success').addClass('alert-danger');
                }
                else{
                  $('.feedback').addClass('alert-danger');
                }
                $('.alert-message').html("").html(data.message); 
              }
            },
            error: function(data){
    					$('.feedback').addClass('alert-danger');
    					$('.alert-message').html("").html(data.message); 
            }
				});
			},
		});

		$("#AddRawMaterial").validate({
	  	errorElement: "div",
	    rules: {
	        "raw_material_item_name" : {
            required : true,
            maxlength : 100
	        },
	        "raw_material_brand" :{
	        	required : true,
	        	maxlength : 100
	        },
	        "raw_material_unit" : {
	        	required : true
	        }
	    },
	    submitHandler: function(form) {
				var formData = $("#AddRawMaterial").serialize(); 
				$.ajax({
		        url: "<?=base_url()?>index.php/BusinessAdmin/AddRawMaterial/",
		        data: formData,
		        type: "POST",
		        crossDomain: true,
						cache: false,
		        dataType : "json",
		    		success: function(data) {
              if(data.success == 'true'){ 
              	$("#ModalAddRawMaterial").modal('hide');
								$('#defaultModalSuccess').modal('show').on('shown.bs.modal', function (e) {
									$("#SuccessModalMessage").html("").html(data.message);
								}).on('hidden.bs.modal', function (e) {
										window.location.reload();
								});
              }
              else if (data.success == 'false'){                   
          	    if($('.feedback').hasClass('alert-success')){
                  $('.feedback').removeClass('alert-success').addClass('alert-danger');
                }
                else{
                  $('.feedback').addClass('alert-danger');
                }
                $('.alert-message').html("").html(data.message); 
              }
            },
            error: function(data){
    					$('.feedback').addClass('alert-danger');
    					$('.alert-message').html("").html(data.message); 
            }
				});
			},
		});

		$("#EditCategory").validate({
	  	errorElement: "div",
	    rules : {
      	"category_name" : {
      	  required : true,
        	maxlength : 100
      	}
      },
	    submitHandler: function(form) {
				var formData = $("#EditCategory").serialize(); 
				$.ajax({
		        url: "<?=base_url()?>index.php/BusinessAdmin/EditCategory/",
		        data: formData,
		        type: "POST",
		        crossDomain: true,
						cache: false,
		        dataType : "json",
		    		success: function(data) {
              if(data.success == 'true'){
              	$("#ModalEditCategory").modal('hide');
								$('#defaultModalSuccess').modal('show').on('shown.bs.modal', function (e) {
									$("#SuccessModalMessage").html("").html(data.message);
								}).on('hidden.bs.modal', function (e) {
										window.location.reload();
								});
              }
              else if (data.success == 'false'){                   
          	    if($('.feedback').hasClass('alert-success')){
                  $('.feedback').removeClass('alert-success').addClass('alert-danger');
                }
                else{
                  $('.feedback').addClass('alert-danger');
                }
                $('.alert-message').html("").html(data.message); 
              }
            },
            error: function(data){
    					$('.feedback').addClass('alert-danger');
    					$('.alert-message').html("").html(data.message); 
            }
				});
			},
		});

		$("#EditSubCategory").validate({
	  	errorElement: "div",
	    rules: {
      	"sub_category_name" : {
      	  required : true,
        	maxlength : 100
        },
        "sub_category_category_id" : {
        	required : true
        }
      },
	    submitHandler: function(form) {
				var formData = $("#EditSubCategory").serialize(); 
				$.ajax({
		        url: "<?=base_url()?>index.php/BusinessAdmin/EditSubCategory/",
		        data: formData,
		        type: "POST",
		        crossDomain: true,
						cache: false,
		        dataType : "json",
		    		success: function(data) {
              if(data.success == 'true'){
              	$("#ModalEditSubCategory").modal('hide');
								$('#defaultModalSuccess').modal('show').on('shown.bs.modal', function (e) {
									$("#SuccessModalMessage").html("").html(data.message);
								}).on('hidden.bs.modal', function (e) {
										window.location.reload();
								});
              }
              else if (data.success == 'false'){                   
          	    if($('.feedback').hasClass('alert-success')){
                  $('.feedback').removeClass('alert-success').addClass('alert-danger');
                }
                else{
                  $('.feedback').addClass('alert-danger');
                }
                $('.alert-message').html("").html(data.message); 
              }
            },
            error: function(data){
    					$('.feedback').addClass('alert-danger');
    					$('.alert-message').html("").html(data.message); 
            }
				});
			},
		});

		$("#EditService").validate({
	  	errorElement: "div",
	    rules : {
      	"service_name" : {
          required : true,
          maxlength : 100
        },
        "service_est_time" :{
        	required : true,
        	maxlength : 50
        },
        "service_price_inr" : {
        	required : true,
        	digits : true
        },
        "service_gst_percentage" : {
        	required : true,
        	digits : true
        }
       /* "service_sub_category_id" :{
        	required : true
        }*/
      },
	    submitHandler: function(form) {
				var formData = $("#EditService").serialize(); 
				$.ajax({
		        url: "<?=base_url()?>index.php/BusinessAdmin/EditService/",
		        data: formData,
		        type: "POST",
		        crossDomain: true,
						cache: false,
		        dataType : "json",
		    		success: function(data) {
              if(data.success == 'true'){
              	$("#ModalEditService").modal('hide');
								$('#defaultModalSuccess').modal('show').on('shown.bs.modal', function (e) {
									$("#SuccessModalMessage").html("").html(data.message);
								}).on('hidden.bs.modal', function (e) {
										window.location.reload();
								});
              }
              else if (data.success == 'false'){                   
          	    if($('.feedback').hasClass('alert-success')){
                  $('.feedback').removeClass('alert-success').addClass('alert-danger');
                }
                else{
                  $('.feedback').addClass('alert-danger');
                }
                $('.alert-message').html("").html(data.message); 
              }
            },
            error: function(data){
    					$('.feedback').addClass('alert-danger');
    					$('.alert-message').html("").html(data.message); 
            }
				});
			},
		});

		$("#EditOTCCategory").validate({
	  	errorElement: "div",
	    rules: {
	        "otc_item_name" : {
            required : true,
            maxlength : 100
	        },
	        "otc_brand" :{
	        	required : true,
	        	maxlength : 100
	        },
	        "otc_unit" : {
	        	required : true
	        },
	        "otc_price_inr" : {
	        	required : true,
	        	digits : true
	        },
	        "otc_gst_percentage" : {
	        	required : true,
	        	digits : true
	        }
	    },
	    submitHandler: function(form) {
				var formData = $("#EditOTCCategory").serialize(); 
				$.ajax({
		        url: "<?=base_url()?>index.php/BusinessAdmin/EditOTCCategory/",
		        data: formData,
		        type: "POST",
		        crossDomain: true,
						cache: false,
		        dataType : "json",
		    		success: function(data) {
              if(data.success == 'true'){ 
              	$("#ModalEditOTC").modal('hide');
								$('#defaultModalSuccess').modal('show').on('shown.bs.modal', function (e) {
									$("#SuccessModalMessage").html("").html(data.message);
								}).on('hidden.bs.modal', function (e) {
										window.location.reload();
								});
              }
              else if (data.success == 'false'){                   
          	    if($('.feedback').hasClass('alert-success')){
                  $('.feedback').removeClass('alert-success').addClass('alert-danger');
                }
                else{
                  $('.feedback').addClass('alert-danger');
                }
                $('.alert-message').html("").html(data.message); 
              }
            },
            error: function(data){
    					$('.feedback').addClass('alert-danger');
    					$('.alert-message').html("").html(data.message); 
            }
				});
			},
		});

		$("#EditRawMaterial").validate({
	  	errorElement: "div",
	    rules: {
	        "raw_material_item_name" : {
            required : true,
            maxlength : 100
	        },
	        "raw_material_brand" :{
	        	required : true,
	        	maxlength : 100
	        },
	        "raw_material_unit" : {
	        	required : true
	        }
	    },
	    submitHandler: function(form) {
				var formData = $("#EditRawMaterial").serialize(); 
				$.ajax({
		        url: "<?=base_url()?>index.php/BusinessAdmin/EditRawMaterial/",
		        data: formData,
		        type: "POST",
		        crossDomain: true,
						cache: false,
		        dataType : "json",
		    		success: function(data) {
              if(data.success == 'true'){ 
              	$("#ModalEditRawMaterial").modal('hide');
								$('#defaultModalSuccess').modal('show').on('shown.bs.modal', function (e) {
									$("#SuccessModalMessage").html("").html(data.message);
								}).on('hidden.bs.modal', function (e) {
										window.location.reload();
								});
              }
              else if (data.success == 'false'){                   
          	    if($('.feedback').hasClass('alert-success')){
                  $('.feedback').removeClass('alert-success').addClass('alert-danger');
                }
                else{
                  $('.feedback').addClass('alert-danger');
                }
                $('.alert-message').html("").html(data.message); 
              }
            },
            error: function(data){
    					$('.feedback').addClass('alert-danger');
    					$('.alert-message').html("").html(data.message); 
            }
				});
			},
		});

		$('.category-edit-btn').click(function(event) {
      event.preventDefault();
      this.blur(); // Manually remove focus from clicked link.
      var parameters = {
        category_id : $(this).attr('category_id')
      };
      $.getJSON("<?=base_url()?>index.php/BusinessAdmin/GetCategory/", parameters)
      .done(function(data, textStatus, jqXHR) { 
        $("#EditCategory input[name=category_name]").attr('value',data.category_name);
        $("#EditCategory textarea[name=category_description]").val(data.category_description);
        $("#EditCategory input[name=category_id]").attr('value',data.category_id);

        $("#ModalEditCategory").modal('show');
    	})
    	.fail(function(jqXHR, textStatus, errorThrown) {
        console.log(errorThrown.toString());
   		});
    });

    $('.sub-category-edit-btn').click(function(event) {
      event.preventDefault();
      this.blur(); // Manually remove focus from clicked link.
      var parameters = {
        sub_category_id : $(this).attr('sub_category_id')
      };
      $.getJSON("<?=base_url()?>index.php/BusinessAdmin/GetSubCategory/", parameters)
      .done(function(data, textStatus, jqXHR) { 
        $("#EditSubCategory input[name=sub_category_name]").attr('value',data.sub_category_name);
        $("#EditSubCategory textarea[name=sub_category_description]").val(data.sub_category_description);
        $("#EditSubCategory select[name=sub_category_category_id]").val(data.sub_category_category_id);
        $("#EditSubCategory input[name=sub_category_id]").val(data.sub_category_id);
        $("#ModalEditSubCategory").modal('show');
    	})
    	.fail(function(jqXHR, textStatus, errorThrown) {
        console.log(errorThrown.toString());
   		});
    });

    $('.service-edit-btn').click(function(event) {
      event.preventDefault();
      this.blur(); // Manually remove focus from clicked link.
      var parameters = {
        service_id : $(this).attr('service_id')
      };

      $.getJSON("<?=base_url()?>index.php/BusinessAdmin/GetService/", parameters)
      .done(function(data, textStatus, jqXHR) { 
        $("#EditService input[name=service_name]").attr('value',data.service_name);
        $("#EditService input[name=service_price_inr]").attr('value',data.service_price_inr);
        $("#EditService input[name=service_gst_percentage]").attr('value',data.service_gst_percentage);
        $("#EditService textarea[name=service_description]").val(data.service_description);
        $("#EditService input[name=service_est_time]").attr('value',data.service_est_time);
        $("#EditService select[name=service_sub_category_id]").val(data.service_sub_category_id);
        $("#EditService input[name=service_id]").attr('value',data.service_id);
       
        $("#ModalEditService").modal('show');
    	})
    	.fail(function(jqXHR, textStatus, errorThrown) {
        console.log(errorThrown.toString());
   		});
    });

    $('.otc-edit-btn').click(function(event) {
      event.preventDefault();
      this.blur(); // Manually remove focus from clicked link.
      var parameters = {
        otc_category_id : $(this).attr('otc_category_id')
      };

      $.getJSON("<?=base_url()?>index.php/BusinessAdmin/GetOTCCategory/", parameters)
      .done(function(data, textStatus, jqXHR) { 
        $("#EditOTCCategory input[name=otc_item_name]").attr('value',data.otc_item_name);
        $("#EditOTCCategory input[name=otc_brand]").attr('value',data.otc_brand);
        $("#EditOTCCategory input[name=otc_unit]").attr('value',data.otc_unit);
        $("#EditOTCCategory input[name=otc_category_id]").attr('value',data.otc_category_id);
        $("#EditOTCCategory input[name=otc_price_inr]").attr('value',data.otc_price_inr);
        $("#EditOTCCategory input[name=otc_gst_percentage]").attr('value',data.otc_gst_percentage);
       
        $("#ModalEditOTC").modal('show');
    	})
    	.fail(function(jqXHR, textStatus, errorThrown) {
        console.log(errorThrown.toString());
   		});
    });

    $('.raw-material-edit-btn').click(function(event) {
      event.preventDefault();
      this.blur(); // Manually remove focus from clicked link.
      var parameters = {
        raw_material_category_id : $(this).attr('raw_material_category_id')
      };

      $.getJSON("<?=base_url()?>index.php/BusinessAdmin/GetRawMaterial/", parameters)
      .done(function(data, textStatus, jqXHR) { 
        $("#EditRawMaterial input[name=raw_material_name]").attr('value',data.raw_material_name);
        $("#EditRawMaterial input[name=raw_material_brand]").attr('value',data.raw_material_brand);
        $("#EditRawMaterial input[name=raw_material_unit]").attr('value',data.raw_material_unit);
        $("#EditRawMaterial input[name=raw_material_category_id]").attr('value',data.raw_material_category_id);
       
        $("#ModalEditRawMaterial").modal('show');
    	})
    	.fail(function(jqXHR, textStatus, errorThrown) {
        console.log(errorThrown.toString());
   		});
    });

    $('.service-deactivate-btn').click(function(event) {
      event.preventDefault();
      this.blur(); // Manually remove focus from clicked link.
      var parameters = {
        "service_id" : $(this).attr('service_id'),
        "activate" : 'false',
        "deactivate" : 'true'
      };
      $.ajax({
        url: "<?=base_url()?>index.php/BusinessAdmin/DeactivateService/",
        data: parameters,
        type: "POST",
        crossDomain: true,
				cache: false,
        dataType : "json",
    		success: function(data) {
          if(data.success == 'true'){
						$('#defaultModalSuccess').modal('show').on('shown.bs.modal', function (e) {
							$("#SuccessModalMessage").html("").html(data.message);
						}).on('hidden.bs.modal', function (e) {
								window.location.reload();
						});
          }
        }
			});
    });

    $('.category-deactivate-btn').click(function(event) {
      event.preventDefault();
      this.blur(); // Manually remove focus from clicked link.
      var parameters = {
        "category_id" : $(this).attr('category_id'),
        "activate" : 'false',
        "deactivate" : 'true'
      };
      $.ajax({
        url: "<?=base_url()?>index.php/BusinessAdmin/DeactivateCategory/",
        data: parameters,
        type: "POST",
        crossDomain: true,
				cache: false,
        dataType : "json",
    		success: function(data) {
          if(data.success == 'true'){
						$('#defaultModalSuccess').modal('show').on('shown.bs.modal', function (e) {
							$("#SuccessModalMessage").html("").html(data.message);
						}).on('hidden.bs.modal', function (e) {
								window.location.reload();
						});
          }
        }
			});
    });

    $('.sub-category-deactivate-btn').click(function(event) {
      event.preventDefault();
      this.blur(); // Manually remove focus from clicked link.
      var parameters = {
        "sub_category_id" : $(this).attr('sub_category_id'),
        "activate" : 'false',
        "deactivate" : 'true'
      };
      $.ajax({
        url: "<?=base_url()?>index.php/BusinessAdmin/DeactivateSubCategory/",
        data: parameters,
        type: "POST",
        crossDomain: true,
				cache: false,
        dataType : "json",
    		success: function(data) {
          if(data.success == 'true'){
						$('#defaultModalSuccess').modal('show').on('shown.bs.modal', function (e) {
							$("#SuccessModalMessage").html("").html(data.message);
						}).on('hidden.bs.modal', function (e) {
								window.location.reload();
						});
          }
        }
			});
    });

    $('.otc-deactivate-btn').click(function(event) {
      event.preventDefault();
      this.blur(); // Manually remove focus from clicked link.
      var parameters = {
        "otc_category_id" : $(this).attr('otc_category_id'),
        "activate" : 'false',
        "deactivate" : 'true'
      };
      $.ajax({
        url: "<?=base_url()?>index.php/BusinessAdmin/DeactivateOTCCategory/",
        data: parameters,
        type: "POST",
        crossDomain: true,
				cache: false,
        dataType : "json",
    		success: function(data) {
          if(data.success == 'true'){
						$('#defaultModalSuccess').modal('show').on('shown.bs.modal', function (e) {
							$("#SuccessModalMessage").html("").html(data.message);
						}).on('hidden.bs.modal', function (e) {
								window.location.reload();
						});
          }
        }
			});
    });

    $('.raw-material-deactivate-btn').click(function(event) {
      event.preventDefault();
      this.blur(); // Manually remove focus from clicked link.
      var parameters = {
        "raw_material_category_id" : $(this).attr('raw_material_category_id'),
        "activate" : 'false',
        "deactivate" : 'true'
      };
      $.ajax({
        url: "<?=base_url()?>index.php/BusinessAdmin/DeactivateRawMaterial/",
        data: parameters,
        type: "POST",
        crossDomain: true,
				cache: false,
        dataType : "json",
    		success: function(data) {
          if(data.success == 'true'){
						$('#defaultModalSuccess').modal('show').on('shown.bs.modal', function (e) {
							$("#SuccessModalMessage").html("").html(data.message);
						}).on('hidden.bs.modal', function (e) {
								window.location.reload();
						});
          }
        }
			});
    });


    $("#Service-Category-Id").on('change',function(e){
    	var parameters = {
    		'category_id' :  $(this).val()
    	};
    	$.getJSON("<?=base_url()?>index.php/BusinessAdmin/GetSubCategoriesByCatId/", parameters)
      .done(function(data, textStatus, jqXHR) {
      		var options = "<option value='' selected></option>"; 
       		for(var i=0;i<data.length;i++){
       			options += "<option value="+data[i].sub_category_id+">"+data[i].sub_category_name+"</option>";
       		}
       		$("#Service-Sub-Category-Id").html("").html(options);
    	})
    	.fail(function(jqXHR, textStatus, errorThrown) {
        console.log(errorThrown.toString());
   		});
    });

    $("#OTC-Category-Id").on('change',function(e){
    	var parameters = {
    		'category_id' :  $(this).val()
    	};
    	$.getJSON("<?=base_url()?>index.php/BusinessAdmin/GetSubCategoriesByCatId/", parameters)
      .done(function(data, textStatus, jqXHR) {
      		var options = "<option value='' selected></option>"; 
       		for(var i=0;i<data.length;i++){
       			options += "<option value="+data[i].sub_category_id+">"+data[i].sub_category_name+"</option>";
       		}
       		$("#OTC-Sub-Category-Id").html("").html(options);
    	})
    	.fail(function(jqXHR, textStatus, errorThrown) {
        console.log(errorThrown.toString());
   		});
    });

   /* $("#Service-Category-Edit-Id").on('change',function(e){
    	var parameters = {
    		'category_id' :  $(this).val()
    	};
    	$.getJSON("<?=base_url()?>index.php/BusinessAdmin/GetSubCategoriesByCatId/", parameters)
      .done(function(data, textStatus, jqXHR) {
      		var options = "<option value='' selected></option>"; 
       		for(var i=0;i<data.length;i++){
       			options += "<option value="+data[i].sub_category_id+">"+data[i].sub_category_name+"</option>";
       		}
       		$("#Service-Sub-Category-Edit-Id").html("").html(options);
    	})
    	.fail(function(jqXHR, textStatus, errorThrown) {
        console.log(errorThrown.toString());
   		});
    });*/

  });
</script>