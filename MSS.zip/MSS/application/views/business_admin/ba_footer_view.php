		<footer class="footer">
			<div class="container-fluid">
				<div class="row text-muted">
					<div class="col-6 text-left">
						<ul class="list-inline">
							<li class="list-inline-item">
								<a class="text-muted" href="#">Support</a>
							</li>
							<li class="list-inline-item">
								<a class="text-muted" href="#">Help Center</a>
							</li>
							<li class="list-inline-item">
								<a class="text-muted" href="#">Privacy</a>
							</li>
							<li class="list-inline-item">
								<a class="text-muted" href="#">Terms of Service</a>
							</li>
						</ul>
					</div>
					<div class="col-6 text-right">
						<p class="mb-0">
							&copy; 2019 - <a href="#" class="text-muted">MarksSalonSolution</a>
						</p>
					</div>
				</div>
			</div>
		</footer>
	</div>
</div>
		<script src="<?=base_url()?>public/app_stack/js/app.js"></script>
		<script src="<?=base_url()?>public/app_stack/js/validation.js"></script>
	</body>
</html>