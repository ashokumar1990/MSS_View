<?php
	$this->load->view('business_admin/ba_header_view');
?>
<div class="wrapper">
	<?php
        $this->load->view('business_admin/ba_nav_view');
        
	?>
	<div class="main">
		<?php
            $this->load->view('business_admin/ba_top_nav_view');  
                      
		?>
		<main class="content">
			<div class="container-fluid p-0">
				<h1 class="h3 mb-3">Expense Tracker</h1>
				<div class="row">
					<?php
						if(empty($business_outlet_details)){
					?>	
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title">Add Outlets</h5>
								</div>
								<div class="card-body">
									<p>Please add outlet to proceed.</p>
								</div>
							</div>
						</div>
					<?php
						}

						if(!isset($selected_outlet)){
            
					?>
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title">Select Outlet</h5>
								</div>
								<div class="card-body">
									<p>Please select outlet to proceed.</p>
								</div>
							</div>
						</div>
					<?php
						}
						else{
                           
					?>
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h5 class="card-title">Expenses</h5>
							</div>
							<div class="card-body">
								<!-- Modals -->
								<div class="modal fade" id="defaultModalSuccess" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title">Success</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    			<span aria-hidden="true">&times;</span>
                 			 	</button>
											</div>
											<div class="modal-body m-3">
												<p class="mb-0" id="SuccessModalMessage"><p>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>

								<div class="modal fade" id="ModalAddExpense" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog modal-dialog-centered modal-md" role="document">
										<div class="modal-content">
											<div class="modal-header" style="background-color:#47bac1">
												<h5 class="modal-title">Add Expense</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		                      <span aria-hidden="true">&times;</span>
		                    </button>
											</div>
											<div class="modal-body">
												<div class="row">
													<div class="col-md-12">
														<form id="AddExpenseForm" method="POST" action="#">
                                                        <div class="row">
														<input type="hidden" id="expense_date" name="expense_date" value="<?=date('Y-m-d')?>">
															
															<div class="form-group col-md-6">
																<label>Item Name</label>
																<input type="text" class="form-control" placeholder="Item Name" name="item_name" autofocus>
															</div>
															<div class="form-group col-md-6">
																<label>Expense Type</label>
																<select class="form-control" name="expense_type" id="expense_type" selected="selected">
																<?php
																		foreach ($expense_type  as $type) {
																			echo "<option value=".$type['expense_type'].">".$type['expense_type']."</option>";
																		}
																	?>
                                                                </select>
															</div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="form-group col-md-6">
																<label>Employee Name</label>
																<input type="text" class="form-control" value="<?php echo($business_admin_details['business_admin_first_name']);?>" name="" readonly    >
															</div>
                                                            <div class="form-group col-md-6">
																<label>Amount</label>
																<input type="number" class="form-control" min="0" placeholder="Amount" name="amount">
															</div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="form-group col-md-6">
																<label>Quantity</label>
																<input type="number" class="form-control" placeholder="Quantity" name="quantity" min="0">
															</div>
                                                            <div class="form-group col-md-6">
																<label>Unit</label>
																<select class="form-control" name="unit" id="unit" selected="selected">
                                                                    <option value="ea" name="ea">EA</option>
                                                                    <option value="kg" name="kg">Kg</option>
                                                                    <option value="gms" name="gms">gms</option>
                                                                    <option value="ml" name="ml">ml</option>
                                                                <select>
															</div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="form-group col-md-6">
																<label>Payment Mode</label>
																<select class="form-control" name="payment_mode" id="payment_mode" selected="selected">
                                                                    <option value="cash">Cash</option>
                                                                    <option value="card">Card</option>
                                                                    <option value="wallet">Wallet</option>
                                                                <select>
															</div>
                                                            <div class="form-group col-md-6">
																<label>Expense Status</label>
																<select class="form-control" name="expense_status" id="expense_status" selected="selected">
                                                                <option class="text-muted">--Paid/Unpaid/Advance--</option>
                                                                    <option value="paid" name="paid">Paid</option>
                                                                    <option value="advance" name="advance">Advance</option>
                                                                    <option value="unpaid" name="unpaid">Unpaid</option>
                                                                <select>
															</div>
                                                        </div>
                                                        <div class="row">
                                                        <div class="col-md-6">
															<button type="submit" class="btn btn-primary">Submit</button>
                                                            </div>
                                                        </div>
														</form>
														<div class="alert alert-dismissible feedback mt-2" role="alert">
															<button type="button" class="close" data-dismiss="alert" aria-label="Close">
																<span aria-hidden="true">&times;</span>
									           				</button>
															<div class="alert-message">
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>

								<div class="modal fade" id="ModalEditExpenseCategory" tabindex="-1" role="dialog" aria-hidden="true">
									<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title">Edit Expense</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		                      <span aria-hidden="true">&times;</span>
		                    </button>
											</div>
											<div class="modal-body m-3">
												<div class="row">
													<div class="col-md-12">
														<form id="EditExpenseCategory" method="POST" action="#">
															<div class="form-group">
																<label>Category Name</label>
																<input type="text" class="form-control" placeholder="Category Name" name="expense_type">
															</div>
															<div class="form-group">
																<label>Description</label>
																<textarea class="form-control" placeholder="Description" name="expense_type_description"></textarea>
															</div>
															<div class="form-group">
					                      <input class="form-control" type="hidden" name="expense_type_id" readonly="true">
					                    </div>
															<button type="submit" class="btn btn-primary">Submit</button>
														</form>
														<div class="alert alert-dismissible feedback mt-2" role="alert">
															<button type="button" class="close" data-dismiss="alert" aria-label="Close">
																<span aria-hidden="true">&times;</span>
									            </button>
															<div class="alert-message">
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>

								<!-----END------>
								
								<table class="table table-hover table-responsive mt-3">
									<thead>
										<tr class="text-primary">
											<th>Date</th>
											<th>Expense Type</th>
											<th>Item Name</th>
											<th>Employee Name</th>
                                            <th>Amount</th>
											<th>Quantity</th>
											<th>Units</th>
											<th>Payment Mode</th>
                                            <th>Payment Mode</th>
										</tr>
									</thead>
									<tbody>
										<?php
                                            foreach ($expenses as $expense):
                                                
										?>
										<tr>
											<!-- <td><?=$expense['expense_date']?></td>
											<td><?=$expense['expense_type']?></td>
											<td><?=$expense['item_name']?></td>
                                            <td><?=$expense['employee_name']?></td>
											<td><?=$expense['amount']?></td>
											<td><?=$expense['unit']?></td>
                                            <td><?=$expense['quantity']?></td>
                                            <td><?=$expense['payment_mode']?></td>
											<td><?=$expense['expense_status']?></td>								
											<td class="table-action">
												<button type="button" class="btn btn-primary expense-type-edit-btn" >
									        <i class="align-middle" data-feather="edit-2"></i>
									      </button>
											</td> -->
										</tr>	
                                        <?php	
                                        	
											endforeach;
										?>
									</tbody>
								</table>
                                <button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#ModalAddExpense"><i class="fas fa-fw fa-plus"></i>Add Expense</button>
							</div>
                            
						</div>	
					</div>
			</div>
			<div class="row">
				<div class="col-md-6">
						<div class="card">
							<div class="row card-header">
								<div class="card-title col-md-3"> Expense Summary</div>
								<div class="form-group col-md-4">
									<label class="form-label">From</label>
									<input class="form-control" type="date" name="fromDate" value="" />
								</div>
								<div class="col-md-4">
								<label class="form-label">To</label>
									<input class="form-control" type="date" name="toDate" value="" />
								</div>
							</div>
							<div class="card-body">
								<table id="datatables-buttons" class="table table-striped" style="width:100%">
									<thead>
										<tr>
											<th>Total Spend</th>
											<th>Paid</th>
											<th>Unpaid</th>
											<th>Advance</th>
											<th>Total Outflow</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>Date1</td>
											<td>Paid</td>
											<td>0</td>
											<td>61</td>
											<td>201</td>
											
										</tr>
										<tr>
											<td>Date1</td>
											<td>Paid</td>
											<td>0</td>
											<td>63</td>
											<td>201</td>
											
										</tr>
										<tr>
											<td>Date1</td>
											<td>Paid</td>
											<td>0</td>
											<td>66</td>
											<td>200</td>
											
										</tr>
										<tr>
											<td>Grand Total</td>
											<td>Paid</td>
											<td>0</td>
											<td>66</td>
											<td>200</td>
											
										</tr>
										
									</tbody>
								</table>
							</div>
						</div>
				</div>
				<div class="col-md-6">
					<div class="card flex-fill w-100">
						<div class="card-header row">
							<!-- <h5 class="card-title mb-0">Top 5 Expenses</h5>	 -->
							<div class="card-title col-md-3">Top 5 Expenses</div>
								<div class="form-group col-md-4">
									<label class="form-label">From</label>
									<input class="form-control" type="date" name="fromDate" value="" />
								</div>
								<div class="col-md-4">
								<label class="form-label">To</label>
									<input class="form-control" type="date" name="toDate" value="" />
								</div>								
						</div>
						<div class="card-body">
							<div class="chart chart-lg">
								<canvas id="chartjs-dashboard-bar3"></canvas>
							</div>					
						</div>
					</div>
				</div>
			</div>
										</div>
					<?php
						}
					?>
					
				</div>
						
			</div>
			
		</main>
<?php
	$this->load->view('business_admin/ba_footer_view');
?>
<script type="text/javascript">
	$(document).ready(function(){
		// Daterangepicker
		// $("input[name=\"daterange\"]").daterangepicker({
		// 		opens: "left"
		// 	});
		// 	$("input[name=\"datetimes\"]").daterangepicker({
		// 		timePicker: true,
		// 		opens: "left",
		// 		startDate: moment().startOf("hour"),
		// 		endDate: moment().startOf("hour").add(32, "hour"),
		// 		locale: {
		// 			format: "M/DD hh:mm A"
		// 		}
		// 	});
			$("input[name=\"datesingle\"]").daterangepicker({
				singleDatePicker: true,
				showDropdowns: true
			});
			var start = moment().subtract(29, "days");
			var end = moment();

			function cb(start, end) {
				$("#reportrange span").html(start.format("MMMM D, YYYY") + " - " + end.format("MMMM D, YYYY"));
			}
			// $("#reportrange").daterangepicker({
			// 	startDate: start,
			// 	endDate: end,
			// 	ranges: {
			// 		"Today": [moment(), moment()],
			// 		"Yesterday": [moment().subtract(1, "days"), moment().subtract(1, "days")],
			// 		"Last 7 Days": [moment().subtract(6, "days"), moment()],
			// 		"Last 30 Days": [moment().subtract(29, "days"), moment()],
			// 		"This Month": [moment().startOf("month"), moment().endOf("month")],
			// 		"Last Month": [moment().subtract(1, "month").startOf("month"), moment().subtract(1, "month").endOf("month")]
			// 	}
			// }, cb);
			// cb(start, end);
			//end datepicker 
		$(document).ajaxStart(function() {
      $("#load_screen").show();
    });

    $(document).ajaxStop(function() {
      $("#load_screen").hide();
    });
	  	
  	$("#AddExpense").validate({
	  	errorElement: "div",
	    rules: {
			"expense_date" : {
            required : true,
            maxlength : 10
	        } ,
	        "expense_type" : {
            required : true,
            maxlength : 50
	        } ,
            "item_name" : {
            required : true,
            maxlength : 50
	        },
            "amount" : {
            required : true,
            maxlength : 10
	        },
            "quantity" : {
            required : true,
            maxlength : 10
	        }, 
            "unit" : {
            required : true,
            maxlength : 10
	        }, 
            "payment_mode" : {
            required : true,
            maxlength : 50
	        },    
            "expense_status" : {
            required : true,
            maxlength : 50
	        }
	    },
	    submitHandler: function(form) {
				var formData = $("#AddExpense").serialize(); 
				$.ajax({
		        url: "<?=base_url()?>index.php/BusinessAdmin/expenses/",
		        data: formData,
		        type: "POST",
		        crossDomain: true,
						cache: false,
		        dataType : "json",
		    		success: function(data) {
              if(data.success == 'true'){ 
              	$("#ModalAddExpense").modal('hide');
				$('#defaultModalSuccess').modal('show').on('shown.bs.modal', function (e) {
					$("#SuccessModalMessage").html("").html(data.message);
				}).on('hidden.bs.modal', function (e) {
						window.location.reload();
				});
              }
              else if (data.success == 'false'){                   
          	    if($('.feedback').hasClass('alert-success')){
                  $('.feedback').removeClass('alert-success').addClass('alert-danger');
                }
                else{
                  $('.feedback').addClass('alert-danger');
                }
                $('.alert-message').html("").html(data.message); 
              }
            },
            error: function(data){
    					$('.feedback').addClass('alert-danger');
    					$('.alert-message').html("").html(data.message); 
            }
				});
			},
		});

		$("#EditExpense").validate({
	  	errorElement: "div",
	    rules : {
      	"expense_type" : {
      	  required : true,
        	maxlength : 100
      	}
      },
	    submitHandler: function(form) {
				var formData = $("#EditExpense").serialize(); 
				$.ajax({
		        url: "<?=base_url()?>index.php/BusinessAdmin/EditExpense/",
		        data: formData,
		        type: "POST",
		        crossDomain: true,
						cache: false,
		        dataType : "json",
		    		success: function(data) {
              if(data.success == 'true'){
              	$("#ModalEditExpense").modal('hide');
								$('#defaultModalSuccess').modal('show').on('shown.bs.modal', function (e) {
									$("#SuccessModalMessage").html("").html(data.message);
								}).on('hidden.bs.modal', function (e) {
										window.location.reload();
								});
              }
              else if (data.success == 'false'){                   
          	    if($('.feedback').hasClass('alert-success')){
                  $('.feedback').removeClass('alert-success').addClass('alert-danger');
                }
                else{
                  $('.feedback').addClass('alert-danger');
                }
                $('.alert-message').html("").html(data.message); 
              }
            },
            error: function(data){
    					$('.feedback').addClass('alert-danger');
    					$('.alert-message').html("").html(data.message); 
            }
				});
			},
		});

	// 	$('.expense-type-edit-btn').click(function(event) {
    //   event.preventDefault();
    //   this.blur(); // Manually remove focus from clicked link.
    //   var parameters = {
    //     expense_type_id : $(this).attr('expense_type_id')
    //   };
    //   $.getJSON("<?=base_url()?>index.php/BusinessAdmin/GetExpenseType/", parameters)
    //   .done(function(data, textStatus, jqXHR) { 
    //     $("#EditExpense input[name=expense_type]").attr('value',data.expense_type);
    //     $("#EditExpense textarea[name=expense_type_description]").val(data.expense_type_description);
    //     $("#EditExpense input[name=expense_type_id]").attr('value',data.expense_type_id);

    //     $("#ModalEditExpense").modal('show');
    // 	})
    // 	.fail(function(jqXHR, textStatus, errorThrown) {
    //     console.log(errorThrown.toString());
   	// 	});
    // });

  });
</script>
<script>
	$(function() {
		// Bar chart
		new Chart(document.getElementById("chartjs-dashboard-bar3"), {
			type: "bar",
			data: {
				labels: ["Wi-Fi", "Daily Snacks", "Monthly rent", "Consumables", "Stationaries"],
				datasets: [{
					label: "Expenses (In Rupees)",
					backgroundColor: window.theme.warning,
					borderColor: window.theme.primary,
					hoverBackgroundColor: window.theme.primary,
					hoverBorderColor: window.theme.primary,
					data: [15, 17, 8, 5, 6, 5, 12]
				}]
			},
			options: {
				maintainAspectRatio: false,
				legend: {
					display: true
				},
				scales: {
					yAxes: [{
						gridLines: {
							display: false
						},
						stacked: false,
						ticks: {
							stepSize: 10
						}
					}],
					xAxes: [{
						barPercentage: .75,
						categoryPercentage: .5,
						stacked: false,
						gridLines: {
							color: "transparent"
						}
					}]
				}
			}
		});
	});
</script>