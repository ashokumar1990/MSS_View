		<script src="<?=base_url()?>public/app_stack/js/app.js"></script>
		<script src="<?=base_url()?>public/app_stack/js/validation.js"></script>
	</body>
</html>