<?php
	$this->load->view('universal/header_view');
?>
<div class="wrapper">
	<main class="content" style="width: 80%; margin-left: 10%;">
		<div class="container-fluid p-0">
			<div class="row">
				<div class="col-md-12">
					<div class="row">
						<div class="col-md-7">
							<?php
								echo "<h4 style='text-align: end;margin-bottom: 30px;'>".$shop_details['business_outlet_bill_header_msg']."</h4>";
							?>
						</div>
						<div class="col-md-5" style="text-align: end;"><button class="btn btn-primary btn-outline" onClick="window.print()">Print</button></div>
					</div>
				</div>
				<div class="col-md-12">
					<?php
						if(!isset($cart) || empty($cart)){
					?>
					
					<div class="alert alert-secondary alert-outline alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
            	<span aria-hidden="true">×</span>
          	</button>
						<div class="alert-icon">
							<i class="far fa-fw fa-bell"></i>
						</div>
						<div class="alert-message">
							<strong>Hello there!</strong> Cart is empty!
						</div>
					</div>
					
					<?php
						}
						else{
					?>
					<table class="table table-hover">
						<thead>
							<tr>
								<th>Service Name</th>
								<th>Price</th>
								<th>Qty</th>
								<th>Expert</th>
							</tr>
						</thead>
						<tbody>
							<?php
								foreach ($cart as $item):
							?>
							<tr>
								<td><?=$item['service_name']?></td>
								<td><?=$item['service_total_value']?></td>
								<td><?=$item['service_quantity']?></td>
								<td>
									<?php
										$key = array_search($item['service_expert_id'], array_column($experts, 'employee_id'));
										echo $experts[$key]['employee_first_name'].' '.$experts[$key]['employee_last_name'];
									?>
								</td>	
							</tr>	
							<?php		
								endforeach;
							?>
						</tbody>
					</table>
					<?php
						}
					?>
				</div>
				<div class="col-md-12 mt-3">
					<?php
						if(isset($cart) && !empty($cart)):
					?>
					<div class="mb-3">
						<table class="table table-hover">
							<tbody>
								<tr>
									<td>Total Bill</td>
									<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i>
									<?php
										$total_bill_before = 0;
										$discount_given = 0;
										$actual_bill = 0;
										foreach ($cart as $item) {
											$total_bill_before += ((int)$item['service_price_inr'] * (int) $item['service_quantity']);

											$discount_given += ((int)$item['service_price_inr'] * (int) $item['service_quantity']) - (int)$item['service_total_value']; 
										}

										$actual_bill = $total_bill_before - $discount_given;

										if(isset($payment['discount_info']['cart_discount_absolute'])){
											if($payment['discount_info']['cart_discount_percentage'] == 0){
												$discount_given += (int)$payment['discount_info']['cart_discount_absolute'];
											}
										}

										if(isset($payment['discount_info']['cart_discount_percentage'])){
											if($payment['discount_info']['cart_discount_absolute'] == 0){
												$discount_given += round((((int)$payment['discount_info']['cart_discount_percentage'])/100) * $actual_bill);
											}
										}	

										$actual_bill = $total_bill_before - $discount_given;
										
										echo $total_bill_before;
									?>/-
									</td>
								</tr>
								<tr>
									<td>Package Applied</td>
									<td></td>
								</tr>
								<tr>
									<td>Discount</td>
									<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i>
										<?=$discount_given?>/-
									</td>
								</tr>
								<!-- <tr>
									<td>Wallet Balance Used</td>
									<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i></td>
								</tr>
								<tr>
									<td>Deal Discount</td>
									<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i></td>
								</tr>
								<tr>
									<td>Cashback Used</td>
									<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i></td>
								</tr> -->
								<tr>
									<td><strong>Final Payable Amount</strong></td>
									<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i>
										<?=$actual_bill?>/-
									</td>
								</tr>
								<tr><td></td><td></td></tr>
								<?php if(!empty($payment['full_payment_info']) || !empty($payment['split_payment_info'])){ 
									if(!empty($payment['full_payment_info'])) { ?>
								<tr>
									<td>Payment Type</td>
									<td><?=$payment['full_payment_info']['payment_type']?></td>
								</tr>
								<tr>
									<td>Amount Received</td>
									<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i><?=$payment['full_payment_info']['total_amount_received']?></td>
								</tr>
								<tr>
									<td>Balance to be paid back</td>
									<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i><?=$payment['full_payment_info']['balance_to_be_paid_back']?></td>
								</tr>
								<tr>
									<td>Pending Amount</td>
									<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i><?=$payment['full_payment_info']['pending_amount']?></td>
								</tr>
								<?php 
									}
									else{
								?>
								<tr>
									<td>Payment Type</td>
									<td>Split Payment</td>
								</tr>
								<tr>
									<td>Amount Received</td>
									<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i><?=$payment['split_payment_info']['total_amount_received']?></td>
								</tr>
								<tr>
									<td>Balance to be paid back</td>
									<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i><?=$payment['split_payment_info']['balance_to_be_paid_back']?></td>
								</tr>
								<tr>
									<td>Pending Amount</td>
									<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i><?=$payment['split_payment_info']['total_pending_amount']?></td>
								</tr>	
								<?php
									}
								 }
								?>
							</tbody>
						</table>
					</div>
					<?php
						endif;
					?>
				</div>
				<div class="col-md-12">
					<?php
						echo "<h4 style='text-align: center;margin-top: 30px;'>".$shop_details['business_outlet_bill_footer_msg']."</h4>";
					?>
				</div>
			</div>
		</div>
	</main>
<?php
	$this->load->view('universal/footer_view');
?>