<?php
	$this->load->view('cashier/cashier_header_view');
?>
<div class="wrapper">
	<?php
		$this->load->view('cashier/cashier_nav_view');
	?>

	<div class="main">
		<?php
			 $this->load->view('cashier/cashier_top_nav_view');
		?>
		<main class="content">
			<div class="container-fluid p-0">
				<div class="row">
					<div class="col-md-10">
						<div class="form-group">
							<div class="input-group">
								<input type="text" placeholder="Search Customer by name/contact no." class="form-control" id="SearchCustomer">
								<span class="input-group-append">
						      <button class="btn btn-secondary" type="button" id="SearchCustomerButton" Customer-Id="Nothing">Go!</button>
						    </span>
							</div>
						</div>
					</div>
					<div class="col-md-2">
						<button data-toggle="modal" data-target="#ModalAddCustomer" class="btn btn-primary">Add Customer</button>
						<!--MODAL AREA START---->

						<?php
							$this->load->view('cashier/cashier_success_modal_view');
							$this->load->view('cashier/cashier_error_modal_view');
						?>


						<div id="ModalAddCustomer" tabindex="-1" role="dialog" aria-hidden="true" class="modal fade">
							<div role="document" class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<h5 class="modal-title">Add New Customer</h5>
										<button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
									</div>
									<div class="modal-body m-3">
										<form action="#" method="POST" id="AddNewCustomer">
											<div class="form-group">
												<label>Title</label>
												<select class="form-control" name="customer_title">
													<option value="Mr.">Mr.</option>
													<option value="Ms.">Ms.</option>
												</select>
											</div>
											<div class="form-group">
												<label class="form-label">Name</label>
												<input type="text" placeholder="Enter Name" class="form-control" name="customer_name">
											</div>
											<div class="form-group">
												<label class="form-label">Mobile</label>
												<input type="text" data-mask="0000000000" placeholder="Enter Mobile" class="form-control" name="customer_mobile">
											</div>
											<div class="form-group">
												<label class="form-labe">Date of birth</label>
												<input type="text" class="form-control date" name="customer_dob">
											</div>
											<button type="submit" class="btn btn-primary">Submit</button>
											<button class="btn btn-primary" id="SkipCustomerDetails">Skip</button>
										</form>
										<div class="alert alert-dismissible feedback mt-2" role="alert">
											<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
					            </button>
												<div class="alert-message"></div>
										</div>
									</div>
									<div  class="modal-footer">
										<button  type="button" data-dismiss="modal" class="btn btn-success">Close
										</button>
									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="ModalCustomerDetails" tabindex="-1" role="dialog" aria-hidden="true">
							<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<h5 class="modal-title">Customer Details</h5>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
									</div>
									<div class="modal-body m-3">
										<div class="row">
											<div class="col-md-12">
												<form id="EditCustomerDetails" method="POST" action="#">
													<div id="smartwizard-arrows-primary" class="wizard wizard-primary mb-4">
														<ul>
															<li><a href="#arrows-primary-step-1">Personal Details<br /></a></li>
															<li><a href="#arrows-primary-step-2">Preferred Services<br /></a></li>
															<li><a href="#arrows-primary-step-3">Transactional Details<br /></a></li>
														</ul>

														<div>
															<div id="arrows-primary-step-1" class="">
																<div class="form-row">
																	<div class="form-group col-md-6">
																		<label>Title</label>
																		<select class="form-control" name="customer_title" disabled>
																			<option value="Mr.">Mr.</option>
																			<option value="Ms.">Ms.</option>
																		</select>
																	</div>
																	<div class="form-group col-md-6">
																		<label>Name</label>
																		<input type="text" class="form-control" placeholder="Name" name="customer_name" readonly>
																	</div>
																</div>
																<div class="form-row">
																	<div class="form-group col-md-6">
																		<label>Mobile</label>
																		<input type="text" class="form-control" placeholder="Mobile Number" data-mask="0000000000" name="customer_mobile" readonly>
																	</div>
																	<div class="form-group col-md-6">
																		<label>Next Appointment Date</label>
																		<input type="text" class="form-control date" placeholder="Appointment Date" name="next_appointment_date" disabled>
																	</div>
																</div>
																<div class="form-row">
																	<div class="form-group col-md-6">
																		<label>Date of Birth</label>
																		<input type="text" class="form-control" placeholder="Date of Birth" name="customer_dob" readonly>
																	</div>
																	<div class="form-group col-md-6">
																		<label>Pending Amount</label>
																		<input type="Number" class="form-control" placeholder="Pending Amount" name="customer_pending_amount" readonly>
																	</div>
																</div>
																<div class="form-row">
																	<div class="form-group col-md-6">
																		<label>DOA</label>
																		<input type="text" class="form-control" placeholder="Date of Addition" name="customer_doa" readonly>
																	</div>
																	<div class="form-group col-md-6">
																		<label>Virtual Wallet</label>
																		<input type="number" class="form-control" placeholder="Virtual Wallet" name="customer_virtual_wallet" readonly>
																	</div>
																</div>
																<div class="form-row">
																	<div class="form-group col-md-6">
																		<label>Package Name</label>
																		<input type="text" class="form-control" placeholder="Package Name" name="package_name" disabled>
																	</div>
																	<div class="form-group col-md-6">
																		<label>Deals</label>
																		<input type="text" class="form-control" placeholder="Corp Deal/offers" name="deals" disabled>
																	</div>
																</div>
																<div class="form-row">
																	<div class="form-group col-md-6">
																		<label>Credit</label>
																		<input type="number" class="form-control" placeholder="Credit Value" name="customer_credit_value" disabled>
																	</div>
																	<div class="form-group col-md-6">
																		<label>Reward</label>
																		<input type="number" class="form-control" placeholder="Reward Point" name="reward_point" readonly disabled>
																	</div>
																</div>
																<div class="form-row">
																	<div class="form-group col-md-6">
																		<label>Total Billing</label>
																		<input type="number" class="form-control" placeholder="Total Billing" name="total_billing" disabled>
																	</div>
																	<div class="form-group col-md-6">
																		<label>Customer Segment</label>
																		<select class="form-control" name="customer_segment">
																			<option value="New">New</option>
																			<option value="Repeating">Repeating</option>
																		</select>
																	</div>
																</div>
																<div class="form-row">
																	<div class="form-group col-md-6">
																		<label>Average Order Value</label>
																		<input type="text" class="form-control" placeholder="Average Order Value" name="avg_order_value" disabled>
																	</div>
																	<div class="form-group col-md-6">
																		<label>Total Visit</label>
																		<input type="text" class="form-control" placeholder="Total Visits" name="total_visits" disabled>
																	</div>
																</div>
																<div class="form-row">
																	<div class="form-group col-md-6">
																		<label>Last visit order value</label>
																		<input type="text" class="form-control" placeholder="Order Value" name="last_visit_order_value" disabled>
																	</div>
																	<div class="form-group col-md-6">
																		<label>Last Visit Date</label>
																		<input type="text" class="form-control date" placeholder="Date" name="last_visit_date" disabled>
																	</div>
																</div>
															</div>
															<div id="arrows-primary-step-2" class="">
																<div class="form-row">
																	<div class="form-group col-md-6">
																		<label>Preferred Day</label>
																		<input type="text" class="form-control" placeholder="Preferred Day" name="preferred_day" disabled>
																	</div>
																	<div class="form-group col-md-6">
																		<label>Preferred Service</label>
																		<input type="text" class="form-control" placeholder="Preferred Service" name="preferred_service" disabled>
																	</div>
																</div>
																<div class="form-row">
																	<div class="form-group col-md-6">
																		<label>Preferred Time</label>
																		<input type="text" class="form-control" placeholder="Preferred Time" name="preferred_time" disabled>
																	</div>
																	<div class="form-group col-md-6">
																		<label>Avg. Feedback Rating</label>
																		<input type="text" class="form-control" placeholder="Ratings" name="avg_feedback_rating" disabled>
																	</div>
																</div>
																<div class="form-row">
																	<div class="form-group col-md-6">
																		<label>Recommended Servie</label>
																		<input type="text" class="form-control" placeholder="Recommended Servie" name="recommended_service" disabled>
																	</div>
																</div>
															</div>
															<div id="arrows-primary-step-3" class="">
																<div class="form-group">
						                      <input class="form-control" type="hidden" name="customer_id" readonly="true">
						                    </div>
																<button type="submit" class="btn btn-primary">Submit</button>
															</div>
														</div>
													</div>	
												</form>
												<div class="alert alert-dismissible feedback mt-0 mb-0" role="alert">
													<button type="button" class="close" data-dismiss="alert" aria-label="Close">
														<span aria-hidden="true">&times;</span>
							            </button>
													<div class="alert-message">
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="modal-footer">
										<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
									</div>
								</div>
							</div>
						</div>

						<!----MODAL AREA END--->
					</div>
				</div>
				
				<div class="row">
					<?php
						if(!isset($customers) || empty($customers)){
					?>
					<div class="col-md-6">
						<div class="alert alert-secondary alert-outline alert-dismissible" role="alert">
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
	            	<span aria-hidden="true">×</span>
	          	</button>
							<div class="alert-icon">
								<i class="far fa-fw fa-bell"></i>
							</div>
							<div class="alert-message">
								<strong>Hello there!</strong> No Customer is currently being served!
							</div>
						</div>
					</div>
					<?php
						}
						else{
							foreach ($customers as $customer) {
						?>
					
					<div class="col-md-3 col-sm-6 d-flex">
						<div class="card flex-fill">
							<div class="card-body my-2">
								<div class="row d-flex align-items-center mb-4">
									<div class="col-12">
										<h4 class="d-flex font-weight-light"><?php echo "".$customer['customer_title'].' '.$customer['customer_name'].""; ?></h4>
										<h6 class="d-flex mb-0 font-weight-light"><?=$customer['customer_mobile']?></h6>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
											<a href="<?=base_url()?>index.php/Cashier/PerformBilling/<?=$customer['customer_id']?>" class="btn btn-outline-primary btn-lg">Start Billing</a>
									</div>
								</div>
							</div>
						</div>
					</div>
						<?php	
							}
						}
					?>
				</div>
			</div>
		</main>
<?php
	$this->load->view('cashier/cashier_footer_view');
?>
<script type="text/javascript">
	$(".date").daterangepicker({
		singleDatePicker: true,
		showDropdowns: true,
		autoUpdateInput : false,
		locale: {
      format: 'YYYY-MM-DD'
		}
	});

	$('.date').on('apply.daterangepicker', function(ev, picker) {
    $(this).val(picker.startDate.format('YYYY-MM-DD'));
  });
</script>
<script type="text/javascript">
	$(document).ready(function(){
		/*$(document).ajaxStart(function() {
      $("#load_screen").show();
    });

    $(document).ajaxStop(function() {
      $("#load_screen").hide();
    });*/

		$("#smartwizard-arrows-primary").smartWizard({
			theme: "arrows",
			showStepURLhash: false
		});

		//functionality for getting the dynamic input data
    $("#SearchCustomer").typeahead({
      autoselect: true,
      highlight: true,
      minLength: 1
    },
    {
      source: SearchCustomer,
      templates: {
        empty: "No Customer Found!",
        suggestion: _.template("<p><%- customer_name %>, <%- customer_mobile %></p>")
      }
    });
       
    var to_fill = "";

    $("#SearchCustomer").on("typeahead:selected", function(eventObject, suggestion, name) {
      var loc = "#SearchCustomer";
      to_fill = suggestion.customer_name+","+suggestion.customer_mobile;
      setVals(loc,to_fill,suggestion.customer_id);
    });

    $("#SearchCustomer").blur(function(){
      $("#SearchCustomer").val(to_fill);
      to_fill = "";
    });

    function SearchCustomer(query, cb){
      var parameters = {
        query : query
      };
      $.getJSON("<?=base_url()?>index.php/Cashier/GetCustomerData/", parameters)
      .done(function(data, textStatus, jqXHR) {
        cb(data.message);
      })
      .fail(function(jqXHR, textStatus, errorThrown) {
        // log error to browser's console
        console.log(errorThrown.toString());
      });
    }  

    function setVals(element,fill,customer_id){
      $(element).attr('value',fill);
      $(element).val(fill);
      $("#SearchCustomerButton").attr('Customer-Id',customer_id);
    }

    $("#SearchCustomerButton").click(function(event){
    	event.preventDefault();
      this.blur();
      var customer_id = $(this).attr('Customer-Id');
      if(customer_id == "Nothing"){
      	$('#centeredModalDanger').modal('show').on('shown.bs.modal', function (e) {
					$("#ErrorModalMessage").html("").html("Please select customer!");
				});
      }
      else{
	      var parameters = {
	        customer_id : $(this).attr('Customer-Id')
	      };
	      $("#SearchCustomerButton").attr('Customer-Id',"Nothing");
	      $.getJSON("<?=base_url()?>index.php/Cashier/GetCustomer/", parameters)
	      .done(function(data, textStatus, jqXHR) { 
	      	$("#EditCustomerDetails select[name=customer_title]").val(data.customer_title);
	        $("#EditCustomerDetails input[name=customer_name]").attr('value',data.customer_name);
	        $("#EditCustomerDetails input[name=customer_mobile]").attr('value',data.customer_mobile);
	        $("#EditCustomerDetails input[name=customer_doa]").attr('value',data.customer_doa);
	        $("#EditCustomerDetails input[name=customer_dob]").attr('value',data.customer_dob);
	        $("#EditCustomerDetails input[name=customer_pending_amount]").attr('value',data.customer_pending_amount);
	        $("#EditCustomerDetails input[name=customer_virtual_wallet]").attr('value',data.customer_virtual_wallet);
	        $("#EditCustomerDetails select[name=customer_segment]").val(data.customer_segment);
					$("#EditCustomerDetails input[name=customer_id]").attr('value',data.customer_id);	       
	        $("#ModalCustomerDetails").modal('show');
	    	})
	    	.fail(function(jqXHR, textStatus, errorThrown) {
	        console.log(errorThrown.toString());
	   		});
	    }
    });

    $("#EditCustomerDetails").validate({
	  	errorElement: "div",
	    rules: {
	        "customer_segment" : {
            required : true
	        }
	    },
	    submitHandler: function(form) {
				var formData = $("#EditCustomerDetails").serialize(); 
				$.ajax({
		        url: "<?=base_url()?>index.php/Cashier/EditCustomerDetails/",
		        data: formData,
		        type: "POST",
		        crossDomain: true,
						cache: false,
		        dataType : "json",
		    		success: function(data) {
              if(data.success == 'true'){
              	$("#ModalCustomerDetails").modal('hide'); 
								$('#centeredModalSuccess').modal('show').on('shown.bs.modal', function (e){
									$("#SuccessModalMessage").html("").html(data.message);
								}).on('hidden.bs.modal', function (e) {
										window.location.reload();
								});
              }
              else if (data.success == 'false'){                   
          	    if($('.feedback').hasClass('alert-success')){
                  $('.feedback').removeClass('alert-success').addClass('alert-danger');
                }
                else{
                  $('.feedback').addClass('alert-danger');
                }
                $('.alert-message').html("").html(data.message); 
              }
            },
            error: function(data){
    					$('.feedback').addClass('alert-danger');
    					$('.alert-message').html("").html(data.message); 
            }
				});
			},
		});

    $("#AddNewCustomer").validate({
	  	errorElement: "div",
	    rules: {
	        "customer_title" : {
            required : true
	        },
	        "customer_name" : {
            required : true,
            maxlength : 100
	        },
	        "customer_mobile" : {
	          required : true,
	          maxlength : 15
	        },
	        "customer_dob" : {
	        	required : true
	        }
	    },
	    submitHandler: function(form) {
				var formData = $("#AddNewCustomer").serialize(); 
				$.ajax({
	        url: "<?=base_url()?>index.php/Cashier/AddNewCustomer/",
	        data: formData,
	        type: "POST",
	        crossDomain: true,
					cache: false,
	        dataType : "json",
	    		success: function(data) {
            if(data.success == 'true'){
            	$("#ModalAddCustomer").modal('hide'); 
							$('#centeredModalSuccess').modal('show').on('shown.bs.modal', function (e){
								$("#SuccessModalMessage").html("").html(data.message);
							}).on('hidden.bs.modal', function (e) {
									window.location.reload();
							});
            }
            else if (data.success == 'false'){                   
        	    if($('.feedback').hasClass('alert-success')){
                $('.feedback').removeClass('alert-success').addClass('alert-danger');
              }
              else{
                $('.feedback').addClass('alert-danger');
              }
              $('.alert-message').html("").html(data.message); 
            }
          },
          error: function(data){
  					$('.feedback').addClass('alert-danger');
  					$('.alert-message').html("").html(data.message); 
          }
				});
			},
		});

	});
</script>