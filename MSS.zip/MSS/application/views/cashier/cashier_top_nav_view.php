<nav class="navbar navbar-expand navbar-light bg-white">
	<a class="sidebar-toggle d-flex mr-2">
		<i class="hamburger align-self-center"></i>
	</a>
	<div class="navbar-collapse collapse">
		<ul class="navbar-nav ml-auto">
			<li class="nav-item" style="margin-top: 8px;margin-right: 16px;">
		  	<img src="<?=base_url()?>public/images/shop_icon.jpg" class="avatar img-fluid rounded-circle mr-1" alt="Business Admin" /> 
		    <?php
		    	echo "<span class=\"text-dark\">".$cashier_details['business_outlet_name']."</span>";
				?>
			</li>
			<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle d-none d-sm-inline-block" href="#" data-toggle="dropdown">
			    <img src="<?=base_url()?>public/images/default.png" class="avatar img-fluid rounded-circle mr-1" alt="Cashier" /> <span class="text-dark"><?=$cashier_details['employee_first_name']?> <?=$cashier_details['employee_last_name']?></span>
			  	</a>
				<div class="dropdown-menu dropdown-menu-right">
					<a class="dropdown-item" href="<?=base_url()?>index.php/Cashier/Profile/"><i class="align-middle mr-1" data-feather="user"></i> Profile</a>
					<a class="dropdown-item" href="<?=base_url()?>index.php/Cashier/Logout/">Sign out</a>
				</div>
			</li>
		</ul>
	</div>
</nav>