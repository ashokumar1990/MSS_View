<?php
	$this->load->view('cashier/cashier_header_view');
?>
<div class="wrapper">
	<?php
		$this->load->view('cashier/cashier_nav_view');
	?>
	<div class="main">
		<?php
			$this->load->view('cashier/cashier_top_nav_view');
		?>
		<main class="content">
			<div class="container-fluid p-0">
				<div class="row">
					<div class="col-md-12">
						<button class="btn btn-outline-primary btn-lg" data-toggle="modal" data-target="#ModalCustomerDetails" Customer-Id="<?=$individual_customer['customer_id']?>" id="EditCustomerDetails"><?=$individual_customer['customer_name']?></button>
						<?php
							$this->load->view('cashier/cashier_success_modal_view');
							$this->load->view('cashier/cashier_error_modal_view');
						?>
					</div>
					<div class="col-md-12 mt-2">
						<div class="row">
							<div class="col-md-7">
								<div id="ServiceSection">
									<!----- Modal Area------->

								<div class="modal fade" id="ModalCustomerDetails" tabindex="-1" role="dialog" aria-hidden="true">
										<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
											<div class="modal-content">
												<div class="modal-header">
													<h5 class="modal-title">Customer Details</h5>
													<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			                      <span aria-hidden="true">&times;</span>
			                    </button>
												</div>
												<div class="modal-body m-3">
													<div class="row">
														<div class="col-md-12">
															<div id="EditCustomerDetails">
																<div id="smartwizard-arrows-primary" class="wizard wizard-primary mb-4">
																	<ul>
																		<li><a href="#arrows-primary-step-1">Personal Details<br /></a></li>
																		<li><a href="#arrows-primary-step-2">Preferred Services<br /></a></li>
																		<li><a href="#arrows-primary-step-3">Transactional Details<br /></a></li>
																	</ul>

																	<div>
																		<div id="arrows-primary-step-1" class="">
																			<div class="form-row">
																				<div class="form-group col-md-6">
																					<label>Title</label>
																					<select class="form-control" name="customer_title" readonly>
																						<option value="Mr.">Mr.</option>
																						<option value="Ms.">Ms.</option>
																					</select>
																				</div>
																				<div class="form-group col-md-6">
																					<label>Name</label>
																					<input type="text" class="form-control" placeholder="Name" name="customer_name" readonly>
																				</div>
																			</div>
																			<div class="form-row">
																				<div class="form-group col-md-6">
																					<label>Mobile</label>
																					<input type="text" class="form-control" placeholder="Mobile Number" data-mask="0000000000" name="customer_mobile" readonly>
																				</div>
																				<div class="form-group col-md-6">
																					<label>Next Appointment Date</label>
																					<input type="text" class="form-control date" placeholder="Appointment Date" name="next_appointment_date" disabled>
																				</div>
																			</div>
																			<div class="form-row">
																				<div class="form-group col-md-6">
																					<label>Date of Birth</label>
																					<input type="text" class="form-control" placeholder="Date of Birth" name="customer_dob" readonly>
																				</div>
																				<div class="form-group col-md-6">
																					<label>Pending Amount</label>
																					<input type="Number" class="form-control" placeholder="Pending Amount" name="customer_pending_amount" readonly>
																				</div>
																			</div>
																			<div class="form-row">
																				<div class="form-group col-md-6">
																					<label>DOA</label>
																					<input type="text" class="form-control" placeholder="Date of Addition" name="customer_doa" readonly>
																				</div>
																				<div class="form-group col-md-6">
																					<label>Virtual Wallet</label>
																					<input type="number" class="form-control" placeholder="Virtual Wallet" name="customer_virtual_wallet" readonly>
																				</div>
																			</div>
																			<div class="form-row">
																				<div class="form-group col-md-6">
																					<label>Package Name</label>
																					<input type="text" class="form-control" placeholder="Package Name" name="package_name" disabled>
																				</div>
																				<div class="form-group col-md-6">
																					<label>Deals</label>
																					<input type="text" class="form-control" placeholder="Corp Deal/offers" name="deals" disabled>
																				</div>
																			</div>
																			<div class="form-row">
																				<div class="form-group col-md-6">
																					<label>Credit</label>
																					<input type="number" class="form-control" placeholder="Credit Value" name="customer_credit_value" disabled>
																				</div>
																				<div class="form-group col-md-6">
																					<label>Reward</label>
																					<input type="number" class="form-control" placeholder="Reward Point" name="reward_point" readonly disabled>
																				</div>
																			</div>
																			<div class="form-row">
																				<div class="form-group col-md-6">
																					<label>Total Billing</label>
																					<input type="number" class="form-control" placeholder="Total Billing" name="total_billing" disabled>
																				</div>
																				<div class="form-group col-md-6">
																					<label>Customer Segment</label>
																					<select class="form-control" name="customer_segment" readonly>
																						<option value="New">New</option>
																						<option value="Repeating">Repeating</option>
																					</select>
																				</div>
																			</div>
																			<div class="form-row">
																				<div class="form-group col-md-6">
																					<label>Average Order Value</label>
																					<input type="text" class="form-control" placeholder="Average Order Value" name="avg_order_value" disabled>
																				</div>
																				<div class="form-group col-md-6">
																					<label>Total Visit</label>
																					<input type="text" class="form-control" placeholder="Total Visits" name="total_visits" disabled>
																				</div>
																			</div>
																			<div class="form-row">
																				<div class="form-group col-md-6">
																					<label>Last visit order value</label>
																					<input type="text" class="form-control" placeholder="Order Value" name="last_visit_order_value" disabled>
																				</div>
																				<div class="form-group col-md-6">
																					<label>Last Visit Date</label>
																					<input type="text" class="form-control date" placeholder="Date" name="last_visit_date" disabled>
																				</div>
																			</div>
																		</div>
																		<div id="arrows-primary-step-2" class="">
																			<div class="form-row">
																				<div class="form-group col-md-6">
																					<label>Preferred Day</label>
																					<input type="text" class="form-control" placeholder="Preferred Day" name="preferred_day" disabled>
																				</div>
																				<div class="form-group col-md-6">
																					<label>Preferred Service</label>
																					<input type="text" class="form-control" placeholder="Preferred Service" name="preferred_service" disabled>
																				</div>
																			</div>
																			<div class="form-row">
																				<div class="form-group col-md-6">
																					<label>Preferred Time</label>
																					<input type="text" class="form-control" placeholder="Preferred Time" name="preferred_time" disabled>
																				</div>
																				<div class="form-group col-md-6">
																					<label>Avg. Feedback Rating</label>
																					<input type="text" class="form-control" placeholder="Ratings" name="avg_feedback_rating" disabled>
																				</div>
																			</div>
																			<div class="form-row">
																				<div class="form-group col-md-6">
																					<label>Recommended Servie</label>
																					<input type="text" class="form-control" placeholder="Recommended Servie" name="recommended_service" disabled>
																				</div>
																			</div>
																		</div>
																		<div id="arrows-primary-step-3" class="">
																			<div class="form-group">
																		</div>
																	</div>
																</div>	
															</div>
															<div class="alert alert-dismissible feedback mt-0 mb-0" role="alert">
																<button type="button" class="close" data-dismiss="alert" aria-label="Close">
																	<span aria-hidden="true">&times;</span>
										            </button>
																<div class="alert-message">
																</div>
															</div>
														</div>
													</div>
												</div>
												<div class="modal-footer">
													<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
												</div>
											</div>
										</div>
									</div>
									</div>

									<div id="ModalServiceDetails" tabindex="-1" role="dialog" aria-hidden="true" class="modal fade">
										<div role="document" class="modal-dialog modal-lg">
											<div class="modal-content">
												<div class="modal-header">
													<h5 class="modal-title">Service/Product Details</h5>
													<button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
												</div>
												<div class="modal-body m-3">
													<form action="#" method="POST" id="ServiceDetails">
														<div class="form-group">
															<label class="form-label">Service/Product</label>
															<input type="text" class="form-control" name="service_name" readonly>
														</div>
														<div class="form-group">
															<label class="form-label">Quantity</label>
															<input type="number" placeholder="Enter Quantity" class="form-control" name="service_quantity" min="1">
														</div>
														<div class="form-group">
															<label class="form-label">Discount %</label>
															<input type="number" class="form-control" name="service_discount_percentage" placeholder="Enter % value only">
														</div>
														<div class="form-group">
															<label class="form-label">Discount Absolute</label>
															<input type="number" class="form-control" name="service_discount_absolute" placeholder="Enter absolute value only">
														</div>
														<div class="form-group">
															<label class="form-label">Price Per Service/Product<small> (All inclusive of taxes)</small></label>
															<input type="number" class="form-control" name="service_price_inr" readonly>
														</div>
														<div class="form-group">
															<label class="form-label">Total Value</label>
															<input type="number" class="form-control" name="service_total_value" readonly>
														</div>
														<div class="form-group">
															<label>Expert Name</label>
															<select class="form-control" name="service_expert_id">
																<?php
																	foreach ($experts as $expert):
																?>
																		<option value="<?=$expert['employee_id']?>"><?=$expert['employee_first_name']." ".$expert['employee_last_name']?></option>>
																<?php		
																	endforeach;
																?>
															</select>
														</div>
														<div class="form-group">
				                      <input class="form-control" type="hidden" name="service_id" readonly="true">
				                    </div>
				                    <div class="form-group">
				                      <input class="form-control" type="hidden" name="customer_id" readonly="true">
				                    </div>
				                    <div class="form-group">
				                      <input class="form-control" type="hidden" name="service_gst_percentage" readonly="true">
				                    </div>
				                    <div class="form-group">
				                      <input class="form-control" type="hidden" name="service_est_time" readonly="true">
				                    </div>
														<button type="submit" class="btn btn-primary">Submit</button>
													</form>
													<div class="alert alert-dismissible feedback mt-0 mb-0" role="alert">
														<button type="button" class="close" data-dismiss="alert" aria-label="Close">
															<span aria-hidden="true">&times;</span>
								            </button>
															<div class="alert-message"></div>
													</div>
												</div>
												<div  class="modal-footer">
													<button  type="button" data-dismiss="modal" class="btn btn-success">Close
													</button>
												</div>
											</div>
										</div>
									</div>
									<!------Modal Area End--->
									
									<!----Accordion Start---->
									<div class="accordion" id="accordionExample">
										<div class="card">
											<div class="card-header" id="headingOne">
												<h5 class="card-title my-2">
													<a href="#" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
							              Categories
							            </a>
												</h5>
											</div>
											<div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
												<div class="card-body">
													<div class="row">
														<?php
															foreach ($categories as $category):
														?>
															
															<div class="col-md-4 col-sm-6">
																<a class="ShowSubCategories" category-id="<?=$category['category_id']?>">
																	<div class="card customized-category-card">
																		<div class="card-body" style="text-align: center;padding: 36px 0px;">
																			<p class="card-text"><?=$category['category_name']?></p>
																		</div>
																	</div>
																</a>		
															</div>

														<?php		
															endforeach;
														?>
														
													</div>
												</div>
											</div>
										</div>
										<div class="card">
											<div class="card-header" id="headingTwo">
												<h5 class="card-title my-2">
													<a href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseOne">
							              Sub-Categories
							            </a>
												</h5>
											</div>
											<div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
												<div class="card-body" id="Sub-Categories-Data">
													
												</div>
											</div>
										</div>
										<div class="card">
											<div class="card-header" id="headingThree">
												<h5 class="card-title my-2">
													<a href="#" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseOne">
							              Services & Products
							            </a>
												</h5>
											</div>
											<div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
												<div class="card-body" id="Services-Data">
													
												</div>
											</div>
										</div>
									</div>
									<!----Accordion End------>
								</div>
								<div id="TotalSection">
									<div class="card">
										<div class="card-body">
											<!--MODAL Section for Payments-->

											<div id="ModalFullPayment" tabindex="-1" role="dialog" aria-hidden="true" class="modal fade">
												<div role="document" class="modal-dialog modal-lg">
													<div class="modal-content">
														<div class="modal-header">
															<h5 class="modal-title">Full Payment</h5>
															<button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
														</div>
														<div class="modal-body m-3">
															<form action="#" method="POST" id="FullPaymentInfo">
																<div class="form-group">
																	<label class="form-label">Payment Type</label>
																	<select name="payment_type" class="form-control">
																		<option value="Cash">Cash</option>
																		<option value="Credit_Card">Credit Card</option>
																		<option value="Debit_Card">Debit Card</option>
																		<option value="Paytm">Paytm</option>
																		<option value="Phonepe">Phonepe</option>
																		<option value="Google_Pay">Google Pay</option>
																		<option value="Virtual_Wallet" disabled>Virtual Wallet</option>
																	</select>
																</div>
																<div class="form-group">
																	<label class="form-label">Total Amount</label>
																	<input type="number" class="form-control" name="total_final_bill" readonly>
																</div>
																<div class="form-group">
																	<label class="form-label">Amount Received</label>
																	<input type="number" class="form-control" name="total_amount_received">
																</div>
																<div class="form-group">
																	<label class="form-label">Balance to be paid back</label>
																	<input type="number" class="form-control" name="balance_to_be_paid_back" readonly>
																</div>
																<div class="form-group">
																	<label class="form-label">Pending Amount</label>
																	<input type="number" class="form-control" name="pending_amount" readonly>
																</div>
						                    <div class="form-group">
						                      <input class="form-control" type="hidden" name="customer_id" readonly="true">
						                    </div>
																<button type="submit" class="btn btn-primary">Submit</button>
															</form>
															<div class="alert alert-dismissible feedback mt-0 mb-0" role="alert">
																<button type="button" class="close" data-dismiss="alert" aria-label="Close">
																	<span aria-hidden="true">&times;</span>
										            </button>
																	<div class="alert-message"></div>
															</div>
														</div>
														<div  class="modal-footer">
															<button  type="button" data-dismiss="modal" class="btn btn-success">Close
															</button>
														</div>
													</div>
												</div>
											</div>

											<div id="ModalSplitPayment" tabindex="-1" role="dialog" aria-hidden="true" class="modal fade">
												<div role="document" class="modal-dialog modal-lg">
													<div class="modal-content">
														<div class="modal-header">
															<h5 class="modal-title">Split Payment</h5>
															<button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
														</div>
														<div class="modal-body m-3">
															<form action="#" method="POST" id="SplitPaymentInfo">
																<div class="form-row">	
																	<div class="form-group col-md-6">
																		<label class="form-label">Total Amount</label>
																		<input type="number" class="form-control" name="total_final_bill" readonly>
																	</div>
																	<div class="form-group col-md-6">
																		<label class="form-label">Amount Received</label>
																		<input type="number" class="form-control" name="total_amount_received" readonly>
																	</div>
																</div>
																<div class="form-row">
																	<div class="form-group col-md-6">
																		<label class="form-label">Balance to be paid back</label>
																		<input type="number" class="form-control" name="balance_to_be_paid_back" readonly>
																	</div>
																	<div class="form-group col-md-6">
																		<label class="form-label">Pending Amount</label>
																		<input type="number" class="form-control" name="total_pending_amount" readonly>
																	</div>
																</div>
																<div class="form-row">
																<table class="table table-hover table-bordered" id="Split-Payment-Info-Table">
																	<tbody>
													       		<tr>
													        		<td>1</td>
													        		<td>
													        			<div class="form-group">
													        				<label class="form-label">Payment Mode</label>
														        			<select name="payment_type[]" class="form-control">
																						<option value="Cash">Cash</option>
																						<option value="Credit_Card">Credit Card</option>
																						<option value="Debit_Card">Debit Card</option>
																						<option value="Paytm">Paytm</option>
																						<option value="Phonepe">Phonepe</option>
																						<option value="Google_Pay">Google Pay</option>
																						<option value="Virtual_Wallet" disabled>Virtual Wallet</option>
																					</select>
													        			</div>
													        		</td>
													        		<td>
													        			<div class="form-group">
																					<label class="form-label">Amount Received</label>
																					<input type="number" placeholder="Amount in INR" class="form-control" name="amount_received[]">
																				</div>
													        		</td>
													       		</tr>
													       	</tbody>
													      </table>
																</div>
						                    <div class="form-group">
						                      <input class="form-control" type="hidden" name="customer_id" readonly="true">
						                    </div>
						                    <button type="button" class="btn btn-success" id="AddRow">Add <i class="fa fa-plus" aria-hidden="true"></i></button>
    														<button type="button" class="btn btn-danger" id="DeleteRow">Delete <i class="fa fa-trash" aria-hidden="true"></i></button>
																<button type="submit" class="btn btn-primary">Submit</button>
															</form>
															<div class="alert alert-dismissible feedback mt-0 mb-0" role="alert">
																<button type="button" class="close" data-dismiss="alert" aria-label="Close">
																	<span aria-hidden="true">&times;</span>
										            </button>
																	<div class="alert-message"></div>
															</div>
														</div>
														<div  class="modal-footer">
															<button  type="button" data-dismiss="modal" class="btn btn-success">Close
															</button>
														</div>
													</div>
												</div>
											</div>

											<div id="ModalApplyExtraDiscount" tabindex="-1" role="dialog" aria-hidden="true" class="modal fade">
												<div role="document" class="modal-dialog modal-lg">
													<div class="modal-content">
														<div class="modal-header">
															<h5 class="modal-title">Extra Discount</h5>
															<button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
														</div>
														<div class="modal-body m-3">
															<form action="#" method="POST" id="ApplyExtraDiscount">
																<div class="form-group">
																	<label class="form-label">Discount %</label>
																	<input type="number" class="form-control" name="cart_discount_percentage" placeholder="Enter % value only">
																</div>
																<div class="form-group">
																	<label class="form-label">Discount Absolute</label>
																	<input type="number" class="form-control" name="cart_discount_absolute" placeholder="Enter absolute value only">
																</div>
						                    <div class="form-group">
						                      <input class="form-control" type="hidden" name="customer_id" readonly="true" value="<?=$individual_customer['customer_id']?>">
						                    </div>
																<button type="submit" class="btn btn-primary">Submit</button>
															</form>
															<div class="alert alert-dismissible feedback mt-0 mb-0" role="alert">
																<button type="button" class="close" data-dismiss="alert" aria-label="Close">
																	<span aria-hidden="true">&times;</span>
										            </button>
																	<div class="alert-message"></div>
															</div>
														</div>
														<div  class="modal-footer">
															<button  type="button" data-dismiss="modal" class="btn btn-success">Close
															</button>
														</div>
													</div>
												</div>
											</div>

											<!--MODAL Section Ends---------->
											<?php
												if(isset($cart) && !empty($cart)):
											?>
											<div class="mb-3">
												<table class="table table-hover">
													<tbody>
														<tr>
															<td>Total Bill</td>
															<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i>
															<?php
																$total_bill_before = 0;
																$discount_given = 0;
																$actual_bill = 0;
																$cart_json = json_encode($cart);
																foreach ($cart as $item) {
																	$total_bill_before += ((int)$item['service_price_inr'] * (int) $item['service_quantity']);

																	$discount_given += ((int)$item['service_price_inr'] * (int) $item['service_quantity']) - (int)$item['service_total_value']; 
																}

																$actual_bill = $total_bill_before - $discount_given;

																if(isset($payment['discount_info']['cart_discount_absolute'])){
																	if($payment['discount_info']['cart_discount_percentage'] == 0){
																		$discount_given += (int)$payment['discount_info']['cart_discount_absolute'];
																		
																	}
																}

																if(isset($payment['discount_info']['cart_discount_percentage'])){
																	if($payment['discount_info']['cart_discount_absolute'] == 0){
																		$discount_given += round((((int)$payment['discount_info']['cart_discount_percentage'])/100) * $actual_bill);
																	}
																}	

																$actual_bill = $total_bill_before - $discount_given;
																
																echo $total_bill_before;
															?>/-
															</td>
														</tr>
														<tr>
															<td>Package Applied</td>
															<td></td>
														</tr>
														<tr>
															<td>Discount</td>
															<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i>
																<?=$discount_given?>/-
															</td>
														</tr>
														<!-- <tr>
															<td>Wallet Balance Used</td>
															<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i></td>
														</tr>
														<tr>
															<td>Deal Discount</td>
															<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i></td>
														</tr>
														<tr>
															<td>Cashback Used</td>
															<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i></td>
														</tr> -->
														<tr>
															<td><strong>Final Payable Amount</strong></td>
															<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i>
																<?=$actual_bill?>/-
															</td>
														</tr>
														<tr><td></td><td></td></tr>
														<?php if(!empty($payment['full_payment_info']) || !empty($payment['split_payment_info'])){ 
															if(!empty($payment['full_payment_info'])) { ?>
														<tr>
															<td>Payment Type</td>
															<td><?=$payment['full_payment_info']['payment_type']?></td>
														</tr>
														<tr>
															<td>Amount Received</td>
															<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i><?=$payment['full_payment_info']['total_amount_received']?></td>
														</tr>
														<tr>
															<td>Balance to be paid back</td>
															<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i><?=$payment['full_payment_info']['balance_to_be_paid_back']?></td>
														</tr>
														<tr>
															<td>Pending Amount</td>
															<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i><?=$payment['full_payment_info']['pending_amount']?></td>
														</tr>
														<?php 
															}
															else{
														?>
														<tr>
															<td>Payment Type</td>
															<td>Split Payment</td>
														</tr>
														<tr>
															<td>Amount Received</td>
															<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i><?=$payment['split_payment_info']['total_amount_received']?></td>
														</tr>
														<tr>
															<td>Balance to be paid back</td>
															<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i><?=$payment['split_payment_info']['balance_to_be_paid_back']?></td>
														</tr>
														<tr>
															<td>Pending Amount</td>
															<td><i class="fas fa-fw fa-rupee-sign fa-2x" aria-hidden="true"></i><?=$payment['split_payment_info']['total_pending_amount']?></td>
														</tr>	
														<?php
															}
														 }
														?>
													</tbody>
												</table>
											</div>
											<div class="mb-3">
												<button class="btn btn-square btn-primary" data-toggle="modal" data-target="#ModalApplyExtraDiscount">Discount</button>
												<a href="<?=base_url()?>index.php/Cashier/JobOrder/<?=$individual_customer['customer_id']?>/" class="btn btn-square btn-secondary" target="_blank">Job Order</a>
												<a href="<?=base_url()?>index.php/Cashier/PrintBill/<?=$individual_customer['customer_id']?>/" class="btn btn-square btn-success" id="Print-Bill" target="_blank">Print Bill</a>
												<div class="btn-group">
													<?php if(!empty($payment['full_payment_info']) || !empty($payment['split_payment_info'])){ ?>
													<button type="button" class="btn btn-square btn-danger dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" disabled>Pay</button>
													<div class="dropdown-menu">
														<a class="dropdown-item full-payment-btn" href="#">Full Payment</a>
														<a class="dropdown-item split-payment-btn" href="#">Split Payment</a>
													</div>
													<?php
														}
														else{
													?>
													<button type="button" class="btn btn-square btn-danger dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Pay</button>
													<div class="dropdown-menu">
														<a class="dropdown-item full-payment-btn" href="#">Full Payment</a>
														<a class="dropdown-item split-payment-btn" href="#">Split Payment</a>
													</div>
												  <?php } ?>
												</div>
												<?php if(!empty($payment['full_payment_info']) || !empty($payment['split_payment_info'])){?>
												<button class="btn btn-square btn-primary" id="Settle-Final-Order">Settle Order</button>
												<?php 
													}
													else{
												?>
												<button class="btn btn-square btn-primary" disabled>Settle Order</button>
												<?php
													}
												?>
												<button class="btn btn-square btn-primary mt-2" disabled>My Services</button>
											</div>
											<?php
												endif;
											?>
										</div>
									</div>
								</div>
							</div>
							<div class="col-md-5">
								<?php
									if(!isset($cart) || empty($cart)){
								?>
								
									<div class="alert alert-secondary alert-outline alert-dismissible" role="alert">
										<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				            	<span aria-hidden="true">×</span>
				          	</button>
										<div class="alert-icon">
											<i class="far fa-fw fa-bell"></i>
										</div>
										<div class="alert-message">
											<strong>Hello there!</strong> Cart is empty!
										</div>
									</div>
								
								<?php
									}
									else{
								?>
								<table class="table table-hover table-responsive">
									<thead>
										<tr>
											<th>Service Name</th>
											<th>Price</th>
											<th>Qty</th>
											<th>Expert</th>
											<th>Actions</th>
										</tr>
									</thead>
									<tbody>
										<?php
											foreach ($cart as $item):
										?>
										<tr>
											<td><?=$item['service_name']?></td>
											<td><?=$item['service_total_value']?></td>
											<td><?=$item['service_quantity']?></td>
											<td>
												<?php
													$key = array_search($item['service_expert_id'], array_column($experts, 'employee_id'));
													echo $experts[$key]['employee_first_name'].' '.$experts[$key]['employee_last_name'];
												?>
											</td>
											<td class="table-action">
									      <button type="button" class="btn btn-danger btn-small cart-delete-btn" service-id="<?=$item['service_id']?>">
									        <i class="fa fa-trash" aria-hidden="true"></i>
									      </button>
											</td>	
										</tr>	
										<?php		
											endforeach;
										?>
									</tbody>
								</table>
								<?php
										/*if(isset($payment))
											echo "<pre>".print_r($payment,true)."</pre>";
											echo "\n";
											echo "<pre>".print_r($cart,true)."</pre>";*/
									}
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</main>	
<?php
	$this->load->view('cashier/cashier_footer_view');
?>
<script type="text/javascript">
	$(".date").daterangepicker({
		singleDatePicker: true,
		showDropdowns: true,
		autoUpdateInput : false,
		locale: {
      format: 'YYYY-MM-DD'
		}
	});

	$('.date').on('apply.daterangepicker', function(ev, picker) {
    $(this).val(picker.startDate.format('YYYY-MM-DD'));
  });
</script>

<script type="text/javascript">
	$(document).ready(function(){

		$("#smartwizard-arrows-primary").smartWizard({
			theme: "arrows",
			showStepURLhash: false
		});

		$(document).on('click','.ShowSubCategories',function(event){
			event.preventDefault();
			$(this).blur();
			var parameters = {category_id : $(this).attr('category-id')};
			$.getJSON("<?=base_url()?>index.php/Cashier/GetSubCategoriesByCatId/",parameters)
      .done(function(data, textStatus, jqXHR) {
    		var str = "<div class='row'>";
    		for(var i=0;i<data.length;i++){
    			
    			str += "<div class=\"col-md-4 col-sm-6\">\
										<a class=\"ShowServices\" sub-category-id=\""+data[i].sub_category_id+"\">\
											<div class=\"card customized-category-card\">\
												<div class=\"card-body\" style=\"text-align: center;padding: 36px 0px;\">\
													<p class=\"card-text\">"+data[i].sub_category_name+"</p>\
												</div>\
											</div>\
										</a>\
									</div>";
    		}
    		
    		str += "</div>";
    		$("#Sub-Categories-Data").html("").html(str);
     		$("#collapseTwo").collapse('show');
    	})
    	.fail(function(jqXHR, textStatus, errorThrown) {
        console.log(errorThrown.toString());
   		});	
		});

		$(document).on('click','.ShowServices',function(event){
			event.preventDefault();
			$(this).blur();
			var parameters = {sub_category_id : $(this).attr('sub-category-id')};
			$.getJSON("<?=base_url()?>index.php/Cashier/GetServicesBySubCatId/",parameters)
      .done(function(data, textStatus, jqXHR) {
    		var str = "<div class='row'>";
    		for(var i=0;i<data.length;i++){
    			
    			str += "<div class=\"col-md-4 col-sm-6\">\
										<a class=\"ProvideServiceDetails\" service-id=\""+data[i].service_id+"\" service-name=\""+data[i].service_name+"\" service-price-inr=\""+data[i].service_price_inr+"\" service-gst-percentage=\""+data[i].service_gst_percentage+"\" service-est-time=\""+data[i].service_est_time+"\">\
											<div class=\"card customized-category-card\">\
												<div class=\"card-body\" style=\"text-align: center;padding: 36px 0px;\">\
													<p class=\"card-text\">"+data[i].service_name+"</p>\
												</div>\
											</div>\
										</a>\
									</div>";
    		}
    		
    		str += "</div>";
    		$("#Services-Data").html("").html(str);
     		$("#collapseThree").collapse('show');
    	})
    	.fail(function(jqXHR, textStatus, errorThrown) {
        console.log(errorThrown.toString());
   		});	
		});


		var service_total_price = 0;
		var base_price = 0;
		var qty = 0;
		
		$(document).on('click','.ProvideServiceDetails',function(event){
			event.preventDefault();
			$(this).blur();

			service_total_price = Math.round(Number($(this).attr('service-price-inr')) + (Number($(this).attr('service-price-inr')) * Number($(this).attr('service-gst-percentage')/100)));

			$("#ServiceDetails input[name=service_name]").val($(this).attr('service-name'));
			$("#ServiceDetails input[name=service_price_inr]").val(service_total_price);
			$("#ServiceDetails input[name=service_total_value]").val(service_total_price);
			$("#ServiceDetails input[name=service_quantity]").val(1);
			$("#ServiceDetails input[name=service_discount_absolute]").val(0);
			$("#ServiceDetails input[name=service_discount_percentage]").val(0);
			$("#ServiceDetails input[name=service_id]").val($(this).attr('service-id'));
			$("#ServiceDetails input[name=customer_id]").val(<?=$individual_customer['customer_id']?>);
			$("#ServiceDetails input[name=service_gst_percentage]").val(Number($(this).attr('service-gst-percentage')));
			$("#ServiceDetails input[name=service_est_time]").val($(this).attr('service-est-time'));
			
			$("#ModalServiceDetails").modal('show');	
		});


		$("#ServiceDetails input[name=service_quantity]").on('input',function(){
			
			if($(this).val() <= 0){
				alert("Quantity should be a positive value");
			}
			else{
				base_price = $("#ServiceDetails input[name=service_price_inr]").val();
				qty = $(this).val();
				
				$("#ServiceDetails input[name=service_total_value]").val(base_price*qty);
				$("#ServiceDetails input[name=service_quantity]").val($(this).val());
				$("#ServiceDetails input[name=service_discount_absolute]").val(0);
			  $("#ServiceDetails input[name=service_discount_percentage]").val(0);
			}
		});

		$("#ServiceDetails input[name=service_discount_absolute]").on('input',function(){

			base_price = $("#ServiceDetails input[name=service_price_inr]").val();
			qty = $("#ServiceDetails input[name=service_quantity]").val();
			service_total_value = base_price * qty;
			
			if($(this).val() < service_total_value){
				service_total_value = Math.round((service_total_value) - $(this).val());
				$("#ServiceDetails input[name=service_total_value]").val(service_total_value);
				$("#ServiceDetails input[name=service_discount_percentage]").val(0);
			}
			else if($(this).val() > service_total_value){
				alert("Please enter less value than overall value!");
				$("#ServiceDetails input[name=service_discount_absolute]").val(0);
			}	
		});

		$("#ServiceDetails input[name=service_discount_percentage]").on('input',function(){

			base_price = $("#ServiceDetails input[name=service_price_inr]").val();
			qty = $("#ServiceDetails input[name=service_quantity]").val();
			service_total_value = base_price * qty;

			if($(this).val() < 100){
				service_total_value = Math.round(service_total_value - (service_total_value * ($(this).val()/100)));
				$("#ServiceDetails input[name=service_total_value]").val(service_total_value);
				$("#ServiceDetails input[name=service_discount_absolute]").val(0);
			}
			else if($(this).val() >= 100){
				alert("Please enter less value than 100% !");
				$("#ServiceDetails input[name=service_discount_percentage]").val(0);
			}			
		});

		$("#ApplyExtraDiscount input[name=cart_discount_percentage]").on('input',function(){

			if($(this).val() < 100){
				$("#ApplyExtraDiscount input[name=cart_discount_absolute]").val(0);
			}
			else if($(this).val() >= 100){
				alert("Please enter less value than 100% !");
				$("#ApplyExtraDiscount input[name=cart_discount_percentage]").val(0);
			}			
		});

		$("#ApplyExtraDiscount input[name=cart_discount_absolute]").on('input',function(){
			var actual_bill_for_discount = <?php if(isset($actual_bill)){ echo $actual_bill; } else{ echo 0;} ?>;
			if($(this).val() < actual_bill_for_discount){
				$("#ApplyExtraDiscount input[name=cart_discount_percentage]").val(0);
			}
			else if($(this).val() >= actual_bill_for_discount){
				alert("Cannot apply discount on complete bill!");
				$("#ApplyExtraDiscount input[name=cart_discount_absolute]").val(0);
			}			
		});

		$("#ServiceDetails").validate({
	  	errorElement: "div",
	    rules: {
	        "service_name" : {
            required : true,
            maxlength : 100
	        },
	        "service_total_value" : {
            required : true
	        },
	        "service_quantity" : {
	          required : true,
	          digits : true
	        },
	        "service_expert_id" : {
	        	required : true
	        },
	        "service_discount_percentage" : {
	        	digits : true
	        },
	        "service_discount_absolute" : {
	        	digits : true
	        },
	        "service_price_inr" : {
	        	required : true
	        }
	    },
	    submitHandler: function(form) {
				var formData = $("#ServiceDetails").serialize(); 
				$.ajax({
	        url: "<?=base_url()?>index.php/Cashier/AddToCart/",
	        data: formData,
	        type: "POST",
	        crossDomain: true,
					cache: false,
	        dataType : "json",
	    		success: function(data) {
            if(data.success == 'true'){
            	$("#ModalServiceDetails").modal('hide'); 
							$('#centeredModalSuccess').modal('show').on('shown.bs.modal', function (e){
								$("#SuccessModalMessage").html("").html(data.message);
							}).on('hidden.bs.modal', function (e) {
									window.location.reload();
							});
            }
            else if (data.success == 'false'){                   
        	    if($('.feedback').hasClass('alert-success')){
                $('.feedback').removeClass('alert-success').addClass('alert-danger');
              }
              else{
                $('.feedback').addClass('alert-danger');
              }
              $('.alert-message').html("").html(data.message); 
            }
          },
          error: function(data){
  					$('.feedback').addClass('alert-danger');
  					$('.alert-message').html("").html(data.message); 
          }
				});
			},
		});

		$("#ApplyExtraDiscount").validate({
	  	errorElement: "div",
	    rules: {
	        "cart_discount_percentage" : {
	        	digits : true,
	        	required : true
	        },
	        "cart_discount_absolute" : {
	        	digits : true,
	        	required : true
	        }
	    },
	    submitHandler: function(form) {
				var formData = $("#ApplyExtraDiscount").serialize(); 
				$.ajax({
	        url: "<?=base_url()?>index.php/Cashier/ApplyExtraDiscount/",
	        data: formData,
	        type: "POST",
	        crossDomain: true,
					cache: false,
	        dataType : "json",
	    		success: function(data) {
            if(data.success == 'true'){
            	$("#ModalApplyExtraDiscount").modal('hide'); 
							$('#centeredModalSuccess').modal('show').on('shown.bs.modal', function (e){
								$("#SuccessModalMessage").html("").html(data.message);
							}).on('hidden.bs.modal', function (e) {
									window.location.reload();
							});
            }
            else if (data.success == 'false'){                   
        	    if($('.feedback').hasClass('alert-success')){
                $('.feedback').removeClass('alert-success').addClass('alert-danger');
              }
              else{
                $('.feedback').addClass('alert-danger');
              }
              $('.alert-message').html("").html(data.message); 
            }
          },
          error: function(data){
  					$('.feedback').addClass('alert-danger');
  					$('.alert-message').html("").html(data.message); 
          }
				});
			},
		});

		$("#FullPaymentInfo").validate({
	  	errorElement: "div",
	    rules: {
	        "payment_type" : {
	        	required : true
	        },
	        "total_final_bill" : {
	        	digits : true,
	        	required : true
	        },
	        "total_amount_received" : {
	        	digits : true,
	        	required : true
	        },
	        "pending_amount" : {
	        	digits : true,
	        	required : true
	        },
	        "balance_to_be_paid_back" : {
	        	digits : true,
	        	required : true
	        }
	    },
	    submitHandler: function(form) {
				var formData = $("#FullPaymentInfo").serialize(); 
				$.ajax({
	        url: "<?=base_url()?>index.php/Cashier/FullPaymentInfo/",
	        data: formData,
	        type: "POST",
	        crossDomain: true,
					cache: false,
	        dataType : "json",
	    		success: function(data) {
            if(data.success == 'true'){
            	$("#ModalFullPayment").modal('hide'); 
							$('#centeredModalSuccess').modal('show').on('shown.bs.modal', function (e){
								$("#SuccessModalMessage").html("").html(data.message);
							}).on('hidden.bs.modal', function (e) {
									window.location.reload();
							});
            }
            else if (data.success == 'false'){                   
        	    if($('.feedback').hasClass('alert-success')){
                $('.feedback').removeClass('alert-success').addClass('alert-danger');
              }
              else{
                $('.feedback').addClass('alert-danger');
              }
              $('.alert-message').html("").html(data.message); 
            }
          },
          error: function(data){
  					$('.feedback').addClass('alert-danger');
  					$('.alert-message').html("").html(data.message); 
          }
				});
			},
		});

		$("#SplitPaymentInfo").validate({
	  	errorElement: "div",
	    rules: {
	        "payment_type" : {
	        	required : true
	        },
	        "total_final_bill" : {
	        	digits : true,
	        	required : true
	        },
	        "total_amount_received" : {
	        	digits : true,
	        	required : true
	        },
	        "total_pending_amount" : {
	        	digits : true,
	        	required : true
	        },
	        "balance_to_be_paid_back" : {
	        	digits : true,
	        	required : true
	        },
	        "amount_received" : {
	        	digits : true,
	        	required : true
	        }
	    },
	    submitHandler: function(form) {
				var formData = $("#SplitPaymentInfo").serialize(); 
				$.ajax({
	        url: "<?=base_url()?>index.php/Cashier/SplitPaymentInfo/",
	        data: formData,
	        type: "POST",
	        crossDomain: true,
					cache: false,
	        dataType : "json",
	    		success: function(data) {
            if(data.success == 'true'){
            	$("#ModalSplitPayment").modal('hide'); 
							$('#centeredModalSuccess').modal('show').on('shown.bs.modal', function (e){
								$("#SuccessModalMessage").html("").html(data.message);
							}).on('hidden.bs.modal', function (e) {
									window.location.reload();
							});
            }
            else if (data.success == 'false'){                   
        	    if($('.feedback').hasClass('alert-success')){
                $('.feedback').removeClass('alert-success').addClass('alert-danger');
              }
              else{
                $('.feedback').addClass('alert-danger');
              }
              $('.alert-message').html("").html(data.message); 
            }
          },
          error: function(data){
  					$('.feedback').addClass('alert-danger');
  					$('.alert-message').html("").html(data.message); 
          }
				});
			},
		});
		
    $('.cart-delete-btn').click(function(event) {
      event.preventDefault();
      this.blur(); // Manually remove focus from clicked link.
      var parameters = {
        service_id : $(this).attr('service-id'),
        customer_id : <?=$individual_customer['customer_id']?>
      };

      $.ajax({
        url: "<?=base_url()?>index.php/Cashier/DeleteCartItem/",
        data: parameters,
        type: "GET",
        crossDomain: true,
				cache: false,
        dataType : "json",
    		success: function(data) {
          if(data.success == 'true'){
						$('#centeredModalSuccess').modal('show').on('shown.bs.modal', function (e){
							$("#SuccessModalMessage").html("").html(data.message);
						}).on('hidden.bs.modal', function (e) {
								window.location.reload();
						});
          }
          else if (data.success == 'false'){                   
      	   	$('#centeredModalDanger').modal('show').on('shown.bs.modal', function (e){
							$("#ErrorModalMessage").html("").html(data.message);
						});
          }
        },
        error: function(data){
					$('#centeredModalDanger').modal('show').on('shown.bs.modal', function (e){
						$("#ErrorModalMessage").html("").html("Some error occured!");
					});
        }
			});
    });

    $(".full-payment-btn").click(function(event){
    	event.preventDefault();
      this.blur(); // Manually remove focus from clicked link.

			$("#FullPaymentInfo input[name=total_final_bill]").val(<?php if(isset($actual_bill)){ echo $actual_bill; } ?>);
			$("#FullPaymentInfo input[name=balance_to_be_paid_back]").val(0);
			$("#FullPaymentInfo input[name=pending_amount]").val(0);
			$("#FullPaymentInfo input[name=customer_id]").val(<?=$individual_customer['customer_id']?>);
			
			$("#ModalFullPayment").modal('show');	
    });

    $(".split-payment-btn").click(function(event){
    	event.preventDefault();
      this.blur(); // Manually remove focus from clicked link.

			$("#SplitPaymentInfo input[name=total_final_bill]").val(<?php if(isset($actual_bill)){ echo $actual_bill; } ?>);
			$("#SplitPaymentInfo input[name=balance_to_be_paid_back]").val(0);
			$("#SplitPaymentInfo input[name=total_pending_amount]").val(0);
			$("#SplitPaymentInfo input[name=total_amount_received]").val(0);
			$("#SplitPaymentInfo input[name=customer_id]").val(<?=$individual_customer['customer_id']?>);
			
			$("#ModalSplitPayment").modal('show');	
    });

    $("#FullPaymentInfo input[name=total_amount_received]").on('input',function(){
    	var billable_amt = $("#FullPaymentInfo input[name=total_final_bill]").val();
    	
    	
    	if($(this).val() < billable_amt){
    		$("#FullPaymentInfo input[name=pending_amount]").val(billable_amt - $(this).val());
    		$("#FullPaymentInfo input[name=balance_to_be_paid_back]").val(0);
    	}
    	else if(billable_amt < $(this).val()){
    		$("#FullPaymentInfo input[name=pending_amount]").val(0);
    		$("#FullPaymentInfo input[name=balance_to_be_paid_back]").val($(this).val() - billable_amt);
    	}
			else if(billable_amt == $(this).val()){
    		$("#FullPaymentInfo input[name=balance_to_be_paid_back]").val(0);
    		$("#FullPaymentInfo input[name=pending_amount]").val(0);
    	}
    });

    $("#AddRow").click(function(event){
    	event.preventDefault();
      this.blur();
      var rowno = $("#Split-Payment-Info-Table tr").length;

      rowno = rowno+1;
      
      $("#Split-Payment-Info-Table tr:last").after("<tr><td>"+rowno+"</td><td><div class=\"form-group\"><label class=\"form-label\">Payment Mode</label><select name=\"payment_type[]\" class=\"form-control\"><option value=\"Cash\">Cash</option><option value=\"Credit_Card\">Credit Card</option><option value=\"Debit_Card\">Debit Card</option><option value=\"Paytm\">Paytm</option><option value=\"Phonepe\">Phonepe</option><option value=\"Google_Pay\">Google Pay</option><option value=\"Virtual_Wallet\" disabled>Virtual Wallet</option></select></div></td><td><div class=\"form-group\"><label class=\"form-label\">Amount Received</label><input type=\"number\" placeholder=\"Amount in INR\" class=\"form-control\" name=\"amount_received[]\"></div></td></tr>");
    });

    $("#DeleteRow").click(function(event){
    	event.preventDefault();
      this.blur();
      var rowno = $("#Split-Payment-Info-Table tr").length;
      if(rowno > 1){
      	$('#Split-Payment-Info-Table tr:last').remove();
    	}
    });

    $(document).on('input',"#SplitPaymentInfo input[name^=amount_received]",function(event){
    	var billable_amt = $("#SplitPaymentInfo input[name=total_final_bill]").val();
    	
    	var amts_received_array = $('#SplitPaymentInfo input[name^=amount_received]').map(function(idx, elem) {
		    return $(elem).val();
		  }).get();

		  event.preventDefault();
		 
		  //console.log(amts_received_array);
		  var sum_amts_recieved = 0;
		  for(var i=0;i<amts_received_array.length;i++){
		  	sum_amts_recieved += Number(amts_received_array[i]);
		  }
		  //console.log(sum_amts_recieved);
    	$("#SplitPaymentInfo input[name=total_amount_received]").val(sum_amts_recieved);
    	if(sum_amts_recieved < billable_amt){
    		$("#SplitPaymentInfo input[name=total_pending_amount]").val(billable_amt - sum_amts_recieved);
    		$("#SplitPaymentInfo input[name=balance_to_be_paid_back]").val(0);
    	}
    	else if(billable_amt < sum_amts_recieved){
    		$("#SplitPaymentInfo input[name=total_pending_amount]").val(0);
    		$("#SplitPaymentInfo input[name=balance_to_be_paid_back]").val(sum_amts_recieved - billable_amt);
    	}
			else if(billable_amt == sum_amts_recieved){
    		$("#SplitPaymentInfo input[name=balance_to_be_paid_back]").val(0);
    		$("#SplitPaymentInfo input[name=total_pending_amount]").val(0);
    	}
    });

    $(document).on('click','#Settle-Final-Order',function(event){
    	event.preventDefault();
    	this.blur();

    	var txn_data = {
    		'txn_customer_id' :<?=$individual_customer['customer_id']?>,
    		'txn_discount' : <?php if(isset($discount_given)){ echo $discount_given; }else{ echo 0;}?> ,
    		'txn_value' :  <?php if(isset($actual_bill)){ echo $actual_bill; }else{ echo 0;} ?>
    	};

    	var cart_data = {};
    	var txn_settlement = {};
    	var customer_pending_data = {}; 

    	<?php if(isset($cart)): ?>
    		cart_data = <?php echo $cart_json; ?>;
    	<?php endif; ?>

    	<?php 
    	if(!empty($payment['full_payment_info']) || !empty($payment['split_payment_info'])){ if(!empty($payment['full_payment_info'])) { 
    	?>

    	txn_settlement = {
    		'txn_settlement_way' : 'Full Payment',
    		'txn_settlement_payment_mode' : '<?=$payment['full_payment_info']['payment_type']?>',
    		'txn_settlement_amount_received' : <?=$payment['full_payment_info']['total_amount_received']?>,
    		'txn_settlement_balance_paid' : <?=$payment['full_payment_info']['balance_to_be_paid_back']?>
    	};

    	customer_pending_data = {
    		'customer_id' : <?=$individual_customer['customer_id']?>,
    		'pending_amount' : <?=$payment['full_payment_info']['pending_amount']?>
    	}

    	<?php
    		}

    		if(!empty($payment['split_payment_info'])){
    	?>
    	txn_settlement = {
    		'txn_settlement_way' : 'Split Payment',
    		'txn_settlement_payment_mode' : 'Split',
    		'txn_settlement_amount_received' : <?=$payment['split_payment_info']['total_amount_received']?>,
    		'txn_settlement_balance_paid' : <?=$payment['split_payment_info']['balance_to_be_paid_back']?>
    	};

    	customer_pending_data = {
    		'customer_id' : <?=$individual_customer['customer_id']?>,
    		'pending_amount' : <?=$payment['split_payment_info']['total_pending_amount']?>
    	};
    	<?php
    		}
    	}
    	?>

    	var parameters = {
    		'txn_data' : txn_data,
    		'txn_settlement' : txn_settlement,
    		'customer_pending_data' : customer_pending_data,
    		'cart_data' : cart_data
    	};

    	$.ajax({
        url: "<?=base_url()?>index.php/Cashier/DoTransaction/",
        data: parameters,
        type: "POST",
        crossDomain: true,
				cache: false,
        dataType : "json",
    		success: function(data) {
          if(data.success == 'true'){
						$('#centeredModalSuccess').modal('show').on('shown.bs.modal', function (e){
							$("#SuccessModalMessage").html("").html(data.message);
						}).on('hidden.bs.modal', function (e) {
								window.location.href = "<?=base_url()?>index.php/Cashier/Dashboard/";
						});
          }
          else if (data.success == 'false'){                   
      	    $('#centeredModalDanger').modal('show').on('shown.bs.modal', function (e){
							$("#ErrorModalMessage").html("").html(data.message);
						})
          }
        },
        error: function(data){
					$('#centeredModalDanger').modal('show').on('shown.bs.modal', function (e){
						$("#ErrorModalMessage").html("").html("There is some problem!");
					})
        }
			});
    });

    $.getJSON("<?=base_url()?>index.php/Cashier/GetCustomer/", {customer_id : <?=$individual_customer['customer_id']?>})
	      .done(function(data, textStatus, jqXHR) { 
	      	$("#EditCustomerDetails select[name=customer_title]").val(data.customer_title);
	        $("#EditCustomerDetails input[name=customer_name]").attr('value',data.customer_name);
	        $("#EditCustomerDetails input[name=customer_mobile]").attr('value',data.customer_mobile);
	        $("#EditCustomerDetails input[name=customer_doa]").attr('value',data.customer_doa);
	        $("#EditCustomerDetails input[name=customer_dob]").attr('value',data.customer_dob);
	        $("#EditCustomerDetails input[name=customer_pending_amount]").attr('value',data.customer_pending_amount);
	        $("#EditCustomerDetails input[name=customer_virtual_wallet]").attr('value',data.customer_virtual_wallet);
	        $("#EditCustomerDetails select[name=customer_segment]").val(data.customer_segment);
					$("#EditCustomerDetails input[name=customer_id]").attr('value',data.customer_id);
	    	})
	    	.fail(function(jqXHR, textStatus, errorThrown) {
	        console.log(errorThrown.toString());
	   		});


	});
</script>	