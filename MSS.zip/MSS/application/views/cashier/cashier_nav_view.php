<nav class="sidebar">
	<div class="sidebar-content">
		<a class="sidebar-brand" href="<?=base_url()?>index.php/Cashier/">
 		 	<i class="align-middle" data-feather="box"></i>
	   	<span class="align-middle">MarksSalonSolution</span>
    </a>
		<ul class="sidebar-nav">
			<li class="sidebar-header">
				Dashboard
			</li>
			<?php
				if(array_search('POS System', $business_admin_packages) !== false):
			?>
			<li class="sidebar-item">
				<a href="#dashboards" data-toggle="collapse" class="sidebar-link">
          <i class="align-middle" data-feather="sliders"></i> <span class="align-middle">POS</span>
        </a>
				<ul id="dashboards" class="sidebar-dropdown list-unstyled collapse show">
					<li class="sidebar-item active"><a class="sidebar-link" href="<?=base_url()?>index.php/Cashier/Dashboard/">Billing</a></li>
		    		<li class="sidebar-item"><a class="sidebar-link" href="<?=base_url()?>index.php/Cashier/cashier_expense_view/">Expenses</a></li>
					<li class="sidebar-item"><a class="sidebar-link" href="dashboard-default.html">Inventory</a></li>
					
				</ul>
			</li>
			<?php
				endif;

				if(array_search('Appointments', $business_admin_packages) !== false):
			?>
			<li class="sidebar-item">
				<a href="#pages" data-toggle="collapse" class="sidebar-link collapsed">
          <i class="align-middle" data-feather="layout"></i> <span class="align-middle">Appointments</span>
        </a>
				<ul id="pages" class="sidebar-dropdown list-unstyled collapse ">
					<li class="sidebar-item"><a class="sidebar-link" href="pages-profile.html">Calendar View</a></li>
					<li class="sidebar-item"><a class="sidebar-link" href="pages-settings.html">Add Appointment</a></li>
				</ul>
			</li>
			<?php
				endif;
			?>
			<li class="sidebar-header">
				Other Options
			</li>
			<li class="sidebar-item">
				<a href="#ui" data-toggle="collapse" class="sidebar-link collapsed">
		          <i class="align-middle" data-feather="grid"></i> <span class="align-middle">Settings</span>
		        </a>
				<ul id="ui" class="sidebar-dropdown list-unstyled collapse ">
					<li class="sidebar-item"><a class="sidebar-link" href="<?=base_url()?>index.php/Cashier/Logout/">Logout</a></li>
					<li class="sidebar-item"><a class="sidebar-link" href="<?=base_url()?>index.php/Cashier/Profile/">Profile</a></li>
					<li class="sidebar-item"><a class="sidebar-link" href="<?=base_url()?>index.php/Cashier/ResetPassword/">Reset Password</a></li>
				</ul>
			</li>
		</ul>
		<div class="sidebar-bottom d-none d-lg-block">
			<div class="media">
				<img class="rounded-circle mr-3" src="<?=base_url()?>public/images/default.png" alt="Cashier Admin" width="40" height="40">
				<div class="media-body">
					<h5 class="mb-1"><?=$cashier_details['employee_first_name']?></h5>
					<div>
						<i class="fas fa-circle text-success"></i> Online
					</div>
				</div>
			</div>
		</div>
	</div>
</nav>