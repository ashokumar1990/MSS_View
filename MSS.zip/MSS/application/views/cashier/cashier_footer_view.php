		<footer class="footer">
			<div class="container-fluid">
				<div class="row text-muted">
					<div class="col-md-3 offset-md-4">
						<button class="btn btn-primary btn-lg">Customer</button>
					</div>
					<div class="col-md-3">
						<button class="btn btn-outline-primary btn-lg">Employee</button>
					</div>
				</div>
			</div>
		</footer>
	</div>
</div>
		<script src="<?=base_url()?>public/app_stack/js/app.js"></script>
		<script src="<?=base_url()?>public/app_stack/js/validation.js"></script>
		<script src="<?=base_url()?>public/app_stack/js/underscore-min.js"></script>
    <script src="<?=base_url()?>public/app_stack/js/typeahead.jquery.min.js"></script>
	</body>
</html>