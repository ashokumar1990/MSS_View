<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class BusinessAdmin extends CI_Controller {
		
	private function IsLoggedIn($type){
		if (!isset($this->session->userdata['logged_in'])) {
			return false;
    }
    else{
		if($this->session->userdata['logged_in']['user_type'] == $type){
			return true;
		}
		else{
		return false;
		}
    }
}

	private function GetDataForAdmin($title){
		$data = array();
		$data['title'] = $title;
		$data['business_admin_packages'] = $this->GetBusinessAdminPackages();
		$data['business_admin_details']  = $this->GetBusinessAdminDetails();
		$data['business_outlet_details'] = $this->GetBusinessOutlets();
		if(isset($this->session->userdata['outlets'])){
			$data['selected_outlet']        = $this->GetCurrentOutlet($this->session->userdata['outlets']['current_outlet']);
		}
		
		return $data;
	}

	
	//Default Page for Business Admin
	public function index(){
		if($this->IsLoggedIn('business_admin')){
			$data = $this->GetDataForAdmin("Dashboard");
			$this->load->view('business_admin/ba_dashboard_view',$data);
		}
		else{
			$data['title'] = "Login";
			$this->load->view('business_admin/ba_login_view',$data);
		}
	}
	
	//constructor of the Alumni Controller
	public function __construct(){
	   parent::__construct();
	   date_default_timezone_set('Asia/Kolkata');
	   $this->load->model('AnalyticsModel');
	   $this->load->model('BusinessAdminModel');
	   $this->load->model('AppointmentsModel');
	   $this->load->model('CashierModel');
	   $this->load->model('POSModel');
  }

  public function ReturnJsonArray($success,$error,$message){
  	if($success == true && $error == false){
  		$data = array(
						'success' => 'true',
						'error'   => 'false',
						'message' =>  $message
					 );
			header("Content-type: application/json");
			print(json_encode($data, JSON_PRETTY_PRINT));
		}
		elseif ($success == false && $error == true) {
			$data = array(
						'success' => 'false',
						'error'   => 'true',
						'message' =>  $message
					 );
			header("Content-type: application/json");
			print(json_encode($data, JSON_PRETTY_PRINT));
		}
  }

  //Testing Function
  private function PrettyPrintArray($data){
  	print("<pre>".print_r($data,true)."</pre>");
  	die;
  }

	//function for logging out the user
	public function Logout(){
		if(isset($this->session->userdata['logged_in']) && !empty($this->session->userdata['logged_in'])){
 			$this->session->unset_userdata('logged_in');
 			$this->session->unset_userdata('outlets');
 			$this->session->sess_destroy();
 		}
		redirect(base_url(),'refresh');
	}

	//function for logging out the user
	private function LogoutUrl($url){
		if(isset($this->session->userdata['logged_in']) && !empty($this->session->userdata['logged_in'])){
 			$this->session->unset_userdata('logged_in');
 			$this->session->unset_userdata('outlets');
 			$this->session->sess_destroy();
 		}
	    
	    redirect($url,'refresh');
	}

	//function for login
	public function Login(){
		if(isset($_POST) && !empty($_POST)){
			$this->form_validation->set_rules('business_admin_email', 'Email', 'trim|required|max_length[100]');
			$this->form_validation->set_rules('business_admin_password', 'Password', 'trim|required');
			
			if ($this->form_validation->run() == FALSE) 
			{
				$data = array(
								'success' => 'false',
								'error'   => 'true',
								'message' =>  validation_errors()
							);
				header("Content-type: application/json");
				print(json_encode($data, JSON_PRETTY_PRINT));
				die;
			}  
			else 
			{
				$data = array(
					'business_admin_email' 	  => $this->input->post('business_admin_email'),
					'business_admin_password' => $this->input->post('business_admin_password')
				);
				
				$result = $this->BusinessAdminModel->BusinessAdminLogin($data);
				
				if ($result['success'] == 'true') 
				{
					$result = $this->BusinessAdminModel->BusinessAdminByEmail($data['business_admin_email']);
					
					if($result['success'] == 'true'){
						if($data['business_admin_email'] == $result['res_arr']['business_admin_email'] && password_verify($data['business_admin_password'],$result['res_arr']['business_admin_password']) && $result['res_arr']['business_admin_account_expiry_date'] >= date('Y-m-d'))
						{ 
							$session_data = array(
								'business_admin_id'      => $result['res_arr']['business_admin_id'],
								'business_admin_name'    => $result['res_arr']['business_admin_first_name'].' '.$result['res_arr']['business_admin_last_name'],
								'business_admin_email'   => $result['res_arr']['business_admin_email'],
								'user_type'        => 'business_admin'
							);
							
							$this->session->set_userdata('logged_in', $session_data);
							$this->ReturnJsonArray(true,false,'Valid login!');
							die;
						}
						else
						{
							if($result['res_arr']['business_admin_account_expiry_date'] < date('Y-m-d')){
								$this->ReturnJsonArray(false,true,'Your account is expired. Please renew your subscription!');
								die;
							}
							else{
								$this->ReturnJsonArray(false,true,'Wrong email or password !');
								die;
							}
						}
					}
					elseif($result['error'] == 'true'){
						$this->ReturnJsonArray(false,true,$result['message']);
						die;
					}
				}
				elseif($result['error'] == 'true'){
					$this->ReturnJsonArray(false,true,$result['message']);
					die;
				}
			}
		}
		else{
			$data['title'] = "Login";
			$this->load->view('business_admin/ba_login_view',$data);
		}
	}

	public function ResetBusinessAdminPassword(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('new_password', 'New Password', 'trim|required');
				$this->form_validation->set_rules('confirm_new_password', 'Confirm Password', 'trim|required');

				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{
					  
					$new_password 		  =  $this->input->post('new_password');
					$confirm_new_password =  $this->input->post('confirm_new_password');
					
					if($new_password === $confirm_new_password){
						
						$data = array(
							"business_admin_password" => password_hash($new_password,PASSWORD_DEFAULT),
							"business_admin_id"       => $this->session->userdata['logged_in']['business_admin_id']
						);
						
						$result = $this->BusinessAdminModel->Update($data,'mss_business_admin','business_admin_id');
						
						if($result['success'] == 'true'){
							$this->ReturnJsonArray(true,false,"Password changed successfully!");
							die;
            }
            elseif($result['error'] == 'true'){
            	$this->ReturnJsonArray(false,true,$result['message']);
							die;
            }
					}
					else{
						$this->ReturnJsonArray(false,true,"Passwords Do Not Match!");
						die;
					}
				}	
		  }
		 	else{
		   	$this->ReturnJsonArray(false,true,"Not a POST Request !");
				die;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}					
	}

	//Dashboard for the Business Admin
	public function Dashboard(){
		if($this->IsLoggedIn('business_admin')){
			$data = $this->GetDataForAdmin("Dashboard");
			$this->load->view('business_admin/ba_dashboard_view',$data);
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}


	private function GetBusinessAdminPackages(){
		if($this->IsLoggedIn('business_admin')){
			$data = $this->BusinessAdminModel->BusinessAdminPackages($this->session->userdata['logged_in']['business_admin_id']);
			
			if($data['success'] == 'true'){
				$temp = array();
				
				foreach ($data['res_arr'] as $d) {
					if($d['package_expiry_date'] >= date('Y-m-d')){
						array_push($temp,$d['package_name']);
					}
				}
				
				return $temp;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}	
	}
	
	private function GetBusinessAdminDetails(){
		if($this->IsLoggedIn('business_admin')){
			$data = $this->BusinessAdminModel->DetailsById($this->session->userdata['logged_in']['business_admin_id'],'mss_business_admin','business_admin_id');
			if($data['success'] == 'true'){	
				return $data['res_arr'];
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}	
	}

	private function GetCurrentOutlet($outlet_id){
		if($this->IsLoggedIn('business_admin')){
			$data = $this->BusinessAdminModel->DetailsById($outlet_id,'mss_business_outlets','business_outlet_id');
			if($data['success'] == 'true'){	
				return $data['res_arr'];
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}	
	}

	private function GetBusinessOutlets(){
		if($this->IsLoggedIn('business_admin')){
			$where = array(
				'business_outlet_business_admin' => $this->session->userdata['logged_in']['business_admin_id']
			);
			$data = $this->BusinessAdminModel->MultiWhereSelect('mss_business_outlets',$where);
			if($data['success'] == 'true'){	
				return $data['res_arr'];
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}	
	}
	
		
		//Basic Template
		// public function packages(){
		// 	if($this->IsLoggedIn('business_admin')){
		// 		$data = $this->GetDataForAdmin("Dashboard");
		// 		$this->load->view('business_admin/ba_packages_view',$data);
		// 	}
		// 	else{
		// 		$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		// 	}
		// }
		//
		// public function packages(){
		// 	if($this->IsLoggedIn('business_admin')){
		// 		$data = $this->GetDataForAdmin("packages");
		// 		if(isset($data['selected_outlet']) || !empty($data['selected_outlet'])){
		// 			$data['categories']  = $this->GetCategories($this->session->userdata['outlets']['current_outlet']);
		// 			$data['sub_categories']  = $this->GetSubCategories($this->session->userdata['outlets']['current_outlet']);
		// 			$data['packages']  = $this->GetPackages($this->session->userdata['outlets']['current_outlet']);
					
		// 		}
		// 		$this->load->view('business_admin/ba_packages_view',$data);
		// 	}
		// 	else{
		// 		$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		// 	}
		// }

		//  
	
	public function MenuManagement(){
		if($this->IsLoggedIn('business_admin')){
			$data = $this->GetDataForAdmin("Menu Management");
			if(isset($data['selected_outlet']) || !empty($data['selected_outlet'])){
				$data['categories']  = $this->GetCategories($this->session->userdata['outlets']['current_outlet']);
				$data['sub_categories']  = $this->GetSubCategories($this->session->userdata['outlets']['current_outlet']);
				$data['services']  = $this->GetServices($this->session->userdata['outlets']['current_outlet']);
				$data['all_otc'] = $this->GetOTCCategories($this->session->userdata['outlets']['current_outlet']);
				$data['raw_materials'] = $this->GetRawMaterials($this->session->userdata['outlets']['current_outlet']);
			}
			$this->load->view('business_admin/ba_menu_management_view',$data);
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function ConfigExpense(){
		if($this->IsLoggedIn('business_admin')){
			$data = $this->GetDataForAdmin("Expense");
			$data['expense_types'] = $this->GetExpensesTypes($this->session->userdata['outlets']['current_outlet']);
			$this->load->view('business_admin/ba_config_expense_category_view',$data);
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function Inventory(){
		if($this->IsLoggedIn('business_admin')){
			$data = $this->GetDataForAdmin("Add Composition");
			if(isset($data['selected_outlet']) || !empty($data['selected_outlet'])){
				$data['categories']  = $this->GetCategories($this->session->userdata['outlets']['current_outlet']);
				$data['sub_categories']  = $this->GetSubCategories($this->session->userdata['outlets']['current_outlet']);
				$data['services']  = $this->GetServices($this->session->userdata['outlets']['current_outlet']);
				$data['raw_materials'] = $this->GetRawMaterials($this->session->userdata['outlets']['current_outlet']);
				$data['compositions'] = $this->GetCompositions($this->session->userdata['outlets']['current_outlet']);
			}
			$this->load->view('business_admin/ba_inventory_management_view',$data);
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function AddCategory(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('category_name', 'Category Name', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('category_description', 'Category Description', 'trim');
				
				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{
					$data = array(
						'category_name' 				=> $this->input->post('category_name'),
						'category_description' 	=> $this->input->post('category_description'),
						'category_business_admin_id' => $this->session->userdata['logged_in']['business_admin_id'],
						'category_business_outlet_id' => $this->session->userdata['outlets']['current_outlet']
					);

					$result = $this->BusinessAdminModel->Insert($data,'mss_categories');
						
					if($result['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"Category added successfully!");
						die;
          }
          elseif($result['error'] == 'true'){
          	$this->ReturnJsonArray(false,true,$result['message']);
						die;
          }
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function AddSubCategory(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('sub_category_name', 'Sub-Category Name', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('sub_category_description', 'Sub-Category Description', 'trim');
				$this->form_validation->set_rules('sub_category_category_id', 'Category Name', 'trim|required');
				
				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{
					$data = array(
						'sub_category_name' 				=> $this->input->post('sub_category_name'),
						'sub_category_description' 	=> $this->input->post('sub_category_description'),
						'sub_category_category_id' => $this->input->post('sub_category_category_id')
					);

					$result = $this->BusinessAdminModel->Insert($data,'mss_sub_categories');
						
					if($result['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"Sub-Category added successfully!");
						die;
          }
          elseif($result['error'] == 'true'){
          	$this->ReturnJsonArray(false,true,$result['message']);
						die;
          }
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function EditCategory(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('category_name', 'Category Name', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('category_description', 'Category Description', 'trim');
				
				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{
					$data = array(
						'category_id'           => $this->input->post('category_id'),
						'category_name' 				=> $this->input->post('category_name'),
						'category_description' 	=> $this->input->post('category_description')
					);

					$result = $this->BusinessAdminModel->Update($data,'mss_categories','category_id');
						
					if($result['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"Category updated successfully!");
						die;
          }
          elseif($result['error'] == 'true'){
          	$this->ReturnJsonArray(false,true,$result['message']);
						die;
          }
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function EditSubCategory(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('sub_category_name', 'Sub-Category Name', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('sub_category_description', 'Sub-Category Description', 'trim');
				$this->form_validation->set_rules('sub_category_category_id', 'Category Name', 'trim');
				
				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{
					$data = array(
						'sub_category_id'           => $this->input->post('sub_category_id'),
						'sub_category_name' 				=> $this->input->post('sub_category_name'),
						'sub_category_description' 	=> $this->input->post('sub_category_description'),
						'sub_category_category_id'  => $this->input->post('sub_category_category_id')
					);

					$result = $this->BusinessAdminModel->Update($data,'mss_sub_categories','sub_category_id');
						
					if($result['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"Sub-Category updated successfully!");
						die;
          }
          elseif($result['error'] == 'true'){
          	$this->ReturnJsonArray(false,true,$result['message']);
						die;
          }
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function AddEmployee(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('employee_first_name', 'Employee FirstName', 'trim|required|max_length[50]');
				$this->form_validation->set_rules('employee_last_name', 'Employee Last Name', 'trim|required|max_length[50]');
				$this->form_validation->set_rules('employee_address', 'Employee Address', 'trim|required');
				$this->form_validation->set_rules('employee_mobile', 'Employee Mobile', 'trim|max_length[15]|required');
				$this->form_validation->set_rules('employee_email', 'Employee Email', 'trim|max_length[100]|required');
				$this->form_validation->set_rules('employee_business_outlet', 'Employee Outlet Name', 'trim|required');
				$this->form_validation->set_rules('employee_password', 'Employee Password', 'trim');
				$this->form_validation->set_rules('employee_expertise', 'Employee Expertise', 'trim');
				$this->form_validation->set_rules('employee_role', 'Employee Role', 'trim|required|max_length[50]');
				$this->form_validation->set_rules('employee_date_of_joining', 'Employee Date of Joining', 'trim|required');
				

				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{
					$data = array(
						'employee_first_name' 	=> $this->input->post('employee_first_name'),
						'employee_last_name' 	=> $this->input->post('employee_last_name'),
						'employee_mobile' 	=> $this->input->post('employee_mobile'),
						'employee_address' 	=> $this->input->post('employee_address'),
						'employee_email' 	=> $this->input->post('employee_email'),
						'employee_business_outlet' 	=> $this->input->post('employee_business_outlet'),
						'employee_password' 	=> password_hash($this->input->post('employee_password'), PASSWORD_DEFAULT),
						'employee_expertise' 	=> $this->input->post('employee_expertise'),
						'employee_role' 	=> $this->input->post('employee_role'),
						'employee_date_of_joining' 	=> $this->input->post('employee_date_of_joining'),
						'employee_business_admin' => $this->session->userdata['logged_in']['business_admin_id']
					);

					$result = $this->BusinessAdminModel->Insert($data,'mss_employees');
						
					if($result['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"Employee added successfully!");
						die;
          }
          elseif($result['error'] == 'true'){
          	$this->ReturnJsonArray(false,true,$result['message']);
						die;
          }
				}
			}
			else{
				$data = $this->GetDataForAdmin("Employee Management");
				$data['business_admin_employees']  = $this->GetBusinessAdminEmployees();
				$this->load->view('business_admin/ba_employee_management_view',$data);
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}	
	}

	public function AddService(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('service_name', 'Service Name', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('service_price_inr', 'Service Gross Price', 'trim|required|is_natural_no_zero');
				$this->form_validation->set_rules('service_est_time', 'Service Estimated Time', 'trim|required|max_length[50]');
				$this->form_validation->set_rules('service_description', 'Service Description', 'trim');
				$this->form_validation->set_rules('service_gst_percentage', 'Service GST Percentage', 'trim|is_natural_no_zero|required');
				$this->form_validation->set_rules('service_sub_category_id', 'Service Sub-Category Name', 'trim|required');

				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{
					$data = array(
						'service_name' 	=> $this->input->post('service_name'),
						'service_price_inr' 	=> $this->input->post('service_price_inr'),
						'service_est_time' 	=> $this->input->post('service_est_time'),
						'service_description' 	=> $this->input->post('service_description'),
						'service_gst_percentage' 	=> $this->input->post('service_gst_percentage'),
						'service_sub_category_id' 	=> $this->input->post('service_sub_category_id')
					);

					$result = $this->BusinessAdminModel->Insert($data,'mss_services');
						
					if($result['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"Service added successfully!");
						die;
          }
          elseif($result['error'] == 'true'){
          	$this->ReturnJsonArray(false,true,$result['message']);
						die;
          }
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}	
	}

	public function AddOTCCategory(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('otc_item_name', 'otc Item Name', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('otc_brand', 'Otc brand', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('otc_unit', 'Otc unit', 'trim|required|max_length[50]');
				$this->form_validation->set_rules('otc_sub_category_id', 'Otc Sub-Category Name', 'trim|required');
				$this->form_validation->set_rules('otc_gst_percentage', 'OTC GST Percentage', 'trim|is_natural_no_zero|required');
				$this->form_validation->set_rules('otc_price_inr', 'OTC Gross Price', 'trim|required|is_natural_no_zero');

				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{
					$data = array(
						'otc_item_name' 	=> $this->input->post('otc_item_name'),
						'otc_brand' 	=> $this->input->post('otc_brand'),
						'otc_unit' 	=> $this->input->post('otc_unit'),
						'otc_sub_category_id' 	=> $this->input->post('otc_sub_category_id'),
						'otc_price_inr' => $this->input->post('otc_price_inr'),
						'otc_gst_percentage' => $this->input->post('otc_gst_percentage') 
					);

					$result = $this->BusinessAdminModel->Insert($data,'mss_otc_categories');
						
					if($result['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"OTC added successfully!");
						die;
          }
          elseif($result['error'] == 'true'){
          	$this->ReturnJsonArray(false,true,$result['message']);
						die;
          }
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}	
	}

  public function AddRawMaterial(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('raw_material_name', 'Raw Material Item Name', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('raw_material_brand', 'Raw Material brand', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('raw_material_unit', 'Raw Material unit', 'trim|required|max_length[50]');


				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{
					$data = array(
						'raw_material_name' 	=> $this->input->post('raw_material_name'),
						'raw_material_brand' 	=> $this->input->post('raw_material_brand'),
						'raw_material_unit' 	=> $this->input->post('raw_material_unit'),
						'raw_material_business_admin_id' 	=> $this->session->userdata['logged_in']['business_admin_id'],
						'raw_material_business_outlet_id' => $this->session->userdata['outlets']['current_outlet']
					);

					$result = $this->BusinessAdminModel->Insert($data,'mss_raw_material_categories');
						
					if($result['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"Raw Material added successfully!");
						die;
          }
          elseif($result['error'] == 'true'){
          	$this->ReturnJsonArray(false,true,$result['message']);
						die;
          }
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}	
	}

	public function AddExpenseCategory(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('expense_type', 'Category Name', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('expense_type_description', 'Category Description', 'trim');
				
				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{
					$data = array(
						'expense_type' 				=> $this->input->post('expense_type'),
						'expense_type_description' 	=> $this->input->post('expense_type_description'),
						'expense_type_business_admin_id' => $this->session->userdata['logged_in']['business_admin_id'],
						'expense_type_business_outlet_id' => $this->session->userdata['outlets']['current_outlet']
					);

					$result = $this->BusinessAdminModel->Insert($data,'mss_expense_types');
						
					if($result['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"Expense Category added successfully!");
						die;
          }
          elseif($result['error'] == 'true'){
          	$this->ReturnJsonArray(false,true,$result['message']);
						die;
          }
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}	
	}

	public function AddComposition(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('service_id', 'Service Name', 'trim|required');	
				if ($this->form_validation->run() == FALSE){
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{
					if(!empty($_POST['raw_material_id']) && !empty($_POST['consumption_quantity'])){
						$rmc_id   = $this->input->post('raw_material_id');
						$consumption_quantity = $this->input->post('consumption_quantity');
						$counter = 0; //To keep track of no of succcessful submissions
					
						for($i=0;$i<count($rmc_id);$i++){	  	
					  	$data = array(
					  		'service_id' => $this->input->post('service_id'),
				  			'rmc_id'     => $rmc_id[$i],
				  			'consumption_quantity' => $consumption_quantity[$i]
				  		);		
					   	$result = $this->BusinessAdminModel->Insert($data,'mss_raw_composition');
					   	if($result['success'] == 'true'){
					   		$counter = $counter + 1;
					   	}	 
						}

						if($counter == count($rmc_id)){
							$this->ReturnJsonArray(true,false,"Composition added successfully!");
							die;
						}
						else{
							$this->ReturnJsonArray(false,true,"Please Check!");
							die;
						}	
					}
				} 
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function EditExpenseCategory(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('expense_type', 'Category Name', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('expense_type_description', 'Category Description', 'trim');
				
				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{
					$data = array(
						'expense_type' 				=> $this->input->post('expense_type'),
						'expense_type_description' 	=> $this->input->post('expense_type_description'),
						'expense_type_id'     => $this->input->post('expense_type_id')
					);

					$result = $this->BusinessAdminModel->Update($data,'mss_expense_types','expense_type_id');
						
					if($result['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"Expense Category updated successfully!");
						die;
          }
          elseif($result['error'] == 'true'){
          	$this->ReturnJsonArray(false,true,$result['message']);
						die;
          }
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function EditRawMaterial(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('raw_material_name', 'Raw Material Item Name', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('raw_material_brand', 'Raw Material brand', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('raw_material_unit', 'Raw Material unit', 'trim|required|max_length[50]');


				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{
					$data = array(
						'raw_material_name' 	=> $this->input->post('raw_material_name'),
						'raw_material_brand' 	=> $this->input->post('raw_material_brand'),
						'raw_material_unit' 	=> $this->input->post('raw_material_unit'),
						'raw_material_category_id' 	=> $this->input->post('raw_material_category_id')
					);

					$result = $this->BusinessAdminModel->Update($data,'mss_raw_material_categories','raw_material_category_id');
						
					if($result['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"Raw Material updated successfully!");
						die;
          }
          elseif($result['error'] == 'true'){
          	$this->ReturnJsonArray(false,true,$result['message']);
						die;
          }
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}	
	}

	public function EditOTCCategory(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('otc_item_name', 'otc Item Name', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('otc_brand', 'Otc brand', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('otc_unit', 'Otc unit', 'trim|required|max_length[50]');
				$this->form_validation->set_rules('otc_gst_percentage', 'OTC GST Percentage', 'trim|is_natural_no_zero|required');
				$this->form_validation->set_rules('otc_price_inr', 'OTC Gross Price', 'trim|required|is_natural_no_zero');

				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{
					$data = array(
						'otc_item_name' 	=> $this->input->post('otc_item_name'),
						'otc_brand' 	=> $this->input->post('otc_brand'),
						'otc_unit' 	=> $this->input->post('otc_unit'),
						'otc_category_id' 	=> $this->input->post('otc_category_id'),
						'otc_price_inr' => $this->input->post('otc_price_inr'),
						'otc_gst_percentage' => $this->input->post('otc_gst_percentage')
					);

					$result = $this->BusinessAdminModel->Update($data,'mss_otc_categories','otc_category_id');
						
					if($result['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"OTC updated successfully!");
						die;
          }
          elseif($result['error'] == 'true'){
          	$this->ReturnJsonArray(false,true,$result['message']);
						die;
          }
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}	
	}

	public function EditService(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('service_name', 'Service Name', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('service_price_inr', 'Service Gross Price', 'trim|required|is_natural_no_zero');
				$this->form_validation->set_rules('service_est_time', 'Service Estimated Time', 'trim|required|max_length[50]');
				$this->form_validation->set_rules('service_description', 'Service Description', 'trim');
				$this->form_validation->set_rules('service_gst_percentage', 'Service GST Percentage', 'trim|is_natural_no_zero|required');
				/*$this->form_validation->set_rules('service_sub_category_id', 'Service Sub-Category Name', 'trim|required');*/
				

				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{
					$data = array(
						'service_id'    => $this->input->post('service_id'),
						'service_name' 	=> $this->input->post('service_name'),
						'service_price_inr' 	=> $this->input->post('service_price_inr'),
						'service_est_time' 	=> $this->input->post('service_est_time'),
						'service_description' 	=> $this->input->post('service_description'),
						'service_gst_percentage' 	=> $this->input->post('service_gst_percentage')
						/*'service_sub_category_id' 	=> $this->input->post('service_sub_category_id')*/
					);

					$result = $this->BusinessAdminModel->Update($data,'mss_services','service_id');
						
					if($result['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"Service updated successfully!");
						die;
          }
          elseif($result['error'] == 'true'){
          	$this->ReturnJsonArray(false,true,$result['message']);
						die;
          }
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}	
	}

	public function EditEmployee(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('employee_first_name', 'Employee FirstName', 'trim|required|max_length[50]');
				$this->form_validation->set_rules('employee_last_name', 'Employee Last Name', 'trim|required|max_length[50]');
				$this->form_validation->set_rules('employee_address', 'Employee Address', 'trim|required');
				$this->form_validation->set_rules('employee_mobile', 'Employee Mobile', 'trim|max_length[15]|required');
				$this->form_validation->set_rules('employee_email', 'Employee Email', 'trim|max_length[100]|required');
				$this->form_validation->set_rules('employee_business_outlet', 'Employee Outlet Name', 'trim|required');

				$this->form_validation->set_rules('employee_expertise', 'Employee Expertise', 'trim');

				$this->form_validation->set_rules('employee_date_of_joining', 'Employee Date of Joining', 'trim|required');
				

				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{
					$data = array(
						'employee_id'           => $this->input->post('employee_id'),
						'employee_first_name' 	=> $this->input->post('employee_first_name'),
						'employee_last_name' 	=> $this->input->post('employee_last_name'),
						'employee_mobile' 	=> $this->input->post('employee_mobile'),
						'employee_address' 	=> $this->input->post('employee_address'),
						'employee_email' 	=> $this->input->post('employee_email'),
						'employee_business_outlet' 	=> $this->input->post('employee_business_outlet'),
						'employee_expertise' 	=> $this->input->post('employee_expertise'),
						'employee_date_of_joining' 	=> $this->input->post('employee_date_of_joining')
					);

					$result = $this->BusinessAdminModel->Update($data,'mss_employees','employee_id');
						
					if($result['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"Employee updated successfully!");
						die;
          }
          elseif($result['error'] == 'true'){
          	$this->ReturnJsonArray(false,true,$result['message']);
						die;
          }
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}	
	}

	public function AddOutlet(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('business_outlet_name', 'Business Outlet Name', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('business_outlet_gst_in', 'Business Outlet GST IN', 'trim|max_length[15]|min_length[15]');
				$this->form_validation->set_rules('business_outlet_address', 'Business Outlet Address', 'trim|required');
				$this->form_validation->set_rules('business_outlet_city', 'Business Outlet City', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('business_outlet_state', 'Business Outlet State', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('business_outlet_pincode', 'Business Outlet Pincode', 'trim|required|max_length[10]');
				$this->form_validation->set_rules('business_outlet_mobile', 'Business Outlet Mobile', 'trim|max_length[15]');
				$this->form_validation->set_rules('business_outlet_landline', 'Business Outlet Landline', 'trim|max_length[15]');
				$this->form_validation->set_rules('business_outlet_email', 'Business Outlet Email', 'trim|max_length[100]');
				$this->form_validation->set_rules('business_outlet_bill_header_msg', 'Business Outlet Bill Header message', 'trim');
				$this->form_validation->set_rules('business_outlet_bill_footer_msg', 'Business Outlet Bill Footer message', 'trim');
				$this->form_validation->set_rules('business_outlet_facebook_url', 'Business Outlet FB URL', 'trim');
				$this->form_validation->set_rules('business_outlet_instagram_url', 'Business Outlet Instagram URL', 'trim');
				$this->form_validation->set_rules('business_outlet_latitude', 'Business Outlet Latitude', 'trim');
				$this->form_validation->set_rules('business_outlet_longitude', 'Business Outlet Longitude', 'trim');

				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{
					$data = array(
						'business_outlet_name' 	=> $this->input->post('business_outlet_name'),
						'business_outlet_gst_in' 	=> $this->input->post('business_outlet_gst_in'),
						'business_outlet_mobile' 	=> $this->input->post('business_outlet_mobile'),
						'business_outlet_landline' 	=> $this->input->post('business_outlet_landline'),
						'business_outlet_address' 	=> $this->input->post('business_outlet_address'),
						'business_outlet_pincode' 	=> $this->input->post('business_outlet_pincode'),
						'business_outlet_state' 	=> $this->input->post('business_outlet_state'),
						'business_outlet_city' 	=> $this->input->post('business_outlet_city'),
						'business_outlet_country' 	=> "India",
						'business_outlet_email' 	=> $this->input->post('business_outlet_email'),
						'business_outlet_bill_header_msg' 	=> $this->input->post('business_outlet_bill_header_msg'),
						'business_outlet_bill_footer_msg' 	=> $this->input->post('business_outlet_bill_footer_msg'),
						'business_outlet_facebook_url' 	=> $this->input->post('business_outlet_facebook_url'),
						'business_outlet_instagram_url' 	=> $this->input->post('business_outlet_instagram_url'),
						'business_outlet_latitude' 	=> $this->input->post('business_outlet_latitude'),
						'business_outlet_longitude' 	=> $this->input->post('business_outlet_longitude'),
						'business_outlet_business_admin' 	=> $this->session->userdata['logged_in']['business_admin_id']
					);

					$result = $this->BusinessAdminModel->Insert($data,'mss_business_outlets');
						
					if($result['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"Outlet added successfully!");
						die;
					}
					elseif($result['error'] == 'true'){
						$this->ReturnJsonArray(false,true,$result['message']);
									die;
					}
				}
			}
			else{
				$data = $this->GetDataForAdmin("Add Outlet");
				$this->load->view('business_admin/ba_add_outlet_view',$data);
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}	
	}

	public function GetBusinessOutlet(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_GET) && !empty($_GET)){
				$data = $this->BusinessAdminModel->DetailsById($_GET['business_outlet_id'],'mss_business_outlets','business_outlet_id');
				header("Content-type: application/json");
				print(json_encode($data['res_arr'], JSON_PRETTY_PRINT));
				die;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function GetEmployee(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_GET) && !empty($_GET)){
				$data = $this->BusinessAdminModel->DetailsById($_GET['employee_id'],'mss_employees','employee_id');
				header("Content-type: application/json");
				print(json_encode($data['res_arr'], JSON_PRETTY_PRINT));
				die;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function GetCategory(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_GET) && !empty($_GET)){
				$data = $this->BusinessAdminModel->DetailsById($_GET['category_id'],'mss_categories','category_id');
				header("Content-type: application/json");
				print(json_encode($data['res_arr'], JSON_PRETTY_PRINT));
				die;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function GetSubCategory(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_GET) && !empty($_GET)){
				$data = $this->BusinessAdminModel->DetailsById($_GET['sub_category_id'],'mss_sub_categories','sub_category_id');
				header("Content-type: application/json");
				print(json_encode($data['res_arr'], JSON_PRETTY_PRINT));
				die;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function GetService(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_GET) && !empty($_GET)){
				$data = $this->BusinessAdminModel->DetailsById($_GET['service_id'],'mss_services','service_id');
				header("Content-type: application/json");
				print(json_encode($data['res_arr'], JSON_PRETTY_PRINT));
				die;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function GetOTCCategory(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_GET) && !empty($_GET)){
				$data = $this->BusinessAdminModel->DetailsById($_GET['otc_category_id'],'mss_otc_categories','otc_category_id');
				header("Content-type: application/json");
				print(json_encode($data['res_arr'], JSON_PRETTY_PRINT));
				die;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function GetRawMaterial(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_GET) && !empty($_GET)){
				$data = $this->BusinessAdminModel->DetailsById($_GET['raw_material_category_id'],'mss_raw_material_categories','raw_material_category_id');
				header("Content-type: application/json");
				print(json_encode($data['res_arr'], JSON_PRETTY_PRINT));
				die;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function GetExpenseType(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_GET) && !empty($_GET)){
				$data = $this->BusinessAdminModel->DetailsById($_GET['expense_type_id'],'mss_expense_types','expense_type_id');
				header("Content-type: application/json");
				print(json_encode($data['res_arr'], JSON_PRETTY_PRINT));
				die;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function GetParticularComposition(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_GET) && !empty($_GET)){
				$where = array(
					'business_admin_id'  => $this->session->userdata['logged_in']['business_admin_id'],
					'business_outlet_id' => $this->session->userdata['outlets']['current_outlet'],
					'service_id'         => $_GET['service_id']
				);
				$data = $this->BusinessAdminModel->ViewComposition($where);
				header("Content-type: application/json");
				print(json_encode($data['res_arr'], JSON_PRETTY_PRINT));
				die;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}	
	}

	public function EditOutlet(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('business_outlet_name', 'Business Outlet Name', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('business_outlet_gst_in', 'Business Outlet GST IN', 'trim|max_length[15]|min_length[15]');
				$this->form_validation->set_rules('business_outlet_address', 'Business Outlet Address', 'trim|required');
				$this->form_validation->set_rules('business_outlet_city', 'Business Outlet City', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('business_outlet_state', 'Business Outlet State', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('business_outlet_pincode', 'Business Outlet Pincode', 'trim|required|max_length[10]');
				$this->form_validation->set_rules('business_outlet_mobile', 'Business Outlet Mobile', 'trim|max_length[15]');
				$this->form_validation->set_rules('business_outlet_landline', 'Business Outlet Landline', 'trim|max_length[15]');
				$this->form_validation->set_rules('business_outlet_email', 'Business Outlet Email', 'trim|max_length[100]');
				$this->form_validation->set_rules('business_outlet_bill_header_msg', 'Business Outlet Bill Header message', 'trim');
				$this->form_validation->set_rules('business_outlet_bill_footer_msg', 'Business Outlet Bill Footer message', 'trim');
				$this->form_validation->set_rules('business_outlet_facebook_url', 'Business Outlet FB URL', 'trim');
				$this->form_validation->set_rules('business_outlet_instagram_url', 'Business Outlet Instagram URL', 'trim');
				$this->form_validation->set_rules('business_outlet_latitude', 'Business Outlet Latitude', 'trim');
				$this->form_validation->set_rules('business_outlet_longitude', 'Business Outlet Longitude', 'trim');

				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{
					$data = array(
						'business_outlet_id'    => $this->input->post('business_outlet_id'),
						'business_outlet_name' 	=> $this->input->post('business_outlet_name'),
						'business_outlet_gst_in' 	=> $this->input->post('business_outlet_gst_in'),
						'business_outlet_mobile' 	=> $this->input->post('business_outlet_mobile'),
						'business_outlet_landline' 	=> $this->input->post('business_outlet_landline'),
						'business_outlet_address' 	=> $this->input->post('business_outlet_address'),
						'business_outlet_pincode' 	=> $this->input->post('business_outlet_pincode'),
						'business_outlet_state' 	=> $this->input->post('business_outlet_state'),
						'business_outlet_city' 	=> $this->input->post('business_outlet_city'),
						'business_outlet_country' 	=> "India",
						'business_outlet_email' 	=> $this->input->post('business_outlet_email'),
						'business_outlet_bill_header_msg' 	=> $this->input->post('business_outlet_bill_header_msg'),
						'business_outlet_bill_footer_msg' 	=> $this->input->post('business_outlet_bill_footer_msg'),
						'business_outlet_facebook_url' 	=> $this->input->post('business_outlet_facebook_url'),
						'business_outlet_instagram_url' 	=> $this->input->post('business_outlet_instagram_url'),
						'business_outlet_latitude' 	=> $this->input->post('business_outlet_latitude'),
						'business_outlet_longitude' 	=> $this->input->post('business_outlet_longitude'),
						'business_outlet_business_admin' 	=> $this->session->userdata['logged_in']['business_admin_id']
					);
					
					$result = $this->BusinessAdminModel->Update($data,'mss_business_outlets','business_outlet_id');
						
					if($result['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"Outlet details updated successfully!");
						die;
          }
          elseif($result['error'] == 'true'){
          	$this->ReturnJsonArray(false,true,$result['message']);
						die;
          }
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}	
	}


	private function GetCategories($outlet_id){
		if($this->IsLoggedIn('business_admin')){
			$where = array(
				'category_business_admin_id' => $this->session->userdata['logged_in']['business_admin_id'],
				'category_is_active'         => TRUE,
				'category_business_outlet_id'=> $outlet_id
			);

			$data = $this->BusinessAdminModel->MultiWhereSelect('mss_categories',$where);
			if($data['success'] == 'true'){	
				return $data['res_arr'];
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}		
	}

	private function GetRawMaterials($outlet_id){
		if($this->IsLoggedIn('business_admin')){
			$where = array(
				'raw_material_business_admin_id' => $this->session->userdata['logged_in']['business_admin_id'],
				'raw_material_is_active'         => TRUE,
				'raw_material_business_outlet_id'=> $outlet_id
			);

			$data = $this->BusinessAdminModel->MultiWhereSelect('mss_raw_material_categories',$where);
			if($data['success'] == 'true'){	
				return $data['res_arr'];
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}		
	}

	public function GetSubCategoriesByCatId(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_GET) && !empty($_GET)){
				$where = array(
					'sub_category_category_id' => $_GET['category_id'],
					'sub_category_is_active'   => TRUE
				);
				
				$data = $this->BusinessAdminModel->MultiWhereSelect('mss_sub_categories',$where);
				header("Content-type: application/json");
				print(json_encode($data['res_arr'], JSON_PRETTY_PRINT));
				die;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function GetServicesBySubCatId(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_GET) && !empty($_GET)){
				$where = array(
					'service_sub_category_id'  => $_GET['sub_category_id'],
					'service_is_active'   => TRUE
				);
				
				$data = $this->BusinessAdminModel->MultiWhereSelect('mss_services',$where);
				header("Content-type: application/json");
				print(json_encode($data['res_arr'], JSON_PRETTY_PRINT));
				die;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	private function GetSubCategories($outlet_id){
		if($this->IsLoggedIn('business_admin')){
			$where = array(
				'category_business_admin_id' => $this->session->userdata['logged_in']['business_admin_id'],
				'sub_category_is_active'     => TRUE,
				'category_business_outlet_id'=>$outlet_id
			);

			$data = $this->BusinessAdminModel->SubCategories($where);
			if($data['success'] == 'true'){	
				return $data['res_arr'];
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}		
	}

	private function GetServices($outlet_id){
		if($this->IsLoggedIn('business_admin')){
			$where = array(
				'category_business_admin_id' => $this->session->userdata['logged_in']['business_admin_id'],
				'service_is_active'     => TRUE,
				'category_business_outlet_id'=>$outlet_id
			);

			$data = $this->BusinessAdminModel->Services($where);
			if($data['success'] == 'true'){	
				return $data['res_arr'];
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}		
	}
	// For fetching the packages from database
	private function GetPackages($outlet_id){
		if($this->IsLoggedIn('business_admin')){
			$where = array(
				'category_business_admin_id' => $this->session->userdata['logged_in']['business_admin_id'],
				'service_is_active'     => TRUE,
				'category_business_outlet_id'=>$outlet_id
			);

			$data = $this->BusinessAdminModel->Services($where);
			if($data['success'] == 'true'){	
				return $data['res_arr'];
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}		
	}
	//

	private function GetOTCCategories($outlet_id){
		if($this->IsLoggedIn('business_admin')){
			$where = array(
				'category_business_admin_id' => $this->session->userdata['logged_in']['business_admin_id'],
				'otc_is_active'     => TRUE,
				'category_business_outlet_id'=>$outlet_id
			);

			$data = $this->BusinessAdminModel->OTC($where);
			if($data['success'] == 'true'){	
				return $data['res_arr'];
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}		
	}

	private function GetExpensesTypes($outlet_id){
		if($this->IsLoggedIn('business_admin')){
			$where = array(
				'expense_type_business_admin_id'  => $this->session->userdata['logged_in']['business_admin_id'],
				'expense_type_business_outlet_id' => $outlet_id
			);

			$data = $this->BusinessAdminModel->MultiWhereSelect('mss_expense_types',$where);
			if($data['success'] == 'true'){	
				return $data['res_arr'];
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}		
	}

	private function GetCompositions($outlet_id){
		if($this->IsLoggedIn('business_admin')){
			$where = array(
				'business_admin_id'  => $this->session->userdata['logged_in']['business_admin_id'],
				'business_outlet_id' => $outlet_id
			);

			$data = $this->BusinessAdminModel->ViewCompositionBasic($where);
			if($data['success'] == 'true'){	
				return $data['res_arr'];
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}		
	}

	private function GetBusinessAdminEmployees(){
		if($this->IsLoggedIn('business_admin')){
			$where = array(
				'employee_business_admin' => $this->session->userdata['logged_in']['business_admin_id']
			);

			$data = $this->BusinessAdminModel->MultiWhereSelect('mss_employees',$where);
			if($data['success'] == 'true'){	
				return $data['res_arr'];
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}		
	}


	//To Change Employee Status
	public function ChangeEmployeeStatus(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				if($this->input->post('activate') == 'true' && $this->input->post('deactivate') == 'false'){
					//Activate the Employee
					$data = array(
					  "employee_id"          => $this->input->post('employee_id'),
						"employee_is_active"   => TRUE
					);

					$status = $this->BusinessAdminModel->Update($data,'mss_employees','employee_id');
					if($status['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"Activated successfully!");
						die;
					}
					elseif($status['error'] == 'true'){
						$this->ReturnJsonArray(false,true,$status['message']);
						die;
					}
				}	
				elseif($this->input->post('activate') == 'false' && $this->input->post('deactivate') == 'true'){
					//Deactivate the Employee
					$data = array(
						"employee_id" => $this->input->post('employee_id'),	
						"employee_is_active"   => FALSE
					);

					$status = $this->BusinessAdminModel->Update($data,'mss_employees','employee_id');
					
					if($status['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"Deactivated successfully!");
						die;
					}
					elseif($status['error'] == 'true'){
						$this->ReturnJsonArray(false,true,$status['message']);
						die;
					}
				}		       
	    }
	    else{
				$this->ReturnJsonArray(false,true,'Not a POST Request !');
				die;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function DeactivateCategory(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				if($this->input->post('activate') == 'false' && $this->input->post('deactivate') == 'true'){
					//Activate the Employee
					$data = array(
					  "category_id"          => $this->input->post('category_id'),
						"category_is_active"   => FALSE
					);

					$status = $this->BusinessAdminModel->DeactiveCategory($data['category_id']);
					if($status['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"Deleted successfully!");
						die;
					}
					elseif($status['error'] == 'true'){
						$this->ReturnJsonArray(false,true,$status['message']);
						die;
					}
				}	    
	    }
	    else{
				$this->ReturnJsonArray(false,true,'Not a POST Request !');
				die;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function DeactivateSubCategory(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				if($this->input->post('activate') == 'false' && $this->input->post('deactivate') == 'true'){
					//Activate the Employee
					$data = array(
					  "sub_category_id"          => $this->input->post('sub_category_id'),
						"sub_category_is_active"   => FALSE
					);

					$status = $this->BusinessAdminModel->DeactiveSubCategory($data['sub_category_id']);
					if($status['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"Deleted successfully!");
						die;
					}
					elseif($status['error'] == 'true'){
						$this->ReturnJsonArray(false,true,$status['message']);
						die;
					}
				}	    
	    }
	    else{
				$this->ReturnJsonArray(false,true,'Not a POST Request !');
				die;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function DeactivateService(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				if($this->input->post('activate') == 'false' && $this->input->post('deactivate') == 'true'){
					//Activate the Employee
					$data = array(
					  "service_id"          => $this->input->post('service_id'),
						"service_is_active"   => FALSE
					);

					$status = $this->BusinessAdminModel->Update($data,'mss_services','service_id');
					if($status['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"Deleted successfully!");
						die;
					}
					elseif($status['error'] == 'true'){
						$this->ReturnJsonArray(false,true,$status['message']);
						die;
					}
				}	    
	    }
	    else{
				$this->ReturnJsonArray(false,true,'Not a POST Request !');
				die;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function DeactivateOTCCategory(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				if($this->input->post('activate') == 'false' && $this->input->post('deactivate') == 'true'){
					//Activate the Employee
					$data = array(
					  "otc_category_id"          => $this->input->post('otc_category_id'),
						"otc_is_active"   => FALSE
					);

					$status = $this->BusinessAdminModel->Update($data,'mss_otc_categories','otc_category_id');
					if($status['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"Deleted successfully!");
						die;
					}
					elseif($status['error'] == 'true'){
						$this->ReturnJsonArray(false,true,$status['message']);
						die;
					}
				}	    
	    }
	    else{
				$this->ReturnJsonArray(false,true,'Not a POST Request !');
				die;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function DeactivateRawMaterial(){
		if($this->IsLoggedIn('business_admin')){
			if(isset($_POST) && !empty($_POST)){
				if($this->input->post('activate') == 'false' && $this->input->post('deactivate') == 'true'){
					//Activate the Employee
					$data = array(
					  "raw_material_category_id"          => $this->input->post('raw_material_category_id'),
						"raw_material_is_active"   => FALSE
					);

					$status = $this->BusinessAdminModel->Update($data,'mss_raw_material_categories','raw_material_category_id');
					if($status['success'] == 'true'){
						$this->ReturnJsonArray(true,false,"Deleted successfully!");
						die;
					}
					elseif($status['error'] == 'true'){
						$this->ReturnJsonArray(false,true,$status['message']);
						die;
					}
				}	    
	    }
	    else{
				$this->ReturnJsonArray(false,true,'Not a POST Request !');
				die;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function SelectOutlet(){
		if($this->IsLoggedIn('business_admin')){
			$outlet_id = $this->uri->segment(3);
			if(isset($this->session->userdata['outlets'])){
				$this->session->unset_userdata('outlets');
				$session_data = array(
					'current_outlet' => $outlet_id
				);
				$this->session->set_userdata('outlets', $session_data);
			}
			else{
				$session_data = array(
					'current_outlet' => $outlet_id
				);
				$this->session->set_userdata('outlets', $session_data);	
			}

			redirect(base_url()."index.php/BusinessAdmin/Dashboard/",'refresh');
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}


// Get CustomerPackages
private function GetCustomerPackages(){
	if($this->IsLoggedIn('business_admin')){
		$where = array(
			'business_admin_id' => $this->session->userdata['logged_in']['business_admin_id'],
			'business_outlet_id'=>$this->session->userdata['outlets']['current_outlet']

		);
		$data = $this->BusinessAdminModel->MultiWhereSelect('mss_packages',$where);
		if($data['success'] == 'true'){	
			return $data['res_arr'];
		}
	}
	else{
		$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
	}	
}
	
//Add packages function
public function packages (){
	if($this->IsLoggedIn('business_admin')){		
		if(isset($_POST) && !empty($_POST)){
			$this->form_validation->set_rules('package_name', 'package_name', 'trim|required|max_length[100]');
			$this->form_validation->set_rules('upfront_amount', 'upfront_amount', 'trim|max_length[5]|min_length[1]');
			$this->form_validation->set_rules('validity', 'validity', 'trim|required');
			$this->form_validation->set_rules('package_type', 'package_type', 'trim|required|max_length[100]');
			
			if ($this->form_validation->run() == FALSE) 
			{
				$data = array(
								'success' => 'false',
								'error'   => 'true',
								'message' =>  validation_errors()
							 );
				header("Content-type: application/json");
				print(json_encode($data, JSON_PRETTY_PRINT));
				die;
			}
			else{
				$data = array(
					'package_name' 	=> $this->input->post('package_name'),
					'upfront_amount' 	=> $this->input->post('upfront_amount'),
					'validity' 	=> $this->input->post('validity'),
					'package_type' 	=> $this->input->post('package_type')
					
				);

				$result = $this->BusinessAdminModel->Insert($data,'mss_packages');
				
				if($result['success'] == 'true'){
					$this->ReturnJsonArray(true,false,"Package added successfully!");
					die;
				}
				elseif($result['error'] == 'true'){
					$this->ReturnJsonArray(false,true,$result['message']);
								die;
				}
			}
		}
		else{
			$data = $this->GetDataForAdmin("packages");
			$data['customer_packages'] = $this->GetCustomerPackages();
			$this->load->view('business_admin/ba_packages_view',$data);
		}
		
	}
	else{
		$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
	}	
}
//Get Expense Tracker
private function GetExpenses(){
	if($this->IsLoggedIn('business_admin')){
		$where = array(
			'expense_type_business_admin_id' => $this->session->userdata['logged_in']['business_admin_id'],
			'expense_type_business_outlet_id'=>$this->session->userdata['outlets']['current_outlet']
			
			

		);
		// $data = $this->BusinessAdminModel->MultiWhereSelect('mss_expenses',$where);
		$data = $this->BusinessAdminModel->MultiWhereSelect('mss_expense_types',$where);
		if($data['success'] == 'true'){	
			return $data['res_arr'];
		}
	}
	else{
		$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
	}	
}
	
//Expense Tracker function
public function Expenses (){
	if($this->IsLoggedIn('business_admin')){		
		if(isset($_POST) && !empty($_POST)){
			$this->form_validation->set_rules('expense_type', 'expense_type', 'trim|required|max_length[50]');
			$this->form_validation->set_rules('item_name', 'item_name', 'trim|max_length[50]');
			$this->form_validation->set_rules('amount', 'amount', 'trim|required');
			$this->form_validation->set_rules('quantity', 'quantity', 'trim|required|max_length[100]');
			$this->form_validation->set_rules('unit', 'unit', 'trim|required|max_length[10]');
			$this->form_validation->set_rules('payment_mode', 'payment_mode', 'trim|max_length[50]');
			$this->form_validation->set_rules('expense_status', 'expense_status', 'trim|required');
			if ($this->form_validation->run() == FALSE) 
			{
				$data = array(
								'success' => 'false',
								'error'   => 'true',
								'message' =>  validation_errors()
							 );
				print_r($data);
				exit;
				header("Content-type: application/json");
				print(json_encode($data, JSON_PRETTY_PRINT));
				die;
			}
			else{
				
				$data = array(
					'expense_date' 	=> $this->input->post('expense_date'),
					'expense_type' 	=> $this->input->post('expense_type'),
					'item_name' 	=> $this->input->post('item_name'),
					'amount' 	=> $this->input->post('amount'),
					'quantity' 	=> $this->input->post('quantity'),
					'unit' 	=> $this->input->post('unit'),
					'payment_mode' 	=> $this->input->post('payment_mode'),
					'expense_status' 	=> $this->input->post('expense_status')
					
					
				);

				$result = $this->BusinessAdminModel->Insert($data,'mss_expenses');
				
				if($result['success'] == 'true'){
					$this->ReturnJsonArray(true,false,"Expenses added successfully!");
					die;
				}
				elseif($result['error'] == 'true'){
					$this->ReturnJsonArray(false,true,$result['message']);
								die;
				}
			}
		}
		else{
			$data = $this->GetDataForAdmin("expenses");
			$data['expenses'] = $this->GetExpenses();
			// print_r($data['expenses']);
			// exit;
			$data['expense_type'] = $this->GetExpensesTypes($this->session->userdata['outlets']['current_outlet']);
			
			$this->load->view('business_admin/ba_expense_view',$data);
			// print_r($data);
			// exit;
			
		}
		
	}
	else{
		$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
	}	
}
}

