<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cashier extends CI_Controller {

	/*
		Definition and usage of temporary session variables for POS billings
		

		--> $this->session->userdata['POS']['.$customer_id.']

		Now to access any particular value
		
		--> $this->session->userdata['POS']['.$customer_id.']['customer_name']		
		

		In the above session we will have multiple session varibles for corresponding
		to each customer who are currently availing the services in the Salon

		They can now be deleted from the session variables very easily 
	*/

	/*
		Definition and usage of temporary session variables for the Cart for customers

		--> $this->session->userdata['cart']['.$customer_id.'][Array of Added Services]
	
		This session variable will be completely distroyed upon logout and partially unset upon settle order for particular customer...

	*/
	private function IsLoggedIn($type){
		if (!isset($this->session->userdata['logged_in'])) {
    	return false;
    }
    else{
    	if($this->session->userdata['logged_in']['user_type'] == $type){
    		return true;
    	}
    	else{
    		return false;
    	}
    }
	}

	private function GetDataForCashier($title){
		$data = array();
		$data['title'] = $title;
		$data['business_admin_packages'] = $this->GetBusinessAdminPackages();
		$data['cashier_details']  = $this->GetCashierDetails();
		return $data;
	}
	
	//Default Page for cashier
	public function index(){
		if($this->IsLoggedIn('cashier')){
			$data = $this->GetDataForCashier("Dashboard");
			
			if(isset($this->session->userdata['POS'])){
				$data['customers'] = $this->session->userdata['POS'];
			}

			if(isset($this->session->userdata['cart'])){
				$data['cart'] = $this->session->userdata['cart'];
			}

			if(isset($this->session->userdata['payment'])){
 				$this->session->unset_userdata('payment');
 			}

			$this->load->view('cashier/cashier_dashboard_view',$data);
		}
		else{
			$data['title'] = "Login";
			$this->load->view('cashier/cashier_login_view',$data);
		}
	}

	//constructor of the Alumni Controller
	public function __construct(){
	   parent::__construct();
	   date_default_timezone_set('Asia/Kolkata');
	   $this->load->model('AnalyticsModel');
	   $this->load->model('CashierModel');
	   $this->load->model('AppointmentsModel');
	   $this->load->model('POSModel');
	   $this->load->model('BusinessAdminModel');
  }
	
  private function ReturnJsonArray($success,$error,$message){
  	if($success == true && $error == false){
  		$data = array(
						'success' => 'true',
						'error'   => 'false',
						'message' =>  $message
					 );
			header("Content-type: application/json");
			print(json_encode($data, JSON_PRETTY_PRINT));
		}
		elseif ($success == false && $error == true) {
			$data = array(
							'success' => 'false',
							'error'   => 'true',
							'message' =>  $message
						 );
			header("Content-type: application/json");
			print(json_encode($data, JSON_PRETTY_PRINT));
		}
  }

  //Testing Function
  private function PrettyPrintArray($data){
  	print("<pre>".print_r($data,true)."</pre>");
  	die;
  }

	//function for logging out the user
	public function Logout(){
		if(isset($this->session->userdata['logged_in']) && !empty($this->session->userdata['logged_in'])){
 			$this->session->unset_userdata('logged_in');
 			
 			if(isset($this->session->userdata['POS'])){
 				$this->session->unset_userdata('POS');
 			}
 			if(isset($this->session->userdata['cart'])){
 				$this->session->unset_userdata('cart');
 			}

 			if(isset($this->session->userdata['payment'])){
 				$this->session->unset_userdata('payment');
 			}
 			
 			$this->session->sess_destroy();
 		}
		redirect(base_url(),'refresh');
	}

	//function for logging out the user
	private function LogoutUrl($url){
		if(isset($this->session->userdata['logged_in']) && !empty($this->session->userdata['logged_in'])){
 			$this->session->unset_userdata('logged_in');
 			
 			if(isset($this->session->userdata['POS'])){
 				$this->session->unset_userdata('POS');
 			}
 			if(isset($this->session->userdata['cart'])){
 				$this->session->unset_userdata('cart');
 			}

 			if(isset($this->session->userdata['payment'])){
 				$this->session->unset_userdata('payment');
 			}
 			
 			$this->session->sess_destroy();
 		}  
	  redirect($url,'refresh');
	}

	//function for login
	public function Login(){
		if(isset($_POST) && !empty($_POST)){
			$this->form_validation->set_rules('employee_email', 'Email', 'trim|required|max_length[100]');
			$this->form_validation->set_rules('employee_password', 'Password', 'trim|required');
			
			if ($this->form_validation->run() == FALSE) 
			{
				$data = array(
								'success' => 'false',
								'error'   => 'true',
								'message' =>  validation_errors()
							 );
				header("Content-type: application/json");
				print(json_encode($data, JSON_PRETTY_PRINT));
				die;
			}  
			else 
			{
				$data = array(
					'employee_email' 	=> $this->input->post('employee_email'),
					'employee_password' => $this->input->post('employee_password')
				);
				
				$result = $this->CashierModel->CashierLogin($data);
				
				if ($result['success'] == 'true') 
				{
					$result = $this->CashierModel->CashierByEmail($data['employee_email']);
					
					if($result['success'] == true){
						if($data['employee_email'] == $result['res_arr']['employee_email'] && password_verify($data['employee_password'],$result['res_arr']['employee_password']) && (int)$result['res_arr']['employee_is_active'] && $result['res_arr']['business_admin_account_expiry_date'] >= date('Y-m-d'))
						{ 
							$session_data = array(
								'employee_id'      => $result['res_arr']['employee_id'],
								'employee_email'   => $result['res_arr']['employee_email'],
								'user_type'        => 'cashier',
								'business_admin_id'=> $result['res_arr']['employee_business_admin'],
								'business_outlet_id'=> $result['res_arr']['employee_business_outlet']
							);
							
							$this->session->set_userdata('logged_in', $session_data);
							$this->ReturnJsonArray(true,false,'Valid login!');
							die;
						}
						else
						{
							if (!(int)$result['res_arr']['employee_is_active']) {
								$this->ReturnJsonArray(false,true,'Your account is suspended. Please contact Admin');
								die;	
							}
							elseif($result['res_arr']['business_admin_account_expiry_date'] < date('Y-m-d')) {
								$this->ReturnJsonArray(false,true,'Your account is expired. Please renew your subscription!');
								die;
							}
							else{
								$this->ReturnJsonArray(false,true,'Wrong email or password !');
								die;
							}
						}
					}
					elseif($result['error'] == 'true'){
						$this->ReturnJsonArray(false,true,$result['message']);
						die;
					}
				}
				elseif($result['error'] == 'true'){
					$this->ReturnJsonArray(false,true,$result['message']);
					die;
				}
			}
		}
		else{
			$data['title'] = "Login";
			$this->load->view('cashier/cashier_login_view',$data);
		}
	}

	public function ResetCashierPassword(){
		if($this->IsLoggedIn('cashier')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('new_password', 'New Password', 'trim|required');
				$this->form_validation->set_rules('confirm_new_password', 'Confirm Password', 'trim|required');

				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{
					$new_password 		  =  $this->input->post('new_password');
					$confirm_new_password =  $this->input->post('confirm_new_password');
					if($new_password === $confirm_new_password){
						$data = array(
											"employee_password" => password_hash($new_password,PASSWORD_DEFAULT),
									  	"employee_id"       => $this->session->userdata['logged_in']['employee_id']
										);
						$result = $this->CashierModel->Update($data,'mss_employees','employee_id');
						
						if($result['success'] == 'true'){
							$this->ReturnJsonArray(true,false,"Password changed successfully!");
							die;
            }
            elseif($result['error'] == 'true'){
            	$this->ReturnJsonArray(false,true,"DB Error!");
							die;
            }
					}
					else{
						$this->ReturnJsonArray(false,true,"Passwords Do Not Match!");
						die;
					}
				}	
		  }
		  else{
		    $this->ReturnJsonArray(false,true,"Not a POST Request !");
				die;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}					
	}

	//Dashboard
	public function Dashboard(){
		if($this->IsLoggedIn('cashier')){
			$data = $this->GetDataForCashier("Dashboard");
			if(isset($this->session->userdata['POS'])){
				$data['customers'] = $this->session->userdata['POS'];
			}

			if(isset($this->session->userdata['cart'])){
				$data['cart'] = $this->session->userdata['cart'];
			}

			if(isset($this->session->userdata['payment'])){
 				$this->session->unset_userdata('payment');
 			}

			$this->load->view('cashier/cashier_dashboard_view',$data);
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}
	}

	private function GetBusinessAdminPackages(){
		if($this->IsLoggedIn('cashier')){
			$data = $this->BusinessAdminModel->BusinessAdminPackages($this->session->userdata['logged_in']['business_admin_id']);
			if($data['success'] == 'true'){
				$temp = array();
				
				foreach ($data['res_arr'] as $d) {
					if($d['package_expiry_date'] >= date('Y-m-d')){
						array_push($temp,$d['package_name']);
					}
				}
				return $temp;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}	
	}

	private function GetCashierDetails(){
		if($this->IsLoggedIn('cashier')){

			$data = $this->CashierModel->GetCashierPersonal($this->session->userdata['logged_in']['employee_id']);
			if($data['success'] == 'true'){	
				return $data['res_arr'];
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}	
	}

	public function GetCustomerData(){
		if($this->IsLoggedIn('cashier')){
			if(isset($_GET) && !empty($_GET)){
				$data = $this->CashierModel->SearchCustomers($_GET['query'],$this->session->userdata['logged_in']['business_admin_id'],$this->session->userdata['logged_in']['business_outlet_id']);
				if($data['success'] == 'true'){	
					$this->ReturnJsonArray(true,false,$data['res_arr']);
					die;
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}
	}

	public function GetCustomer(){
		if($this->IsLoggedIn('cashier')){
			if(isset($_GET) && !empty($_GET)){
				$data = $this->CashierModel->DetailsById($_GET['customer_id'],'mss_customers','customer_id');
				if($data['success'] == 'true'){	
					
					header("Content-type: application/json");
					print(json_encode($data['res_arr'], JSON_PRETTY_PRINT));
					die;	
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}	
	}

	private function GetCustomerBilling($customer_id){
		if($this->IsLoggedIn('cashier')){
			$data = $this->CashierModel->DetailsById($customer_id,'mss_customers','customer_id');
			if($data['success'] == 'true'){	
				return $data['res_arr'];
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}		
	}

	public function AddNewCustomer(){
		if($this->IsLoggedIn('cashier')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('customer_title', 'Title', 'trim|required|max_length[10]');
				$this->form_validation->set_rules('customer_name', 'Customer Name', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('customer_mobile', 'Customer Mobile', 'trim|required|max_length[15]');
				$this->form_validation->set_rules('customer_dob', 'Customer date of birth', 'trim|required');
				
				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{
					$where = array(
						'customer_business_admin_id' => $this->session->userdata['logged_in']['business_admin_id'],
						'customer_business_outlet_id' => $this->session->userdata['logged_in']['business_outlet_id'],
						'customer_mobile'  => $this->input->post('customer_mobile')
					);
					
					$customerExists = $this->CashierModel->CheckCustomerExists($where);
					
					if($customerExists['success'] == 'false' && $customerExists['error'] == 'true' ){
						$this->ReturnJsonArray(false,true,$customerExists['message']);
						die;
					}	
					else{
						$data = array(
							'customer_title' 	=> $this->input->post('customer_title'),
							'customer_name' 	=> $this->input->post('customer_name'),
							'customer_dob'    => $this->input->post('customer_dob'),
							'customer_mobile' => $this->input->post('customer_mobile'),
							'customer_business_admin_id' => $this->session->userdata['logged_in']['business_admin_id'],
							'customer_business_outlet_id' => $this->session->userdata['logged_in']['business_outlet_id']
						);

						$result = $this->CashierModel->Insert($data,'mss_customers');
							
						if($result['success'] == 'true'){
							
							//After Adding customer we have to add it to session varible
							$sess_data = $this->GetCustomerBilling($result['res_arr']['insert_id']);
							$curr_sess_cust_data = array();
							if(!isset($this->session->userdata['POS'])){
								array_push($curr_sess_cust_data, $sess_data);
								$this->session->set_userdata('POS', $curr_sess_cust_data);
							}
							else{
								$curr_sess_cust_data = $this->session->userdata['POS'];
								array_push($curr_sess_cust_data, $sess_data);
								$this->session->set_userdata('POS', $curr_sess_cust_data);
							}
							////////////////////////////////////////////////////////////

							$this->ReturnJsonArray(true,false,"Customer added successfully!");
							die;
	          }
	          elseif($result['error'] == 'true'){
	          	$this->ReturnJsonArray(false,true,$result['message']);
							die;
	          }
	        }
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	public function EditCustomerDetails(){
		if($this->IsLoggedIn('cashier')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('customer_segment', 'Customer Segment', 'trim|required');
				
				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{
				
					$data = array(
						'customer_segment' 	=> $this->input->post('customer_segment'),
						'customer_id' => $this->input->post('customer_id')
					);

					$result = $this->CashierModel->Update($data,'mss_customers','customer_id');
						
					if($result['success'] == 'true'){
						//After updating customer we have to add it to session varible
						$sess_data = $this->GetCustomerBilling($data['customer_id']);
						$curr_sess_cust_data = array();
						if(!isset($this->session->userdata['POS'])){
							array_push($curr_sess_cust_data, $sess_data);
							$this->session->set_userdata('POS', $curr_sess_cust_data);
						}
						else{
							$curr_sess_cust_data = $this->session->userdata['POS'];
							array_push($curr_sess_cust_data, $sess_data);
							$this->session->set_userdata('POS', $curr_sess_cust_data);
						}
						////////////////////////////////////////////////////////////

						$this->ReturnJsonArray(true,false,"Customer updated successfully!");
						die;
          }
          elseif($result['error'] == 'true'){
          	$this->ReturnJsonArray(false,true,$result['message']);
						die;
          }
	        
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/BusinessAdmin/");
		}
	}

	//Very Important function
	public function PerformBilling(){
		if($this->IsLoggedIn('cashier')){	
			$customer_id = $this->uri->segment(3);
			if(isset($customer_id)){
				//Check whether customer belongs to the logged cashier's shop and business admin
				$where = array(
					'business_admin_id' => $this->session->userdata['logged_in']['business_admin_id'],
					'business_outlet_id'=> $this->session->userdata['logged_in']['business_outlet_id'],
					'customer_id'       => $customer_id
				);

				$check = $this->CashierModel->VerifyCustomer($where);
				if($check['success'] == 'true'){	
					$data = $this->GetDataForCashier("Final Billing");
					
					$data['individual_customer'] = $this->GetCustomerBilling($customer_id);
					
					$data['categories']  = $this->GetCategories($this->session->userdata['logged_in']['business_outlet_id']);
					
					$data['experts'] = $this->GetExperts();
					
					if(isset($this->session->userdata['cart'][$customer_id])){
						$data['cart'] = $this->session->userdata['cart'][$customer_id];
					}

					if(isset($this->session->userdata['payment'])){
						$data['payment'] = $this->session->userdata['payment'][$customer_id];
					}

					$this->load->view('cashier/cashier_do_billing_view',$data);
				}
				elseif ($check['error'] == 'true'){
					$data = array(
						'heading' => "Illegal Access!",
						'message' => $check['message']
					);
					$this->load->view('errors/html/error_general',$data);	
				}
			}
			else{
				$data = array(
					'heading' => "Illegal Access!",
					'message' => "Customer details/ID missing. Please do not change url!"
				);
				$this->load->view('errors/html/error_general',$data);
			}	
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}	
	}

	private function GetCategories($outlet_id){
		if($this->IsLoggedIn('cashier')){
			$where = array(
				'category_business_admin_id' => $this->session->userdata['logged_in']['business_admin_id'],
				'category_is_active'         => TRUE,
				'category_business_outlet_id'=> $outlet_id
			);

			$data = $this->BusinessAdminModel->MultiWhereSelect('mss_categories',$where);
			if($data['success'] == 'true'){	
				return $data['res_arr'];
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}		
	}

	private function GetSubCategories($outlet_id){
		if($this->IsLoggedIn('cashier')){
			$where = array(
				'category_business_admin_id' => $this->session->userdata['logged_in']['business_admin_id'],
				'sub_category_is_active'     => TRUE,
				'category_business_outlet_id'=>$outlet_id
			);

			$data = $this->BusinessAdminModel->SubCategories($where);
			if($data['success'] == 'true'){	
				return $data['res_arr'];
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}		
	}

	private function GetServices($outlet_id){
		if($this->IsLoggedIn('cashier')){
			$where = array(
				'category_business_admin_id' => $this->session->userdata['logged_in']['business_admin_id'],
				'service_is_active'     => TRUE,
				'category_business_outlet_id'=>$outlet_id
			);

			$data = $this->BusinessAdminModel->Services($where);
			if($data['success'] == 'true'){	
				return $data['res_arr'];
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}		
	}

	private function GetOTCCategories($outlet_id){
		if($this->IsLoggedIn('cashier')){
			$where = array(
				'category_business_admin_id' => $this->session->userdata['logged_in']['business_admin_id'],
				'otc_is_active'     => TRUE,
				'category_business_outlet_id'=>$outlet_id
			);

			$data = $this->BusinessAdminModel->OTC($where);
			if($data['success'] == 'true'){	
				return $data['res_arr'];
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}		
	}

	public function GetSubCategoriesByCatId(){
		if($this->IsLoggedIn('cashier')){
			if(isset($_GET) && !empty($_GET)){
				$where = array(
					'sub_category_category_id' => $_GET['category_id'],
					'sub_category_is_active'   => TRUE
				);
				
				$data = $this->BusinessAdminModel->MultiWhereSelect('mss_sub_categories',$where);
				header("Content-type: application/json");
				print(json_encode($data['res_arr'], JSON_PRETTY_PRINT));
				die;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}
	}

	public function GetServicesBySubCatId(){
		if($this->IsLoggedIn('cashier')){
			if(isset($_GET) && !empty($_GET)){
				$where = array(
					'service_sub_category_id'  => $_GET['sub_category_id'],
					'service_is_active'   => TRUE
				);
				
				$data = $this->BusinessAdminModel->MultiWhereSelect('mss_services',$where);
				header("Content-type: application/json");
				print(json_encode($data['res_arr'], JSON_PRETTY_PRINT));
				die;
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}
	}

	private function GetExperts(){
		if($this->IsLoggedIn('cashier')){
			$where = array(
				'employee_business_admin' => $this->session->userdata['logged_in']['business_admin_id'],
				'employee_business_outlet'=> $this->session->userdata['logged_in']['business_outlet_id'],
				'employee_is_active' => TRUE
			);

			$data = $this->CashierModel->MultiWhereSelect('mss_employees',$where);
			if($data['success'] == 'true'){	
				return $data['res_arr'];
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}		
	}

	private function ShopDetails(){
		if($this->IsLoggedIn('cashier')){
			$where = array(
				'business_outlet_business_admin' => $this->session->userdata['logged_in']['business_admin_id'],
				'business_outlet_id'=> $this->session->userdata['logged_in']['business_outlet_id'],
			);

			$data = $this->CashierModel->DetailsById($where['business_outlet_id'],'mss_business_outlets','business_outlet_id');
			if($data['success'] == 'true'){	
				return $data['res_arr'];
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}		
	}

	public function AddToCart(){
		if($this->IsLoggedIn('cashier')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('service_name', 'Service Name', 'trim|required|max_length[100]');
				$this->form_validation->set_rules('service_total_value', 'Service Total Value', 'trim|required');
				$this->form_validation->set_rules('service_quantity', 'Service Quantity', 'trim|required');
				$this->form_validation->set_rules('service_discount_percentage', 'Service Discount Percentage', 'trim|required');
				$this->form_validation->set_rules('service_discount_absolute', 'Service Discount Absolute', 'trim|required');
				$this->form_validation->set_rules('service_expert_id', 'Service Expert Name', 'trim|required');
				$this->form_validation->set_rules('service_price_inr', 'Service Price Inr', 'trim|required');
				$this->form_validation->set_rules('customer_id', 'Customer Name', 'trim|required');
				$this->form_validation->set_rules('service_id', 'Service Name', 'trim|required');

				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{

					if(isset($this->session->userdata['payment'])){
		 				$this->session->unset_userdata('payment');
		 			}

					$data = array(
										'customer_id'								 => $this->input->post('customer_id'),
										'service_id'  							 => $this->input->post('service_id'),
										'service_name'							 => $this->input->post('service_name'),
										'service_total_value'				 => $this->input->post('service_total_value'),
										'service_quantity'					 => $this->input->post('service_quantity'),
										'service_discount_percentage'=> $this->input->post('service_discount_percentage'),
										'service_discount_absolute'  => $this->input->post('service_discount_absolute'),
										'service_expert_id'          => $this->input->post('service_expert_id'),
										'service_price_inr'          => $this->input->post('service_price_inr'),
										'service_gst_percentage'     => $this->input->post('service_gst_percentage'),
										'service_est_time'  => $this->input->post('service_est_time')
									);

			
					//Adding the cart product to particular customer's cart
					$curr_sess_cart_data = array();
					$sess_data = array($data);
					if(!isset($this->session->userdata['cart'])){
						$curr_sess_cart_data  += ["".$this->input->post('customer_id')."" => $sess_data];
						$this->session->set_userdata('cart', $curr_sess_cart_data);
					}
					else{
						$curr_sess_cart_data = $this->session->userdata['cart'];

						if(isset($curr_sess_cart_data["".$this->input->post('customer_id').""]) || !empty($curr_sess_cart_data["".$this->input->post('customer_id').""])){
							
							array_push($curr_sess_cart_data["".$this->input->post('customer_id').""], $data);
							$this->session->set_userdata('cart', $curr_sess_cart_data);
						}
						else{
							$curr_sess_cart_data  += ["".$this->input->post('customer_id')."" => $sess_data];
							$this->session->set_userdata('cart', $curr_sess_cart_data);
						}
					}
					/********************************************************************/
					$this->ReturnJsonArray(true,false,"Your Cart updated successfully!");
					die;
				}
			}
			else{
				$this->ReturnJsonArray(false,true,"Not a valid request!");
				die;
			}		
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}	
	}

	public function DeleteCartItem(){
		if($this->IsLoggedIn('cashier')){
			if(isset($_GET) && !empty($_GET)){
				$service_id = $_GET['service_id'];
				$customer_id = $_GET['customer_id'];
				
				if(isset($this->session->userdata['payment'])){
	 				$this->session->unset_userdata('payment');
	 			}

				//Delete the cart product to particular customer's cart
				if(!isset($this->session->userdata['cart']) || empty($this->session->userdata['cart'])){
					$this->ReturnJsonArray(false,true,"Cart is empty!");
					die;
				}
				else{
					$overall_cart_data = $this->session->userdata['cart'];
					$key = array_search($service_id, array_column($overall_cart_data[''.$customer_id.''], 'service_id'));
					unset($overall_cart_data[''.$customer_id.''][$key]);	
					array_splice($overall_cart_data[''.$customer_id.''], $key,$key);
					$this->session->set_userdata('cart', $overall_cart_data);

					$this->ReturnJsonArray(true,false,"Item deleted successfully!");
					die;
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}
	}	

	public function ApplyExtraDiscount(){
		if($this->IsLoggedIn('cashier')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('cart_discount_absolute', 'Discount Absolute', 'trim|required');
				$this->form_validation->set_rules('cart_discount_percentage', 'Discount Percentage', 'trim|required');
				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{	
					$customer_id = $this->input->post('customer_id');
					$curr_sess_payment_data = array();
					if(!isset($this->session->userdata['payment'][''.$customer_id.''])){
						$payment_data = array(
														'full_payment_info' => array(),
														'split_payment_info' => array(),
														'discount_info' => array(
															'cart_discount_absolute' => $this->input->post('cart_discount_absolute'),
															'cart_discount_percentage' => $this->input->post('cart_discount_percentage'),
															'customer_id' => $customer_id
														)
												 	);

						$curr_sess_payment_data  = array(
							"".$this->input->post('customer_id')."" => $payment_data
						);
						$this->session->set_userdata('payment', $curr_sess_payment_data);
						$this->ReturnJsonArray(true,false,"Discount applied successfully!");
						die;
					}
					else{
						
						$payment_data = $this->session->userdata['payment'];
						$payment_data[''.$customer_id.'']['discount_info']['cart_discount_absolute'] = $this->input->post('cart_discount_absolute');
						$payment_data[''.$customer_id.'']['discount_info']['cart_discount_percentage'] = $this->input->post('cart_discount_percentage');
						$payment_data[''.$customer_id.'']['full_payment_info'] = array();
						$payment_data[''.$customer_id.'']['split_payment_info'] = array();
						
						$this->session->set_userdata('payment', $payment_data);
						$this->ReturnJsonArray(true,false,"Discount applied successfully!");
						die;
					}
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}	
	}

	public function FullPaymentInfo(){
		if($this->IsLoggedIn('cashier')){
			if(isset($_POST) && !empty($_POST)){
				$this->form_validation->set_rules('payment_type', 'Payment Type', 'trim|required');
				$this->form_validation->set_rules('total_final_bill', 'Final Bill', 'trim|required');
				$this->form_validation->set_rules('total_amount_received', 'Amount Received', 'trim|required');
				$this->form_validation->set_rules('balance_to_be_paid_back', 'Balance', 'trim|required');
				$this->form_validation->set_rules('pending_amount', 'Pending Amount', 'trim|required');

				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{	
					$customer_id = $this->input->post('customer_id');
					$curr_sess_payment_data = array();
					if(!isset($this->session->userdata['payment'][''.$customer_id.''])){
						$payment_data = array(
														'full_payment_info' => array(
															'payment_type' => $this->input->post('payment_type'),
															'total_final_bill' => $this->input->post('total_final_bill'),
															'total_amount_received' => $this->input->post('total_amount_received'),
															'balance_to_be_paid_back' => $this->input->post('balance_to_be_paid_back'),
															'pending_amount' => $this->input->post('pending_amount')
														),
														'split_payment_info' => array(),
														'discount_info' => array()
												 	);

						$curr_sess_payment_data  = array(
							"".$this->input->post('customer_id')."" => $payment_data
						);
						$this->session->set_userdata('payment', $curr_sess_payment_data);
						$this->ReturnJsonArray(true,false,"success!");
						die;
					}
					else{
						$payment_data = $this->session->userdata['payment'];
						$payment_data[''.$customer_id.'']['full_payment_info']['payment_type'] = $this->input->post('payment_type');
						$payment_data[''.$customer_id.'']['full_payment_info']['total_final_bill'] = $this->input->post('total_final_bill');
						$payment_data[''.$customer_id.'']['full_payment_info']['total_amount_received'] = $this->input->post('total_amount_received');
						$payment_data[''.$customer_id.'']['full_payment_info']['balance_to_be_paid_back'] = $this->input->post('balance_to_be_paid_back');
						$payment_data[''.$customer_id.'']['full_payment_info']['pending_amount'] = $this->input->post('pending_amount');
						$payment_data[''.$customer_id.'']['split_payment_info'] = array();
						
						
						$this->session->set_userdata('payment', $payment_data);
						$this->ReturnJsonArray(true,false,"success!");
						die;
					}
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}	
	}

	public function SplitPaymentInfo(){
		if($this->IsLoggedIn('cashier')){
			if(isset($_POST) && !empty($_POST)){
				
				$this->form_validation->set_rules('total_final_bill', 'Final Bill', 'trim|required');
				$this->form_validation->set_rules('total_amount_received', 'Amount Received', 'trim|required');
				$this->form_validation->set_rules('balance_to_be_paid_back', 'Balance', 'trim|required');
				$this->form_validation->set_rules('total_pending_amount', 'Pending Amount', 'trim|required');

				if ($this->form_validation->run() == FALSE) 
				{
					$data = array(
									'success' => 'false',
									'error'   => 'true',
									'message' =>  validation_errors()
								 );
					header("Content-type: application/json");
					print(json_encode($data, JSON_PRETTY_PRINT));
					die;
				}
				else{	
					$customer_id = $this->input->post('customer_id');
					if(!empty($_POST['payment_type']) && !empty($_POST['amount_received'])){
						$payment_type = $this->input->post('payment_type');
						$amount_received = $this->input->post('amount_received');

						$counter = 0;
						$split_payment_data = array();
						for($i=0;$i<count($payment_type);$i++){
							$temp = array('payment_type' => $payment_type[$i],'amount_received' => $amount_received[$i]);
							array_push($split_payment_data, $temp);
						}

						if(!isset($this->session->userdata['payment'][''.$customer_id.''])){
							$curr_sess_payment_data = array();
							$payment_data = array(
																'full_payment_info' => array(),
																'split_payment_info' => array(
																	'total_final_bill' => $this->input->post('total_final_bill'),
																	'total_amount_received' => $this->input->post('total_amount_received'),
																	'balance_to_be_paid_back' => $this->input->post('balance_to_be_paid_back'),
																	'total_pending_amount' => $this->input->post('total_pending_amount'),
																	'multiple_payments' => $split_payment_data
																),
																'discount_info' => array()
													 		);

							$curr_sess_payment_data  = array(
								"".$this->input->post('customer_id')."" => $payment_data
							);
							$this->session->set_userdata('payment', $curr_sess_payment_data);
							$this->ReturnJsonArray(true,false,"success!");
							die;
						}
						else{
							$payment_data = $this->session->userdata['payment'];
							$payment_data[''.$customer_id.'']['split_payment_info']['total_final_bill'] = $this->input->post('total_final_bill');
							$payment_data[''.$customer_id.'']['split_payment_info']['total_amount_received'] = $this->input->post('total_amount_received');
							$payment_data[''.$customer_id.'']['split_payment_info']['balance_to_be_paid_back'] = $this->input->post('balance_to_be_paid_back');
							$payment_data[''.$customer_id.'']['split_payment_info']['total_pending_amount'] = $this->input->post('total_pending_amount');
							$payment_data[''.$customer_id.'']['split_payment_info']['multiple_payments'] = $split_payment_data;
							$payment_data[''.$customer_id.'']['full_payment_info'] = array();
							
							$this->session->set_userdata('payment', $payment_data);
							$this->ReturnJsonArray(true,false,"success!");
							die;
						}
					}
					else{
						$this->ReturnJsonArray(false,true,"Please the all values must be filled!");
						die;
					}
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}	
	}

  //MOST Important Function of POS Billing. Be Careful While Changing things!
  /* SAMPLE-DATA coming from the POST Request
	Array
	(
    [txn_data] => Array
        (
            [txn_customer_id] => 11
            [txn_discount] => 95
            [txn_value] => 481
        )

    [txn_settlement] => Array
        (
            [txn_settlement_way] => Split Payment
            [txn_settlement_payment_mode] => Split
            [txn_settlement_amount_received] => 400
            [txn_settlement_balance_paid] => 0
        )

    [customer_pending_data] => Array
        (
            [customer_id] => 11
            [pending_amount] => 81
        )

    [cart_data] => Array
        (
            [0] => Array
                (
                    [service_id] => 1
                    [service_total_value] => 220
                    [service_quantity] => 2
                    [service_expert_id] => 4
                    [service_discount_percentage] => 0
                    [service_discount_absolute] => 10
                )

            [1] => Array
                (
                    [service_id] => 1
                    [service_total_value] => 220
                    [service_quantity] => 2
                    [service_expert_id] => 4
                    [service_discount_percentage] => 0
                    [service_discount_absolute] => 10
                )

        )

	)
  */
	public function DoTransaction(){
		if($this->IsLoggedIn('cashier')){
			if(isset($_POST) && !empty($_POST)){
				$customer_id = $_POST['txn_data']['txn_customer_id'];
				$result = $this->CashierModel->BillingTransaction($_POST);
				if($result['success'] == 'true'){
					//1.Unset the payment session
		 			if(isset($this->session->userdata['payment'])){
		 				$this->session->unset_userdata('payment');
		 			}
          
          // 2.Then unset the cart session
		 			if(isset($this->session->userdata['cart'][$customer_id])){
		 				$curr_sess_cart_data  = $this->session->userdata['cart'];
		 				unset($curr_sess_cart_data[''.$customer_id.'']);
		 				$this->session->set_userdata('cart',$curr_sess_cart_data);
		 			}

					//3.Then unset the customer session from POS
		 			if(isset($this->session->userdata['POS'])){
		 				$curr_sess_cust_data  = $this->session->userdata['POS'];
		 				
		 				$key = array_search($customer_id, array_column($curr_sess_cust_data, 'customer_id'));
		 				
		 				unset($curr_sess_cust_data[$key]);
		 				$curr_sess_cust_data = array_values($curr_sess_cust_data);
		 				
		 				$this->session->set_userdata('POS',$curr_sess_cust_data);
		 			}

          /*CODE*/

					$this->ReturnJsonArray(true,false,"Transaction is successful!");
					die;
				}
				elseif ($result['error'] == 'true') {
					$this->ReturnJsonArray(false,true,$result['message']);
					die;
				}
			}
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}
	}

	public function PrintBill(){
		if($this->IsLoggedIn('cashier')){	
			$customer_id = $this->uri->segment(3);
			if(isset($customer_id)){
				//Check whether customer belongs to the logged cashier's shop and business admin
				$where = array(
					'business_admin_id' => $this->session->userdata['logged_in']['business_admin_id'],
					'business_outlet_id'=> $this->session->userdata['logged_in']['business_outlet_id'],
					'customer_id'       => $customer_id
				);

				$check = $this->CashierModel->VerifyCustomer($where);
				if($check['success'] == 'true'){	
					$data['title'] = "Your Bill";
					$data['experts'] = $this->GetExperts();
					$data['shop_details'] = $this->ShopDetails();
					$data['individual_customer'] = $this->GetCustomerBilling($customer_id);
				
					
					if(isset($this->session->userdata['cart'][$customer_id])){
						$data['cart'] = $this->session->userdata['cart'][$customer_id];
					}

					if(isset($this->session->userdata['payment'])){
						$data['payment'] = $this->session->userdata['payment'][$customer_id];
					}

					$this->load->view('cashier/cashier_print_bill',$data);
				}
				elseif ($check['error'] == 'true'){
					$data = array(
						'heading' => "Illegal Access!",
						'message' => $check['message']
					);
					$this->load->view('errors/html/error_general',$data);	
				}
			}
			else{
				$data = array(
					'heading' => "Illegal Access!",
					'message' => "Customer details/ID missing. Please do not change url!"
				);
				$this->load->view('errors/html/error_general',$data);
			}	
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}	
	}

	public function JobOrder(){
		if($this->IsLoggedIn('cashier')){	
			$customer_id = $this->uri->segment(3);
			if(isset($customer_id)){
				//Check whether customer belongs to the logged cashier's shop and business admin
				$where = array(
					'business_admin_id' => $this->session->userdata['logged_in']['business_admin_id'],
					'business_outlet_id'=> $this->session->userdata['logged_in']['business_outlet_id'],
					'customer_id'       => $customer_id
				);

				$check = $this->CashierModel->VerifyCustomer($where);
				if($check['success'] == 'true'){	
					$data['title'] = "Job Order";
					$data['experts'] = $this->GetExperts();
					$data['shop_details'] = $this->ShopDetails();
					$data['individual_customer'] = $this->GetCustomerBilling($customer_id);
				
					
					if(isset($this->session->userdata['cart'][$customer_id])){
						$data['cart'] = $this->session->userdata['cart'][$customer_id];
					}

					$this->load->view('cashier/cashier_job_order',$data);
				}
				elseif ($check['error'] == 'true'){
					$data = array(
						'heading' => "Illegal Access!",
						'message' => $check['message']
					);
					$this->load->view('errors/html/error_general',$data);	
				}
			}
			else{
				$data = array(
					'heading' => "Illegal Access!",
					'message' => "Customer details/ID missing. Please do not change url!"
				);
				$this->load->view('errors/html/error_general',$data);
			}	
		}
		else{
			$this->LogoutUrl(base_url()."index.php/Cashier/");
		}	
	}


	//Get Expense Tracker
private function GetCashierExpenses(){
	if($this->IsLoggedIn('cashier')){
		$where = array(
			'employee_business_admin' => $this->session->userdata['logged_in']['business_admin_id'],
			'employee_business_outlet'=>$this->session->userdata['outlets']['current_outlet'],
			'employee_is_active'=>TRUE
			
			

		);
		$data = $this->CashierModel->MultiWhereSelect('mss_employees',$where);
		// $data = $this->BusinessAdminModel->MultiWhereSelect('mss_expense_types',$where);
		if($data['success'] == 'true'){	
			return $data['res_arr'];
		}
	}
	else{
		$this->LogoutUrl(base_url()."index.php/Cashier/");
	}	
	
}
	
//Expense Tracker function
public function AddExpenses (){
	if($this->IsLoggedIn('cashier')){		
		if(isset($_POST) && !empty($_POST)){
			$this->form_validation->set_rules('expense_type', 'expense_type', 'trim|required|max_length[50]');
			$this->form_validation->set_rules('item_name', 'item_name', 'trim|max_length[50]');
			$this->form_validation->set_rules('amount', 'amount', 'trim|required');
			$this->form_validation->set_rules('quantity', 'quantity', 'trim|required|max_length[100]');
			$this->form_validation->set_rules('unit', 'unit', 'trim|required|max_length[10]');
			$this->form_validation->set_rules('payment_mode', 'payment_mode', 'trim|max_length[50]');
			$this->form_validation->set_rules('expense_status', 'expense_status', 'trim|required');
			if ($this->form_validation->run() == FALSE) 
			{
				$data = array(
								'success' => 'false',
								'error'   => 'true',
								'message' =>  validation_errors()
							 );
				print_r($data);
				exit;
				header("Content-type: application/json");
				print(json_encode($data, JSON_PRETTY_PRINT));
				die;
			}
			else{
				
				$data = array(
					'expense_date' 	=> $this->input->post('expense_date'),
					'expense_type' 	=> $this->input->post('expense_type'),
					'item_name' 	=> $this->input->post('item_name'),
					'amount' 	=> $this->input->post('amount'),
					'quantity' 	=> $this->input->post('quantity'),
					'unit' 	=> $this->input->post('unit'),
					'payment_mode' 	=> $this->input->post('payment_mode'),
					'expense_status' 	=> $this->input->post('expense_status')
					
					
				);

				$result = $this->BusinessAdminModel->Insert($data,'mss_expenses');
				
				if($result['success'] == 'true'){
					$this->ReturnJsonArray(true,false,"Expenses added successfully!");
					die;
				}
				elseif($result['error'] == 'true'){
					$this->ReturnJsonArray(false,true,$result['message']);
								die;
				}
			}
		}
		else{
			$data = $this->GetDataForCashier("cashier_expense");
			$data['cashier_expense'] = $this->GetCashierExpenses();
			// print_r($data['cashier_expenses']);
			// exit;
			// $data['expense_type'] = $this->GetExpensesTypes($this->session->userdata['outlets']['current_outlet']);
			
			$this->load->view('cashier/cashier_expense_view',$data);
			// print_r($data);
			// exit;
			
		}
		
	}
	else{
		$this->LogoutUrl(base_url()."index.php/Cashier/");
	}	
}
}
